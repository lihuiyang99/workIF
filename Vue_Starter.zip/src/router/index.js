import Vue from 'vue'
import Router from 'vue-router'

// Containers
import Home from '@/containers/Full'

// Views
 import Login from '@/views/Login'
// import whole from '@/views/Dashboard'
// import Wholefull from '@/views/wholefull'
 import Blank from '@/views/Blank'
// import Channel540 from '@/views/Channel540'
// import ChannelLocal540 from '@/views/ChannelLocal540'
// import Channel from '@/views/Channel'
// import ChannelLocal from '@/views/ChannelLocal'
// import Video from '@/views/Video'
// import Headline from '@/views/Headline'
// import HeadlineEditor from '@/views/HeadlineEditor'
// import HeadlineAI from '@/views/HeadlineAI'
// import HeadlinesCategories from '@/views/HeadlinesCategories'
// import HeadlineDisplayType from '@/views/HeadlineDisplayType'
// import Wemedia from '@/views/Wemedia'
// import WemediaAccount from '@/views/WemediaAccount'
// import Manufacture from '@/views/Manufacture'
// import ManufactureApp from '@/views/ManufactureApp'
// import idpool_whole from '@/views/idpool/Whole'
// import Article from '@/views/Article'
// import Advert from '@/views/Advert'
// import Advert554 from '@/views/Advert554'
// import AdvertType from '@/views/AdvertType'
// import ArticleAttribute from '@/views/ArticleAttribute'
// import Recommend from '@/views/Recommend'
// import videoRecommend from '@/views/videoRecommend'
// import Image from '@/views/Image'
// import ClickHistory from '@/views/ClickHistory'
// import Jppool from '@/views/jppool'
// import PullData from '@/views/PullData'


//const Home = resolve => {  require.ensure(['@/containers/Full'], () => {   resolve(require('@/containers/Full')) }) }
//const Login = resolve => {  require.ensure(['@/views/Login'], () => {   resolve(require('@/views/Login')) }) }
const whole = resolve => {  require.ensure(['@/views/Dashboard'], () => {   resolve(require('@/views/Dashboard')) }) }
const Wholefull = resolve => {  require.ensure(['@/views/wholefull'], () => {   resolve(require('@/views/wholefull')) }) }
//const Blank = resolve => {  require.ensure(['@/views/Blank'], () => {   resolve(require('@/views/Blank')) }) }
const Channel540 = resolve => {  require.ensure(['@/views/Channel540'], () => {   resolve(require('@/views/Channel540')) }) }
const ChannelLocal540 = resolve => {  require.ensure(['@/views/ChannelLocal540'], () => {   resolve(require('@/views/ChannelLocal540')) }) }
const Channel = resolve => {  require.ensure(['@/views/Channel'], () => {   resolve(require('@/views/Channel')) }) }
const ChannelLocal = resolve => {  require.ensure(['@/views/ChannelLocal'], () => {   resolve(require('@/views/ChannelLocal')) }) }
const Video = resolve => {  require.ensure(['@/views/Video'], () => {   resolve(require('@/views/Video')) }) }
const Headline = resolve => {  require.ensure(['@/views/Headline'], () => {   resolve(require('@/views/Headline')) }) }
const HeadlineEditor = resolve => {  require.ensure(['@/views/HeadlineEditor'], () => {   resolve(require('@/views/HeadlineEditor')) }) }
const HeadlineAI = resolve => {  require.ensure(['@/views/HeadlineAI'], () => {   resolve(require('@/views/HeadlineAI')) }) }
const HeadlinesCategories = resolve => {  require.ensure(['@/views/HeadlinesCategories'], () => {   resolve(require('@/views/HeadlinesCategories')) }) }
const HeadlineDisplayType = resolve => {  require.ensure(['@/views/HeadlineDisplayType'], () => {   resolve(require('@/views/HeadlineDisplayType')) }) }
const Wemedia = resolve => {  require.ensure(['@/views/Wemedia'], () => {   resolve(require('@/views/Wemedia')) }) }
const WemediaAccount = resolve => {  require.ensure(['@/views/WemediaAccount'], () => {   resolve(require('@/views/WemediaAccount')) }) }
const Manufacture = resolve => {  require.ensure(['@/views/Manufacture'], () => {   resolve(require('@/views/Manufacture')) }) }
const ManufactureApp = resolve => {  require.ensure(['@/views/ManufactureApp'], () => {   resolve(require('@/views/ManufactureApp')) }) }
const idpool_whole = resolve => {  require.ensure(['@/views/idpool/Whole'], () => {   resolve(require('@/views/idpool/Whole')) }) }
const Article = resolve => {  require.ensure(['@/views/Article'], () => {   resolve(require('@/views/Article')) }) }
const Advert = resolve => {  require.ensure(['@/views/Advert'], () => {   resolve(require('@/views/Advert')) }) }
const Advert554 = resolve => {  require.ensure(['@/views/Advert554'], () => {   resolve(require('@/views/Advert554')) }) }
const AdvertType = resolve => {  require.ensure(['@/views/AdvertType'], () => {   resolve(require('@/views/AdvertType')) }) }
const ArticleAttribute = resolve => {  require.ensure(['@/views/ArticleAttribute'], () => {   resolve(require('@/views/ArticleAttribute')) }) }
const Recommend = resolve => {  require.ensure(['@/views/Recommend'], () => {   resolve(require('@/views/Recommend')) }) }
const videoRecommend = resolve => {  require.ensure(['@/views/videoRecommend'], () => {   resolve(require('@/views/videoRecommend')) }) }
const Image = resolve => {  require.ensure(['@/views/Image'], () => {   resolve(require('@/views/Image')) }) }
const ClickHistory = resolve => {  require.ensure(['@/views/ClickHistory'], () => {   resolve(require('@/views/ClickHistory')) }) }
const Jppool = resolve => {  require.ensure(['@/views/jppool'], () => {   resolve(require('@/views/jppool')) }) }
const PullData = resolve => {  require.ensure(['@/views/PullData'], () => {   resolve(require('@/views/PullData')) }) }
const VideoChannel = resolve => {  require.ensure(['@/views/VideoChannel'], () => {   resolve(require('@/views/VideoChannel')) }) }
const VideoReGroup = resolve => {  require.ensure(['@/views/VideoReGroup'], () => {   resolve(require('@/views/VideoReGroup')) }) }


Vue.use(Router)

export default new Router({
  mode: 'hash',
  linkActiveClass: 'open active',
  scrollBehavior: () => ({ y: 0 }),
  routes: [
    {
      // 登陆页面
      path: '/',
      name: 'Login',
      component: Login,
      hidden: true
    },
    {
      path: '/home',
     /* redirect: '/wholefull',*/
      name: '历史回溯',
      component: Home,
      show:true,
      hidden: false,
      children: [
        {
          path: '/wholefull',
          name: '整体趋势(新增,日活)',
          component: Wholefull,
          hidden: false
        },
        {
          path: '/whole',
          name: '整体趋势',
          component: whole,
          hidden: false
        },
        {
          path: '/Blank',
          name: '频道数据',
          component: Blank,
          hidden: false,
          /*redirect: '/channel540',*/
          children:[
            {
              path: '/channel540',
              name: '频道（540）',
              component: Channel540,
              hidden: false
            },
            {
              path: '/channellocal540',
              name: '本地频道（540）',
              component: ChannelLocal540,
              hidden: false
            },
            {
              path: '/channel',
              name: '频道全版本',
              component: Channel,
              hidden: false
            },
            {
              path: '/channellocal',
              name: '本地频道全版本',
              component: ChannelLocal,
              hidden: false
            }
          ]
        },
        {
          path: '/Blank',
          name: '视频数据',
          component: Blank,
          hidden: false,
          children:[
            {
              path: '/video',
              name: '视频数据',
              component: Video,
              hidden: false
            },
            {
              path: '/VideoChannel',
              name: '视频频道',
              component: VideoChannel,
              hidden: false
            },
            {
              path: '/VideoReGroup',
              name: '视频推荐分组',
              component: VideoReGroup,
              hidden: false
            }
          ]
        },
        {
          path: '/Blank',
          name: '头条频道(540以上)',
          component: Blank,
          hidden: false,
         /* redirect: '/headline',*/
          children: [
            {
              path: '/headline',
              name: '编辑流 && 推荐流',
              component: Headline,
              hidden: false
            },
            {
              path: '/headlineeditor',
              name: '编辑流',
              component: HeadlineEditor,
              hidden: false
            },
            {
              path: '/headlineai',
              name: '推荐流',
              component: HeadlineAI,
              hidden: false
            },
            {
              path: '/HeadlinesCategories',
              name: '头条分类',
              component: HeadlinesCategories,
              hidden: false
            },
            {
              path: '/HeadlineDisplayType',
              name: '头条展示分类',
              component: HeadlineDisplayType,
              hidden: false
            }
          ]
        },
        {
          path: '/Blank',
          name: '自媒体数据',
          component: Blank,
          hidden: false,
         /* redirect: '/wemedia',*/
          children: [
            {
              path: '/wemedia',
              name: '新闻汇总',
              component: Wemedia,
              hidden: false
            },
            {
              path: '/wemediaaccount',
              name: '账号统计',
              component: WemediaAccount,
              hidden: false
            }
          ]
        },
        {
          path: '/Blank',
          name: '厂商数据',
          component: Blank,
          /*redirect: '/wemedia',*/
          hidden: false,
          children: [
            {
              path: '/manufacture',
              name: '分组汇总',
              component: Manufacture,
              hidden: false
            },
            {
              path: '/manufactureapp',
              name: '厂商统计',
              component: ManufactureApp,
              hidden: false
            }
          ]
        },
        {
          path: '/Blank',
          name: '长效数据',
          component: Blank,
          /*redirect: '/idpool_whole',*/
          hidden: false,
          children: [
            {
              path: '/idpool_whole',
              name: '长效汇总',
              component: idpool_whole,
              hidden: false
            }
          ]
        },
        {
          path: '/PullData',
          name: '拉起数据',
          component: PullData,
          hidden: false
        },
        {
          path: '/Blank',
          name: '广告数据',
          component: Blank,
          /*redirect: '/wemedia',*/
          hidden: false,
          children: [
            {
              path: '/advert',
              name: '广告汇总',
              component: Advert,
              hidden: false
            },
            {
              path: '/advert554',
              name: '广告汇总(554以上)',
              component: Advert554,
              hidden: false
            },
            {
              path: '/advertType',
              name: '广告分类',
              component: AdvertType,
              hidden: false
            }
          ]
        },
      ]
    },
    {
      // 导航栏二
      path: '/home',
      name: '实时跟踪',
      component: Home,
      hidden: false,
      show:true,
      /*redirect: '/article',*/
      children: [
        {
          path: '/article',
          name: '文章消费反馈',
          component: Article,
          hidden: false
        },
        {
          path: '/recommend',
          name: '头条推荐历史',
          component: Recommend,
          hidden: false
        },
        {
          path: '/videoRecommend',
          name: '视频推荐历史',
          component: videoRecommend,
          hidden: false
        },
        {
          path: '/clickHistory',
          name: '点击历史',
          component: ClickHistory,
          hidden: false
        },
        {
          path: '/image',
          name: '用户画像',
          component: Image,
          hidden: false
        },
        {
          path: '/ArticleAttribute',
          name: '内容画像',
          component: ArticleAttribute,
          hidden: false
        },
        {
          path: '/jppool',
          name: '精品池',
          component: Jppool,
          hidden: false
        }
      ]
    }/*,
     { path: "*", redirect: '/',show:false }*/
  ]
})
