<template>
  <!-- 推荐流页面 -->
  <div class="animated fadeIn">
    <div class="card">
      <div class="card-block">
        <div class="row">
          <div class="col-sm-5">
            <h4 class="card-title">推荐流曲线图</h4>
            <div class="small text-muted"></div>
          </div><!--/.col-->
        </div><!--/.row-->
         <div id="headlineArea" style="width: 100%; height: 400px; margin: 0 auto;text-align: -webkit-center;"></div>
      </div>
    </div><!--/.card-->
    <div class="row" style="margin-bottom:20px">
      <div id="wholeTable" style="width: 98%; margin: 0 auto">
      <el-row style="margin-bottom: -10px ">
       <el-col :span="19">
          <el-pagination :total="tableDataAll.length" :page-size="pageSize" :page-sizes="[5, 10, 15, 20]" :current-page="pageCurr"
          layout="total, sizes, prev, pager, next, jumper" @size-change="handleSizeChange" @current-change="handleCurrentChange"></el-pagination>
        </el-col>
        <el-col :span="3" style="margin-top: -4px">
          <el-date-picker type="daterange" placeholder="选择日期范围" :clearable="false" v-model="input" @change="handleChange"></el-date-picker>
        </el-col>
      </el-row>
      <el-tooltip  effect="dark" placement="bottom" >
        <div slot="content">推荐文章1日曝光留存率：前1日在头条推荐流曝光2屏幕以上的用户，本日仍然曝光2屏幕以上的用户所占的比例<br/></div>
      <i class="el-icon-warning" style="float: right;margin:7px 15px"></i>
      </el-tooltip>
       <el-table   v-loading="isLoading"   element-loading-text="拼命加载中"  :data="tableData" :row-class-name="tableRowClassName">
          <el-table-column align="center" v-for="item in columns" :prop="item.prop" :label="item.label" :width="item.width" sortable>
          </el-table-column>
        </el-table>
    </div>
  </div>
  </div><!--/.row-->

</template>

<script>
import echarts from 'echarts'
var input = '',
  myChart,
  startDate = '',
  endDate = '',
  pageSize = 10,
  pageCurr = 1,
  columns = [
    {
      prop: 'date',
      label: '日期',
      width: '120px'
    },
    {
      prop: 'expoPv',
      label: '曝光次数',
      width: '90px'
    },
    {
      prop: 'expoUv',
      label: '曝光人数',
      width: '120px'
    },
    {
      prop: 'expoAvg',
      label: '人均曝光',
      width: '120px'
    },
    {
      prop: 'playPv',
      label: '播放次数',
      width: '100px'
    },
    {
      prop: 'playUv',
      label: '播放人数',
      width: '110px'
    },
    {
      prop: 'playAvg',
      label: '播放人数',
      width: '110px'
    },
    {
      prop: 'playTimeAvg',
      label: '人均播放时长（s）',
      width: '100px'
    },
    {
      prop: 'rate',
      label: '转化率',
      width: '90px'
    },
    {
      prop: 'downPullPv',
      label: '下拉次数',
      width: '90px'
    },
    {
      prop: 'downPullUv',
      label: '下拉人数',
      width: '110px'
    },
    {
      prop: 'downPullAvg',
      label: '人均下拉',
      width: '100px'
    },
    {
      prop: 'upPullPv',
      label: '上拉次数',
      width: '110px'
    },
    {
      prop: 'upPullUv',
      label: '上拉人数',
      width: '100px'
    },
    {
      prop: 'upPullAvg',
      label: '人均上拉',
      width: '100px'
    },
    {
      prop: 'commentPv',
      label: '评论次数',
      width: '100px'
    },
    {
      prop: 'commentUv',
      label: '评论人数',
      width: '100px'
    },
    {
      prop: 'storePv',
      label: '收藏次数',
      width: '100px'
    },
    {
      prop: 'storeUv',
      label: '收藏人数',
      width: '120px'
    },
    {
      prop: 'sharePv',
      label: '分享次数',
      width: '100px'
    },
    {
      prop: 'shareUv',
      label: '分享人数',
      width: '100px'
    },
    {
      prop: 'videoExpo',
      label: '视频曝光量',
      width: '100px'
    },
    {
      prop: 'videoPlayRateAvg',
      label: '人均视频观看比例',
      width: '100px'
    }
    
  ],
  tableData = [],
  tableDataAll = [],
  tableDataAllDate = [],
  tableDataAllExpoPv = [],
  tableDataAllExpoUv = [],
  tableDataAllExpoAvg = [],
  tableDataAllPlayPv= [],
  tableDataAllPlayUv= [],
  tableDataAllPlayAvg= [],
  tableDataAllPlayTimeAvg = [],
  tableDataAllRate = [],
  tableDataAllDownPullPv = [],
  tableDataAllDownPullUv = [],
  tableDataAllDownPullAvg = [],
  tableDataAllUpPullPv = [],
  tableDataAllUpPullUv = [],
  tableDataAllUpPullAvg = [],
  tableDataAllCommentPv = [],
  tableDataAllCommentUv = [],
  tableDataAllStorePv = [],
  tableDataAllStoreUv = [],
  tableDataAllSharePv = [],
  tableDataAllShareUv = [],
  tableDataAllVideoExpo = [],
  tableDataAllVideoPlayRateAvg = [];
export default {
  data () {
    return {
      isLoading: false,
      input: input,
      startDate: startDate,
      endDate: endDate,
      pageSize: pageSize,
      pageCurr: pageCurr,
      columns: columns,
      tableData: tableData,
      tableDataAll: tableDataAll,
      tableDataAllDate: tableDataAllDate,
     tableDataAllExpoPv:tableDataAllExpoPv,
     tableDataAllExpoUv:tableDataAllExpoUv,
     tableDataAllExpoAvg:tableDataAllExpoAvg,
     tableDataAllPlayPv:tableDataAllPlayPv,
     tableDataAllPlayUv:tableDataAllPlayUv,
     tableDataAllPlayAvg:tableDataAllPlayAvg,
     tableDataAllPlayTimeAvg:tableDataAllPlayTimeAvg,
     tableDataAllRate:tableDataAllRate,
     tableDataAllDownPullPv:tableDataAllDownPullPv,
     tableDataAllDownPullUv:tableDataAllDownPullUv,
     tableDataAllDownPullAvg:tableDataAllDownPullAvg,
     tableDataAllUpPullPv:tableDataAllUpPullPv,
     tableDataAllUpPullUv:tableDataAllUpPullUv,
     tableDataAllUpPullAvg:tableDataAllUpPullAvg,
     tableDataAllCommentPv:tableDataAllCommentPv,
     tableDataAllCommentUv:tableDataAllCommentUv,
     tableDataAllStorePv:tableDataAllStorePv,
     tableDataAllStoreUv:tableDataAllStoreUv,
     tableDataAllSharePv:tableDataAllSharePv,
     tableDataAllShareUv:tableDataAllShareUv,
     tableDataAllVideoExpo:tableDataAllVideoExpo,
     tableDataAllVideoPlayRateAvg:tableDataAllVideoPlayRateAvg
    }
  },
  methods: {
    // 选择
    handleChange(val) {
      this.startDate = val.slice(0, 4)+'-'+val.slice(5, 7)+'-'+val.slice(8, 10);
      this.endDate = val.slice(13, 17)+'-'+val.slice(18, 20)+'-'+val.slice(21, 23);
      this.getJSON();
    },
    // 分页
    handleSizeChange(val) {
      this.pageSize = val;
      this.pageCurr = 1;
      tableData.splice(0, tableData.length);
      val=val>=tableDataAll.length?tableDataAll.length:val
      for (var i = 0; i < val; i++) {
        var line = tableDataAll[i];
        line['date'] = line['date']
          line['expoPv'] = line['expoPv'];
          line['expoUv'] = line['expoUv'];
          line['expoAvg'] = line['expoAvg'];
          line['playPv'] = line['playPv'];
          line['playUv'] = line['playUv'];
          line['playAvg'] = line['playAvg'];
          line['playTimeAvg'] = line['playTimeAvg'];
          line['rate'] = line['rate'];
          line['downPullPv'] = line['downPullPv'];
          line['downPullUv'] = line['downPullUv'];
          line['downPullAvg'] = line['downPullAvg'];
          line['upPullPv'] = line['upPullPv'];
          line['upPullUv'] = line['upPullUv'];
          line['upPullAvg'] = line['upPullAvg'];
          line['commentPv'] = line['commentPv'];
          line['commentUv'] = line['commentUv'];
          line['storePv'] = line['storePv'];
          line['storeUv'] = line['storeUv'];
          line['sharePv'] = line['sharePv'];
          line['shareUv'] = line['shareUv'];
          line['videoExpo'] = line['videoExpo'];
          line['videoPlayRateAvg'] = line['videoPlayRateAvg'];
        tableData.push(tableDataAll[i]);
      }
    },
    // 换页
    handleCurrentChange(val) {
      this.pageCurr = val;
      tableData.splice(0, tableData.length);
      var end = (tableDataAll.length > (this.pageCurr)*(this.pageSize)) ? (this.pageCurr)*(this.pageSize) : tableDataAll.length;
      for (var i = (this.pageCurr-1)*(this.pageSize); i < end; i++) {
        var line = tableDataAll[i];
        line['date'] = line['date']
          line['expoPv'] = line['expoPv'];
          line['expoUv'] = line['expoUv'];
          line['expoAvg'] = line['expoAvg'];
          line['playPv'] = line['playPv'];
          line['playUv'] = line['playUv'];
          line['playAvg'] = line['playAvg'];
          line['playTimeAvg'] = line['playTimeAvg'];
          line['rate'] = line['rate'];
          line['downPullPv'] = line['downPullPv'];
          line['downPullUv'] = line['downPullUv'];
          line['downPullAvg'] = line['downPullAvg'];
          line['upPullPv'] = line['upPullPv'];
          line['upPullUv'] = line['upPullUv'];
          line['upPullAvg'] = line['upPullAvg'];
          line['commentPv'] = line['commentPv'];
          line['commentUv'] = line['commentUv'];
          line['storePv'] = line['storePv'];
          line['storeUv'] = line['storeUv'];
          line['sharePv'] = line['sharePv'];
          line['shareUv'] = line['shareUv'];
          line['videoExpo'] = line['videoExpo'];
          line['videoPlayRateAvg'] = line['videoPlayRateAvg'];
        tableData.push(tableDataAll[i]);
      }
    },
    tableRowClassName(row, index) {
      if (index%2 != 0) {
        return 'odd-row';
      } else if (index%2 == 0) {
        return 'even-row';
      }
      return '';
    },
    gettodayDay: function (target) {
      var today = new Date();
      today.setTime(target);
      var year = today.getFullYear();
      var month = today.getMonth();
      var date = today.getDate();
      month = this.addZero(month+1);
      date = this.addZero(date);
      return year.toString()+'-'+month.toString()+'-'+date.toString();
    },
    getDaytime: function (target) {
      var today = new Date();
      today.setTime(target);
      var hour = today.getHours();
      var minute = today.getMinutes();
      var second = today.getSeconds();
      hour = this.addZero(hour);
      minute = this.addZero(minute);
      second = this.addZero(second);
      return hour.toString()+':'+minute.toString()+':'+second.toString();
    },
    getDay: function (day) {
      var today = new Date();
      var target = today.getTime()+1000*60*60*24*day;
      today.setTime(target);
      var year = today.getFullYear();
      var month = today.getMonth();
      var date = today.getDate();
      month = this.addZero(month+1);
      date = this.addZero(date);
      return year.toString()+'-'+month.toString()+'-'+date.toString();
    },
    addZero: function (time) {
      if (time.toString().length == 1) {
        time = '0'+time;
      }
      return time;
    },
    getJSON: function () {
      this.isLoading = true;
      if ((this.startDate) && (this.endDate)) {
      } else {
        this.startDate = this.getDay(-31);
        this.endDate = this.getDay(0);
      }
      var url='http://10.80.128.150:58080/video/data?startDate='+this.startDate+'&endDate='+this.endDate
      this.$http.get(url).then((response) => {
        console.log(response)
        this.isLoading = false;
        tableDataAll.splice(0, tableDataAll.length);
        tableDataAllDate.splice(0, tableDataAllDate.length);
        tableDataAllExpoPv.splice(0, tableDataAllExpoPv.length);
        tableDataAllExpoUv.splice(0, tableDataAllExpoUv.length);
        tableDataAllExpoAvg.splice(0, tableDataAllExpoAvg.length);
        tableDataAllPlayPv.splice(0, tableDataAllPlayPv.length);
        tableDataAllPlayUv.splice(0, tableDataAllPlayUv.length);
        tableDataAllPlayAvg.splice(0, tableDataAllPlayAvg.length);
        tableDataAllPlayTimeAvg.splice(0, tableDataAllPlayTimeAvg.length);
        tableDataAllRate.splice(0, tableDataAllRate.length);
        tableDataAllDownPullPv.splice(0, tableDataAllDownPullPv.length);
        tableDataAllDownPullUv.splice(0, tableDataAllDownPullUv.length);
        tableDataAllDownPullAvg.splice(0, tableDataAllDownPullAvg.length);
        tableDataAllUpPullPv.splice(0, tableDataAllUpPullPv.length);
        tableDataAllUpPullUv.splice(0, tableDataAllUpPullUv.length);
        tableDataAllUpPullAvg.splice(0, tableDataAllUpPullAvg.length);
        tableDataAllCommentPv.splice(0, tableDataAllCommentPv.length);
        tableDataAllCommentUv.splice(0, tableDataAllCommentUv.length);
        tableDataAllStorePv.splice(0, tableDataAllStorePv.length);
        tableDataAllStoreUv.splice(0, tableDataAllStoreUv.length);
        tableDataAllSharePv.splice(0, tableDataAllSharePv.length);
        tableDataAllShareUv.splice(0, tableDataAllShareUv.length);
        tableDataAllVideoExpo.splice(0, tableDataAllVideoExpo.length);
        tableDataAllVideoPlayRateAvg.splice(0, tableDataAllVideoPlayRateAvg.length);
        var temps = response.data;
        for (var i in temps) {
          var temp = temps[i];
          var line = {};
         
          line['date'] = this.gettodayDay(temp['date']);
          line['expoPv'] = temp['expoPv'];
          line['expoUv'] = temp['expoUv'];
          line['expoAvg'] = temp['expoAvg'];
          line['playPv'] = temp['playPv'];
          line['playUv'] = temp['playUv'];
          line['playAvg'] = temp['playAvg'];
          line['playTimeAvg'] = temp['playTimeAvg'];
          line['rate'] = temp['rate'];
          line['downPullPv'] = temp['downPullPv'];
          line['downPullUv'] = temp['downPullUv'];
          line['downPullAvg'] = temp['downPullAvg'];
          line['upPullPv'] = temp['upPullPv'];
          line['upPullUv'] = temp['upPullUv'];
           line['upPullAvg'] = temp['upPullAvg'];
          line['commentPv'] = temp['commentPv'];
          line['commentUv'] = temp['commentUv'];
          line['storePv'] = temp['storePv'];
          line['storeUv'] = temp['storeUv'];
          line['sharePv'] = temp['sharePv'];
          line['shareUv'] = temp['shareUv'];
          line['videoExpo'] = temp['videoExpo'];
          line['videoPlayRateAvg'] = temp['videoPlayRateAvg'];
          tableDataAll.unshift(line);
          tableDataAllDate.push(line['date']);
          tableDataAllExpoPv.push(line['expoPv']);
          tableDataAllExpoUv.push(line['expoUv']);
          tableDataAllExpoAvg.push(line['expoAvg']);
          tableDataAllPlayPv.push(line['playPv']);
          tableDataAllPlayUv.push(line['playUv']);
          tableDataAllPlayAvg.push(line['playAvg']);
          tableDataAllPlayTimeAvg.push(line['playTimeAvg']);
          tableDataAllRate.push(line['rate']);
          tableDataAllDownPullPv.push(line['downPullPv']);
          tableDataAllDownPullUv.push(line['downPullUv']);
          tableDataAllDownPullAvg.push(line['downPullAvg']);
          tableDataAllUpPullPv.push(line['upPullPv']);
          tableDataAllUpPullUv.push(line['upPullUv']);
          tableDataAllUpPullAvg.push(line['upPullAvg']);
          tableDataAllCommentPv.push(line['commentPv']);
          tableDataAllCommentUv.push(line['commentUv']);
          tableDataAllStorePv.push(line['storePv']);
          tableDataAllStoreUv.push(line['storeUv']);
          tableDataAllSharePv.push(line['sharePv']);
          tableDataAllShareUv.push(parseFloat(line['shareUv']));
          tableDataAllVideoExpo.push(line['videoExpo']);
          tableDataAllVideoPlayRateAvg.push(parseFloat(line['videoPlayRateAvg']));
        }
        tableData.splice(0, tableData.length);
        if (tableDataAll.length < 5) {
          this.pageSize = tableDataAll.length;
        } else {
          this.pageSize = 10;
        }
        for (var i = 0; i < this.pageSize; i++) {
          var line = tableDataAll[i];
          line['date'] = line['date']
          line['expoPv'] = line['expoPv'];
          line['expoUv'] = line['expoUv'];
          line['expoAvg'] = line['expoAvg'];
          line['playPv'] = line['playPv'];
          line['playUv'] = line['playUv'];
          line['playAvg'] = line['playAvg'];
          line['playTimeAvg'] = line['playTimeAvg'];
          line['rate'] = line['rate'];
          line['downPullPv'] = line['downPullPv'];
          line['downPullUv'] = line['downPullUv'];
          line['downPullAvg'] = line['downPullAvg'];
          line['upPullPv'] = line['upPullPv'];
          line['upPullUv'] = line['upPullUv'];
          line['upPullAvg'] = line['upPullAvg'];
          line['commentPv'] = line['commentPv'];
          line['commentUv'] = line['commentUv'];
          line['storePv'] = line['storePv'];
          line['storeUv'] = line['storeUv'];
          line['sharePv'] = line['sharePv'];
          line['shareUv'] = line['shareUv'];
          line['videoExpo'] = line['videoExpo'];
          line['videoPlayRateAvg'] = line['videoPlayRateAvg'];
          tableData.push(tableDataAll[i]);
        }
      })
    }
  },
  created: function () {
    this.getJSON();
  },
  beforeUpdate: function () {
    var option = {
      legend: {
        left: 'center',
        data: ['曝光次数', '曝光人数', '人均曝光', '播放次数', '播放人数', '人均播放', '人均播放时长（s）', '转化率', '下拉次数', '下拉人数', '人均下拉', '上拉次数', '上拉人数', '人均上拉', '评论次数', '评论人数', '收藏次数', '收藏人数', '分享次数', '分享次数', '收藏次数', '分享人数', '视频曝光量', '人均视频观看比例'],
        selectedMode: 'multiple',
        selected: {  
                    '曝光次数': true,  
                    '曝光人数': false,  
                    '人均曝光': false,  
                    '播放次数': false,  
                    '播放人数': false,  
                    '人均播放': false, 
                    '人均播放时长（s）': false,  
                    '转化率': false,
                    '下拉次数': false,  
                    '下拉人数': false,  
                    '人均下拉': false,  
                    '上拉次数': false,  
                    '上拉人数': false, 
                    '评论次数': false,  
                    '评论人数': false,
                    '收藏次数': false,  
                    '收藏人数': false,
                    '分享次数': false,  
                    '分享人数': false,  
                    '视频曝光量': false,  
                    '人均视频观看比例': false, 
                }  
      },
      tooltip: {
        trigger: 'axis',
        position: function (pt) {
          return [pt[0]-100, '10%'];
        }
      },
        toolbox: {
        right:'2%',
        top:'10%',
        show: true,
        feature : {
            mark : {show: true},
            dataZoom : {show: true},
            magicType: {type: ['line', 'bar']},
            restore : {show: true},
            saveAsImage : {show: true}
        }
    },
      xAxis: {
        type: 'category',
        boundaryGap: false,
        data: this.tableDataAllDate
      },
      yAxis: {
        type: 'value',
        boundaryGap: [0, '30%']
      },
      dataZoom: [
        {
          type: 'slider',
          show: true,
          xAxisIndex: [0],
          start: 0,
          end: 100
        },
        {
          type: 'inside',
          xAxisIndex: [0],
          start: 0,
          end: 100
        }
      ],
      series: [
        {
          name: '曝光次数',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.tableDataAllExpoPv
        },
        {
          name: '曝光人数',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.tableDataAllExpoUv
        },
        {
          name: '人均曝光',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.tableDataAllExpoAvg
        },
        {
          name: '播放次数',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.tableDataAllPlayPv
        },
        {
          name: '播放人数',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.tableDataAllPlayUv
        },
        {
          name: '人均播放',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.tableDataAllPlayAvg
        },
        {
          name: '人均播放时长（s）',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.tableDataAllPlayTimeAvg
        },
        {
          name: '转化率',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.tableDataAllRate
        },
        {
          name: '下拉次数',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.tableDataAllDownPullPv
        },
        {
          name: '下拉人数',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.tableDataAllDownPullUv
        },
        {
          name: '人均下拉',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.tableDataAllDownPullAvg
        },
        {
          name: '上拉次数',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.tableDataAllUpPullPv
        },
        {
          name: '上拉人数',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.tableDataAllUpPullUv
        },
        {
          name: '人均上拉',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.tableDataAllUpPullAvg
        },
        {
          name: '评论次数',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.tableDataAllCommentPv
        },
        {
          name: '评论人数',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.tableDataAllCommentUv
        },
        {
          name: '收藏次数',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.tableDataAllStorePv
        },
        {
          name: '收藏人数',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.tableDataAllStoreUv
        },
        {
          name: '分享次数',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.tableDataAllSharePv
        },
        {
          name: '分享人数',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.tableDataAllShareUv
        },
        {
          name: '视频曝光量',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.tableDataAllVideoExpo
        },
        {
          name: '人均视频观看比例',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.tableDataAllVideoPlayRateAvg
        }
      ],
      grid: {
        top: '20%',
        left: '2%',
        right: '2%',
        bottom: '3%',
        containLabel: true
      }
    };
    myChart = echarts.init(document.getElementById('headlineArea'));
    myChart.setOption(option);
  },
  mounted () {
        window.onresize = function(){
          myChart.resize();
        }
   }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
/*h1, h2 {
  font-weight: normal;
}

ul {
  list-style-type: none;
  padding: 0;
}

li {
  display: inline-block;
  margin: 0 10px;
}

a {
  color: #42b983;
}*/
</style>
