<template>
  <!-- 分组汇总页面 -->
  <div class="animated fadeIn">
    <div class="card">
      <div class="card-block">
        <div class="row">
          <div class="col-sm-5">
            <h4 class="card-title">分组汇总曲线图</h4>
            <div class="small text-muted"></div>
          </div><!--/.col-->
        </div><!--/.row-->
         <div id="manufactureArea" style="width: 100%; height: 400px; margin: 0 auto;text-align: -webkit-center;"></div>
      </div>
    </div><!--/.card-->
    <div class="row" style="margin-bottom:20px">
      <div id="wholeTable" style="width: 98%; margin: 0 auto">
      <el-row style="margin-bottom: 10px ">
        <el-col :span="19">
          <el-pagination :total="tableDataAll.length" :page-size="pageSize" :page-sizes="[5, 10, 15, 20]" :current-page="pageCurr"
          layout="total, sizes, prev, pager, next, jumper" @size-change="handleSizeChange" @current-change="handleCurrentChange"></el-pagination>
        </el-col>
        <el-col :span="3" style="margin-top: -4px">
          <el-date-picker type="daterange" placeholder="选择日期范围" :clearable="false" v-model="input" @change="handleChange"></el-date-picker>
        </el-col>
      </el-row>
      <el-table v-loading="isLoading"   element-loading-text="拼命加载中" :data="tableData" :row-class-name="tableRowClassName">
        <el-table-column align="center" v-for="item in columns" :prop="item.prop" :label="item.label" :width="item.width" sortable></el-table-column>
      </el-table>
      <el-table v-loading="isLoading"   element-loading-text="拼命加载中" :data="tableDataB" :row-class-name="tableRowClassName">
        <el-table-column align="center" v-for="item in columns" :prop="item.prop" :label="item.label" :min-width="item.width" sortable></el-table-column>
      </el-table>
    </div>
  </div>
  </div><!--/.row-->
</template>

<script>
import echarts from 'echarts'
var input = '',
  startDate = '',
  endDate = '',
  pageSize = 10,
  pageCurr = 1,
  myChart,
  columns = [
    {
      prop: 'date',
      label: '日期',
      width: '120px'
    },
    {
      prop: 'manuGroup',
      label: '厂商分组',
      width: '80px'
    },
    {
      prop: 'dau',
      label: '活跃用户',
      width: '120px'
    },
    {
      prop: 'newUser',
      label: '新增用户',
      width: '100px'
    },
    {
      prop: 'newUserRetain7',
      label: '7日留存',
      width: '100px'
    },
    {
      prop: 'newUserRetain1',
      label: '次日留存',
      width: '100px'
    },
    {
      prop: 'ev',
      label: 'EV',
      width: '120px'
    },
    {
      prop: 'euv',
      label: 'EUV',
      width: '110px'
    },
    {
      prop: 'ev_avg',
      label: '人均EV',
      width: '100px'
    },
    {
      prop: 'pv',
      label: '阅读PV',
      width: '120px'
    },
    {
      prop: 'ctr',
      label: '转化率',
      width: '100px'
    },
    {
      prop: 'uv',
      label: '阅读UV',
      width: '110px'
    },
    {
      prop: 'pv_avg',
      label: '人均阅读PV',
      width: '100px'
    },
    {
      prop: 'duration_avg',
      label: '人均停留时长（min）',
      width: '120px'
    },
    {
      prop: 'share',
      label: '分享次数',
      width: '100px'
    },
    {
      prop: 'share_rate',
      label: '分享率',
      width: '100px'
    },
    {
      prop: 'store',
      label: '收藏次数',
      width: '100px'
    },
    {
      prop: 'store_rate',
      label: '收藏率',
      width: '100px'
    },
    {
      prop: 'comment',
      label: '评论次数',
      width: '100px'
    },
    {
      prop: 'comment_rate',
      label: '评论率',
      width: '100px'
    }
  ],
  tableData = [],
  tableDataAll = [],
  tableDataAllDate = [],
  tableDataAllDau = [],
  tableDataAllNewUser = [],
  tableDataAllNewUserRetain7 = [],
  tableDataAllNewUserRetain1 = [],
  tableDataAllEv = [],
  tableDataAllEuv = [],
  tableDataAllEv_avg = [],
  tableDataAllPv = [],
  tableDataAllCtr = [],
  tableDataAllUv = [],
  tableDataAllPv_avg = [],
  tableDataAllDuration_avg = [],
  tableDataAllShare = [],
  tableDataAllShare_rate = [],
  tableDataAllStore = [],
  tableDataAllStore_rate = [],
  tableDataAllComment = [],
  tableDataAllComment_rate = [],
  tableDataB = [],
  tableDataAllB = [],
  tableDataAllDateB = [],
  tableDataAllDauB = [],
  tableDataAllNewUserB = [],
  tableDataAllNewUserRetain7B = [],
  tableDataAllNewUserRetain1B = [],
  tableDataAllEvB = [],
  tableDataAllEuvB = [],
  tableDataAllEv_avgB = [],
  tableDataAllPvB = [],
  tableDataAllCtrB = [],
  tableDataAllUvB = [],
  tableDataAllPv_avgB = [],
  tableDataAllDuration_avgB = [],
  tableDataAllShareB = [],
  tableDataAllShare_rateB = [],
  tableDataAllStoreB = [],
  tableDataAllStore_rateB = [],
  tableDataAllCommentB = [],
  tableDataAllComment_rateB = [];
export default {
  data () {
    return {
      isLoading: false,
      input: input,
      startDate: startDate,
      endDate: endDate,
      pageSize: pageSize,
      pageCurr: pageCurr,
      columns: columns,
      tableData: tableData,
      tableDataAll: tableDataAll,
      tableDataAllDate: tableDataAllDate,
      tableDataAllDau: tableDataAllDau,
      tableDataAllNewUser: tableDataAllNewUser,
      tableDataAllNewUserRetain7: tableDataAllNewUserRetain7,
      tableDataAllNewUserRetain1: tableDataAllNewUserRetain1,
      tableDataAllEv: tableDataAllEv,
      tableDataAllEuv: tableDataAllEuv,
      tableDataAllEv_avg: tableDataAllEv_avg,
      tableDataAllPv: tableDataAllPv,
      tableDataAllCtr: tableDataAllCtr,
      tableDataAllUv: tableDataAllUv,
      tableDataAllPv_avg: tableDataAllPv_avg,
      tableDataAllDuration_avg: tableDataAllDuration_avg,
      tableDataAllShare: tableDataAllShare,
      tableDataAllShare_rate: tableDataAllShare_rate,
      tableDataAllStore: tableDataAllStore,
      tableDataAllStore_rate: tableDataAllStore_rate,
      tableDataAllComment: tableDataAllComment,
      tableDataAllComment_rate: tableDataAllComment_rate,
      tableDataB: tableDataB,
      tableDataAllB: tableDataAllB,
      tableDataAllDateB: tableDataAllDateB,
      tableDataAllDauB: tableDataAllDauB,
      tableDataAllNewUserB: tableDataAllNewUserB,
      tableDataAllNewUserRetain7B: tableDataAllNewUserRetain7B,
      tableDataAllNewUserRetain1B: tableDataAllNewUserRetain1B,
      tableDataAllEvB: tableDataAllEvB,
      tableDataAllEuvB: tableDataAllEuvB,
      tableDataAllEv_avgB: tableDataAllEv_avgB,
      tableDataAllPvB: tableDataAllPvB,
      tableDataAllCtrB: tableDataAllCtrB,
      tableDataAllUvB: tableDataAllUvB,
      tableDataAllPv_avgB: tableDataAllPv_avgB,
      tableDataAllDuration_avgB: tableDataAllDuration_avgB,
      tableDataAllShareB: tableDataAllShareB,
      tableDataAllShare_rateB: tableDataAllShare_rateB,
      tableDataAllStoreB: tableDataAllStoreB,
      tableDataAllStore_rateB: tableDataAllStore_rateB,
      tableDataAllCommentB: tableDataAllCommentB,
      tableDataAllComment_rateB: tableDataAllComment_rateB
    }
  },
  methods: {
    // 选择
    handleChange(val) {
      this.startDate = val.slice(0, 10);
      this.endDate = val.slice(13, 23);
      this.getJSON();
    },
    // 分页
    handleSizeChange(val) {
      this.pageSize = val;
      this.pageCurr = 1;
      tableData.splice(0, tableData.length);
      for (var i = 0; i < val; i++) {
        var line = tableDataAll[i];
        line['dau'] = line['dau'].toLocaleString();
        line['newUser'] = line['newUser'].toLocaleString();
        line['ev'] = line['ev'].toLocaleString();
        line['euv'] = line['euv'].toLocaleString();
        line['ev_avg'] = line['ev_avg'].toLocaleString();
        line['pv'] = line['pv'].toLocaleString();
        line['uv'] = line['uv'].toLocaleString();
        line['pv_avg'] = line['pv_avg'].toLocaleString();
        line['duration_avg'] = line['duration_avg'].toLocaleString();
        line['share'] = line['share'].toLocaleString();
        line['store'] = line['store'].toLocaleString();
        line['comment'] = line['comment'].toLocaleString();
        tableData.push(tableDataAll[i]);
      }
      tableDataB.splice(0, tableDataB.length);
      for (var i = 0; i < val; i++) {
        var line = tableDataAllB[i];
        line['dau'] = line['dau'].toLocaleString();
        line['newUser'] = line['newUser'].toLocaleString();
        line['ev'] = line['ev'].toLocaleString();
        line['euv'] = line['euv'].toLocaleString();
        line['ev_avg'] = line['ev_avg'].toLocaleString();
        line['pv'] = line['pv'].toLocaleString();
        line['uv'] = line['uv'].toLocaleString();
        line['pv_avg'] = line['pv_avg'].toLocaleString();
        line['duration_avg'] = line['duration_avg'].toLocaleString();
        line['share'] = line['share'].toLocaleString();
        line['store'] = line['store'].toLocaleString();
        line['comment'] = line['comment'].toLocaleString();
        tableDataB.push(tableDataAllB[i]);
      }
    },
    // 换页
    handleCurrentChange(val) {
      this.pageCurr = val;
      tableData.splice(0, tableData.length);
      var end = (tableDataAll.length > (this.pageCurr)*(this.pageSize)) ? (this.pageCurr)*(this.pageSize) : tableDataAll.length;
      for (var i = (this.pageCurr-1)*(this.pageSize); i < end; i++) {
        var line = tableDataAll[i];
        line['dau'] = line['dau'].toLocaleString();
        line['newUser'] = line['newUser'].toLocaleString();
        line['ev'] = line['ev'].toLocaleString();
        line['euv'] = line['euv'].toLocaleString();
        line['ev_avg'] = line['ev_avg'].toLocaleString();
        line['pv'] = line['pv'].toLocaleString();
        line['uv'] = line['uv'].toLocaleString();
        line['pv_avg'] = line['pv_avg'].toLocaleString();
        line['duration_avg'] = line['duration_avg'].toLocaleString();
        line['share'] = line['share'].toLocaleString();
        line['store'] = line['store'].toLocaleString();
        line['comment'] = line['comment'].toLocaleString();
        tableData.push(tableDataAll[i]);
      }
      tableDataB.splice(0, tableDataB.length);
      var end = (tableDataAllB.length > (this.pageCurr)*(this.pageSize)) ? (this.pageCurr)*(this.pageSize) : tableDataAllB.length;
      for (var i = (this.pageCurr-1)*(this.pageSize); i < end; i++) {
        var line = tableDataAllB[i];
        line['dau'] = line['dau'].toLocaleString();
        line['newUser'] = line['newUser'].toLocaleString();
        line['ev'] = line['ev'].toLocaleString();
        line['euv'] = line['euv'].toLocaleString();
        line['ev_avg'] = line['ev_avg'].toLocaleString();
        line['pv'] = line['pv'].toLocaleString();
        line['uv'] = line['uv'].toLocaleString();
        line['pv_avg'] = line['pv_avg'].toLocaleString();
        line['duration_avg'] = line['duration_avg'].toLocaleString();
        line['share'] = line['share'].toLocaleString();
        line['store'] = line['store'].toLocaleString();
        line['comment'] = line['comment'].toLocaleString();
        tableDataB.push(tableDataAllB[i]);
      }
    },
    tableRowClassName(row, index) {
      if (index%2 != 0) {
        return 'odd-row';
      } else if (index%2 == 0) {
        return 'even-row';
      }
      return '';
    },
    getDay: function (day) {
      var today = new Date();
      var target = today.getTime()+1000*60*60*24*day;
      today.setTime(target);
      var year = today.getFullYear();
      var month = today.getMonth();
      var date = today.getDate();
      month = this.addZero(month+1);
      date = this.addZero(date);
      return year.toString()+'-'+month.toString()+'-'+date.toString();
    },
    addZero: function (time) {
      if (time.toString().length == 1) {
        time = '0'+time;
      }
      return time;
    },
    getJSON: function () {
      this.isLoading = true;
      if ((this.startDate) && (this.endDate)) {
      } else {
        this.startDate = this.getDay(-31);
        this.endDate = this.getDay(0);
      }
      var url = 'http://10.80.128.150:58080/batch/manu_stats/manu_group?startDate='+this.startDate+'&endDate='+this.endDate+'&group=A';
      this.$http.get(url).then((response) => {
        this.isLoading = false;
        tableDataAll.splice(0, tableDataAll.length);
        tableDataAllDate.splice(0, tableDataAllDate.length);
        tableDataAllDau.splice(0, tableDataAllDau.length);
        tableDataAllNewUser.splice(0, tableDataAllNewUser.length);
        tableDataAllNewUserRetain7.splice(0, tableDataAllNewUserRetain7.length);
        tableDataAllNewUserRetain1.splice(0, tableDataAllNewUserRetain1.length);
        tableDataAllEv.splice(0, tableDataAllEv.length);
        tableDataAllEuv.splice(0, tableDataAllEuv.length);
        tableDataAllEv_avg.splice(0, tableDataAllEv_avg.length);
        tableDataAllPv.splice(0, tableDataAllPv.length);
        tableDataAllCtr.splice(0, tableDataAllCtr.length);
        tableDataAllUv.splice(0, tableDataAllUv.length);
        tableDataAllPv_avg.splice(0, tableDataAllPv_avg.length);
        tableDataAllDuration_avg.splice(0, tableDataAllDuration_avg.length);
        tableDataAllShare.splice(0, tableDataAllShare.length);
        tableDataAllShare_rate.splice(0, tableDataAllShare_rate.length);
        tableDataAllStore.splice(0, tableDataAllStore.length);
        tableDataAllStore_rate.splice(0, tableDataAllStore_rate.length);
        tableDataAllComment.splice(0, tableDataAllComment.length);
        tableDataAllComment_rate.splice(0, tableDataAllComment_rate.length);
        var temps = response.data;
        for (var i in temps) {
          var temp = temps[i];
          var line = {};
          line['date'] = temp['date'];
          line['manuGroup'] = temp['manuGroup'].toUpperCase();
          line['dau'] = temp['dau'];
          line['newUser'] = temp['newUser'];
          line['newUserRetain7'] = (temp['newUserRetain7']*100).toFixed(3)+'%';
          line['newUserRetain1'] = (temp['newUserRetain1']*100).toFixed(3)+'%';
          line['ev'] = temp['ev'];
          line['euv'] = temp['euv'];
          line['ev_avg'] = temp['ev_avg'].toFixed(3);
          line['pv'] = temp['pv'];
          line['ctr'] = (temp['ctr']*100).toFixed(3)+'%';
          line['uv'] = temp['uv'];
          line['pv_avg'] = temp['pv_avg'].toFixed(3);
          line['duration_avg'] = temp['duration_avg'].toFixed(3);
          line['share'] = temp['share'];
          line['share_rate'] = (temp['share_rate']*100).toFixed(3)+'%';
          line['store'] = temp['store'];
          line['store_rate'] = (temp['store_rate']*100).toFixed(3)+'%';
          line['comment'] = temp['comment'];
          line['comment_rate'] = (temp['comment_rate']*100).toFixed(3)+'%';
          tableDataAll.unshift(line);
          tableDataAllDate.push(line['date']);
          tableDataAllDau.push(line['dau']);
          tableDataAllNewUser.push(line['newUser']);
          tableDataAllNewUserRetain7.push(parseFloat(line['newUserRetain7']));
          tableDataAllNewUserRetain1.push(parseFloat(line['newUserRetain1']));
          tableDataAllEv.push(line['ev']);
          tableDataAllEuv.push(line['euv']);
          tableDataAllEv_avg.push(line['ev_avg']);
          tableDataAllPv.push(line['pv']);
          tableDataAllCtr.push(parseFloat(line['ctr']));
          tableDataAllUv.push(line['uv']);
          tableDataAllPv_avg.push(line['pv_avg']);
          tableDataAllDuration_avg.push(line['duration_avg']);
          tableDataAllShare.push(line['share']);
          tableDataAllShare_rate.push(parseFloat(line['share_rate']));
          tableDataAllStore.push(line['store']);
          tableDataAllStore_rate.push(parseFloat(line['store_rate']));
          tableDataAllComment.push(line['comment']);
          tableDataAllComment_rate.push(parseFloat(line['comment_rate']));
        }
        tableData.splice(0, tableData.length);
        if (tableDataAll.length < 5) {
          this.pageSize = tableDataAll.length;
        } else {
          this.pageSize = 10;
        }
        for (var i = 0; i < this.pageSize; i++) {
          var line = tableDataAll[i];
          line['dau'] = line['dau'].toLocaleString();
          line['newUser'] = line['newUser'].toLocaleString();
          line['ev'] = line['ev'].toLocaleString();
          line['euv'] = line['euv'].toLocaleString();
          line['ev_avg'] = line['ev_avg'].toLocaleString();
          line['pv'] = line['pv'].toLocaleString();
          line['uv'] = line['uv'].toLocaleString();
          line['pv_avg'] = line['pv_avg'].toLocaleString();
          line['duration_avg'] = line['duration_avg'].toLocaleString();
          line['share'] = line['share'].toLocaleString();
          line['store'] = line['store'].toLocaleString();
          line['comment'] = line['comment'].toLocaleString();
          tableData.push(tableDataAll[i]);
        }
      }).then(this.getJSONB)
    },
    getJSONB: function () {
      if ((this.startDate) && (this.endDate)) {
      } else {
        this.startDate = this.getDay(-10);
        this.endDate = this.getDay(0);
      }
      var url = 'http://10.80.128.150:58080/batch/manu_stats/manu_group?startDate='+this.startDate+'&endDate='+this.endDate+'&group=B';
      this.$http.get(url).then((response) => {
        tableDataAllB.splice(0, tableDataAllB.length);
        tableDataAllDateB.splice(0, tableDataAllDateB.length);
        tableDataAllDauB.splice(0, tableDataAllDauB.length);
        tableDataAllNewUserB.splice(0, tableDataAllNewUserB.length);
        tableDataAllNewUserRetain7B.splice(0, tableDataAllNewUserRetain7B.length);
        tableDataAllNewUserRetain1B.splice(0, tableDataAllNewUserRetain1B.length);
        tableDataAllEvB.splice(0, tableDataAllEvB.length);
        tableDataAllEuvB.splice(0, tableDataAllEuvB.length);
        tableDataAllEv_avgB.splice(0, tableDataAllEv_avgB.length);
        tableDataAllPvB.splice(0, tableDataAllPvB.length);
        tableDataAllCtrB.splice(0, tableDataAllCtrB.length);
        tableDataAllUvB.splice(0, tableDataAllUvB.length);
        tableDataAllPv_avgB.splice(0, tableDataAllPv_avgB.length);
        tableDataAllDuration_avgB.splice(0, tableDataAllDuration_avgB.length);
        tableDataAllShareB.splice(0, tableDataAllShareB.length);
        tableDataAllShare_rateB.splice(0, tableDataAllShare_rateB.length);
        tableDataAllStoreB.splice(0, tableDataAllStoreB.length);
        tableDataAllStore_rateB.splice(0, tableDataAllStore_rateB.length);
        tableDataAllCommentB.splice(0, tableDataAllCommentB.length);
        tableDataAllComment_rateB.splice(0, tableDataAllComment_rateB.length);
        var temps = response.data;
        for (var i in temps) {
          var temp = temps[i];
          var line = {};
          line['date'] = temp['date'];
          line['manuGroup'] = temp['manuGroup'].toUpperCase();
          line['dau'] = temp['dau'];
          line['newUser'] = temp['newUser'];
          line['newUserRetain7'] = (temp['newUserRetain7']*100).toFixed(3)+'%';
          line['newUserRetain1'] = (temp['newUserRetain1']*100).toFixed(3)+'%';
          line['ev'] = temp['ev'];
          line['euv'] = temp['euv'];
          line['ev_avg'] = temp['ev_avg'].toFixed(3);
          line['pv'] = temp['pv'];
          line['ctr'] = (temp['ctr']*100).toFixed(3)+'%';
          line['uv'] = temp['uv'];
          line['pv_avg'] = temp['pv_avg'].toFixed(3);
          line['duration_avg'] = temp['duration_avg'].toFixed(3);
          line['share'] = temp['share'];
          line['share_rate'] = (temp['share_rate']*100).toFixed(3)+'%';
          line['store'] = temp['store'];
          line['store_rate'] = (temp['store_rate']*100).toFixed(3)+'%';
          line['comment'] = temp['comment'];
          line['comment_rate'] = (temp['comment_rate']*100).toFixed(3)+'%';
          tableDataAllB.unshift(line);
          tableDataAllDateB.push(line['date']);
          tableDataAllDauB.push(line['dau']);
          tableDataAllNewUserB.push(line['newUser']);
          tableDataAllNewUserRetain7B.push(parseFloat(line['newUserRetain7']));
          tableDataAllNewUserRetain1B.push(parseFloat(line['newUserRetain1']));
          tableDataAllEvB.push(line['ev']);
          tableDataAllEuvB.push(line['euv']);
          tableDataAllEv_avgB.push(line['ev_avg']);
          tableDataAllPvB.push(line['pv']);
          tableDataAllCtrB.push(parseFloat(line['ctr']));
          tableDataAllUvB.push(line['uv']);
          tableDataAllPv_avgB.push(line['pv_avg']);
          tableDataAllDuration_avgB.push(line['duration_avg']);
          tableDataAllShareB.push(line['share']);
          tableDataAllShare_rateB.push(parseFloat(line['share_rate']));
          tableDataAllStoreB.push(line['store']);
          tableDataAllStore_rateB.push(parseFloat(line['store_rate']));
          tableDataAllCommentB.push(line['comment']);
          tableDataAllComment_rateB.push(parseFloat(line['comment_rate']));
        }
        tableDataB.splice(0, tableDataB.length);
        if (tableDataAllB.length < 5) {
          this.pageSize = tableDataAllB.length;
        } else {
          this.pageSize = 10;
        }
        for (var i = 0; i < this.pageSize; i++) {
          var line = tableDataAllB[i];
          line['dau'] = line['dau'].toLocaleString();
          line['newUser'] = line['newUser'].toLocaleString();
          line['ev'] = line['ev'].toLocaleString();
          line['euv'] = line['euv'].toLocaleString();
          line['ev_avg'] = line['ev_avg'].toLocaleString();
          line['pv'] = line['pv'].toLocaleString();
          line['uv'] = line['uv'].toLocaleString();
          line['pv_avg'] = line['pv_avg'].toLocaleString();
          line['duration_avg'] = line['duration_avg'].toLocaleString();
          line['share'] = line['share'].toLocaleString();
          line['store'] = line['store'].toLocaleString();
          line['comment'] = line['comment'].toLocaleString();
          tableDataB.push(tableDataAllB[i]);
        }
      })
    }
  },
  created: function () {
    this.getJSON();
  },
  beforeUpdate: function () {
    var option = {
      legend: {
        left: 'center',
        data: ['A组活跃用户', 'A组新增用户', 'A组7日留存', 'A组次日留存', 'A组EV', 'A组EUV', 'A组人均EV', 'A组阅读PV', 'A组转化率', 'A组阅读UV', 'A组人均阅读PV', 'A组人均停留时长（min）', 'A组分享次数', 'A组分享率', 'A组收藏次数', 'A组收藏率', 'A组评论次数', 'A组评论率', 'B组活跃用户', 'B组新增用户', 'B组7日留存', 'B组次日留存', 'B组EV', 'B组EUV', 'B组人均EV', 'B组阅读PV', 'B组转化率', 'B组阅读UV', 'B组人均阅读PV', 'B组人均停留时长（min）', 'B组分享次数', 'B组分享率', 'B组收藏次数', 'B组收藏率', 'B组评论次数', 'B组评论率'],
        selectedMode: 'multiple',
        selected: {  
                    'A组活跃用户': false,  
                    'A组新增用户': true,  
                    'A组7日留存': false,  
                    'A组次日留存': false,  
                    'A组EV': false,  
                     'A组EUV': false,  
                    'A组人均EV': false, 
                    'A组阅读PV': false,  
                    'A组转化率': false,  
                    'A组阅读UV': false,  
                    'A组人均阅读PV': false,  
                    'A组人均停留时长（min）': false, 
                    'A组分享次数': false,  
                    'A组分享率': false,
                    'A组收藏次数': false,  
                    'A组收藏率': false,  
                    'A组评论次数': false,  
                    'A组评论率': false,  
                    'B组活跃用户': false,  
                    'B组新增用户': true,  
                    'B组7日留存': false,  
                    'B组次日留存': false,  
                    'B组EV': false,  
                     'B组EUV': false,  
                    'B组人均EV': false, 
                    'B组阅读PV': false,  
                    'B组转化率': false,  
                    'B组阅读UV': false,  
                    'B组人均阅读PV': false,  
                    'B组人均停留时长（min）': false, 
                    'B组分享次数': false,  
                    'B组分享率': false,
                    'B组收藏次数': false,  
                    'B组收藏率': false,  
                    'B组评论次数': false,  
                    'B组评论率': false  
                }  
      },
      tooltip: {
        trigger: 'axis',
        position: function (pt) {
          return [pt[0]-100, '10%'];
        }
      },
      grid: {
        top: '30%',
        left: '2%',
        right: '2%',
        bottom: '3%',
        containLabel: true
      },
      toolbox: {
        right:'2%',
        top:'20%',
        show: true,
        feature : {
            mark : {show: true},
            dataZoom : {show: true},
            magicType: {type: ['line', 'bar']},
            restore : {show: true},
            saveAsImage : {show: true}
        }
    },
      xAxis: {
        type: 'category',
        boundaryGap: false,
        data: this.tableDataAllDate
      },
      yAxis: {
        type: 'value',
        boundaryGap: [0, '30%']
      },
      dataZoom: [
        {
          type: 'slider',
          show: true,
          xAxisIndex: [0],
          start: 0,
          end: 100
        },
        {
          type: 'inside',
          xAxisIndex: [0],
          start: 0,
          end: 100
        }
      ],
      series: [
        {
          name: 'A组活跃用户',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.tableDataAllDau
        },
        {
          name: 'A组新增用户',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.tableDataAllNewUser
        },
        {
          name: 'A组7日留存',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.tableDataAllNewUserRetain7
        },
        {
          name: 'A组次日留存',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.tableDataAllNewUserRetain1
        },
        {
          name: 'A组EV',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.tableDataAllEv
        },
        {
          name: 'A组EUV',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.tableDataAllEuv
        },
        {
          name: 'A组人均EV',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.tableDataAllEv_avg
        },
        {
          name: 'A组阅读PV',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.tableDataAllPv
        },
        {
          name: 'A组转化率',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.tableDataAllCtr
        },
        {
          name: 'A组阅读UV',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.tableDataAllUv
        },
        {
          name: 'A组人均阅读PV',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.tableDataAllPv_avg
        },
        {
          name: 'A组人均停留时长（min）',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.tableDataAllDuration_avg
        },
        {
          name: 'A组分享次数',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.tableDataAllShare
        },
        {
          name: 'A组分享率',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.tableDataAllShare_rate
        },
        {
          name: 'A组收藏次数',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.tableDataAllStore
        },
        {
          name: 'A组收藏率',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.tableDataAllStore_rate
        },
        {
          name: 'A组评论次数',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.tableDataAllComment
        },
        {
          name: 'A组评论率',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.tableDataAllComment_rate
        },
        {
          name: 'B组活跃用户',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.tableDataAllDauB
        },
        {
          name: 'B组新增用户',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.tableDataAllNewUserB
        },
        {
          name: 'B组7日留存',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.tableDataAllNewUserRetain7B
        },
        {
          name: 'B组次日留存',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.tableDataAllNewUserRetain1B
        },
        {
          name: 'B组EV',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.tableDataAllEvB
        },
        {
          name: 'B组EUV',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.tableDataAllEuvB
        },
        {
          name: 'B组人均EV',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.tableDataAllEv_avgB
        },
        {
          name: 'B组阅读PV',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.tableDataAllPvB
        },
        {
          name: 'B组转化率',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.tableDataAllCtrB
        },
        {
          name: 'B组阅读UV',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.tableDataAllUvB
        },
        {
          name: 'B组人均阅读PV',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.tableDataAllPv_avgB
        },
        {
          name: 'B组人均停留时长（min）',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.tableDataAllDuration_avgB
        },
        {
          name: 'B组分享次数',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.tableDataAllShareB
        },
        {
          name: 'B组分享率',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.tableDataAllShare_rateB
        },
        {
          name: 'B组收藏次数',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.tableDataAllStoreB
        },
        {
          name: 'B组收藏率',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.tableDataAllStore_rateB
        },
        {
          name: 'B组评论次数',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.tableDataAllCommentB
        },
        {
          name: 'B组评论率',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.tableDataAllComment_rateB
        }
      ]
    };
   myChart = echarts.init(document.getElementById('manufactureArea'));
    myChart.setOption(option);
  },
  mounted () {
        window.onresize = function(){
          myChart.resize();
        }
   }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
/*h1, h2 {
  font-weight: normal;
}

ul {
  list-style-type: none;
  padding: 0;
}

li {
  display: inline-block;
  margin: 0 10px;
}

a {
  color: #42b983;
}*/
</style>
