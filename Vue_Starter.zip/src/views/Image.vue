<template>
  <!-- 用户画像页面 -->
  <div class="animated fadeIn">
    
    <div class="row" style="margin-bottom:20px">
      <div id="wholeTable" style="width: 98%; margin: 0 auto">
      <el-row style="margin-bottom: 10px ">
         <el-col :span="2">
          <el-button type="primary" icon="search" :loading="isLoading" @click="handleClick">搜索</el-button>
        </el-col>
        <el-col :span="18" :offset="1">
          <el-autocomplete placeholder="请输入userkey，点击右侧删除按钮清空搜索历史" style="width: 100%" v-model="input"
          :fetch-suggestions="querySearch" icon="circle-cross" :on-icon-click="handleIconClick"></el-autocomplete>
        </el-col>
      </el-row>
      <el-table   v-loading="isLoading"   element-loading-text="拼命加载中" :default-sort = "{prop: 'key', order: 'ascending'}"   :data="tableData" :row-class-name="tableRowClassName">
        <el-table-column align="center" prop="key" label="key" width="140px" sortable></el-table-column>
        <el-table-column align="center" prop="value" label="value"></el-table-column>
        <el-table-column align="center" prop="desc" label="描述" width="180px"></el-table-column>
        <el-table-column align="center" prop="source" label="来源" width="100px"></el-table-column>
      </el-table>
    </div>
    </div>
  </div><!--/.row-->
</template>

<script>
var 
  input = '',
  history = [],
  tableData = [],
  tableDataAll = [];
export default {
  data () {
    return {
      isLoading: false,
      input: input,
      history: history,
      tableData: tableData,
      tableDataAll: tableDataAll
    }
  },
  methods: {
    open() {
        this.$message({
          message:'没有搜到相关数据',
          duration:2000,
          customClass:'messagetop'
         });
      },
    // 清除
    handleIconClick(ev) {
      this.history.splice(0, this.history.length);
      localStorage.setItem('imageHistory', '');
    },
    // 搜索
    handleClick(ev) {
      var res = localStorage.getItem('imageHistory');
      if (res) {
        if (res.indexOf(this.input) == -1) {
          localStorage.setItem('imageHistory', res+' '+this.input);
        } else {
          var start = res.indexOf(this.input);
          var end = start+this.input.length;
          if (start != 0) {
            start = start-1;
          }
          res = res.slice(0, start)+res.slice(end);
          var arr = res.split(' ');
          this.history.splice(0, this.history.length);
          for (var i in arr) {
            this.history.unshift({"value": arr[i]});
          }
          localStorage.setItem('imageHistory', res+' '+this.input);
        }
      } else {
        localStorage.setItem('imageHistory', this.input);
      }
      this.history.unshift({"value": this.input});
      this.isLoading = true;
      this.getJSON();
      this.isLoading = false;
    },
    // 历史
    querySearch(queryString, cb) {
      if (this.history.length == 0) {
        var res = localStorage.getItem('imageHistory');
        if (res) {
          var arr = res.split(' ');
          for (var i in arr) {
            this.history.unshift({"value": arr[i]});
          }
        }
      }
      cb(this.history);
    },
    tableRowClassName(row, index) {
      if (index%2 != 0) {
        return 'odd-row';
      } else if (index%2 == 0) {
        return 'even-row';
      }
      return '';
    },
    getJSON: function () {
      this.isLoading = true;
      var url = 'http://10.80.128.150:58080/user_portrait?userkey='+this.input;
      var desc = {
        'e': '热点事件',
        's': '优质稿源',
        'ua': '用户活跃度',
        'ub': '自媒体订阅',
        'ui': '算法频道订阅',
        'uk': '正文TAG点击词',
        'umt': '手机型号，品牌',
        'umos': '手机系统',
        'utime': '用户画像更新时间',
        'uver': '客户端版本',
        'uts': '分享',
        'ustore': '收藏',
        'net': '网络状态',
        't1': '文章特征',
        't2': '文章特征',
        't3': '文章特征',
        'vid_t1': '视频特征',
        'vid_t2': '视频特征',
        'vid_t3': '视频特征',
        'slide_t1': '图片特征',
        'slide_t2': '图片特征',
        'slide_t3': '图片特征',
        'last_t1': '文章特征（近两天）',
        'last_t2': '文章特征（近两天）',
        'last_t3': '文章特征（近两天）',
        'search': '搜索',
        'sw_open': '算法频道下用户点击排行',
        'lastitems': '用户近三天最喜爱的三篇内容',
        'likevideo': '是否是视频用户',
        'loc': '地域',
        'generalloc': '长期地域决策信息(常驻地)',
        'sexpand': '优质稿源画像扩展',
        'texpand': '画像兴趣相关扩展',
        'recent_t1': '短期文章特征',
        'recent_t2': '短期文章特征',
        'recent_t3': '短期文章特征',
        'apptype': '客户端类型',
        'pre_gender': '性别预测',
        'general_ub':'用户历史订阅信息',
        'upoi':'用户经纬度位置信息',
        'iphone':'用户手机号',
        'last_utime':'实时画像更新时间',
        'ua_v':'用户阅读活跃度等级'

      };
      var source = {
        'e': '训练',
        's': '训练',
        'ua': '训练',
        'ub': '实时',
        'ui': '实时',
        'uk': '实时',
        'umt': '实时',
        'umos': '实时',
        'utime': '训练',
        'uver': '训练',
        'uts': '实时',
        'ustore': '实时',
        'net': '实时',
        't1': '训练',
        't2': '训练',
        't3': '训练',
        'vid_t1': '训练',
        'vid_t2': '训练',
        'vid_t3': '训练',
        'slide_t1': '训练',
        'slide_t2': '训练',
        'slide_t3': '训练',
        'last_t1': '实时',
        'last_t2': '实时',
        'last_t3': '实时',
        'search': '实时',
        'sw_open': '训练',
        'lastitems': '实时',
        'likevideo': '训练',
        'loc': '实时',
        'generalloc': '训练',
        'sexpand': '训练',
        'texpand': '训练',
        'recent_t1': '训练',
        'recent_t2': '训练',
        'recent_t3': '训练',
        'apptype': '训练',
        'pre_gender': '训练',
        'general_ub':'训练',
        'upoi':'实时  ',
        'iphone':'训练',
        'last_utime':'实时',
        'ua_v':'训练'
      };
      this.$http.get(url).then((response) => {
        this.isLoading = false;
        tableDataAll.splice(0, tableDataAll.length);
        var temp = response.data;
        console.log(temp)
        if(temp!=''){
            for(var i in temp){
            var line = {};
              line['key'] = i;
              line['value'] = temp[i];
              if(desc.hasOwnProperty(i)){
                line['desc'] = desc[i];
              }else{
                line['desc'] = '--';
              }
              if(source.hasOwnProperty(i)){
                line['source'] = source[i];
              }else{
                line['source'] = '--';
              }
              tableDataAll.unshift(line);
          }
        }else{
          this.open()
        }
        
        

        // for (var i = 0; i < key.length; i++) {
        //   var line = {};
        //   line['key'] = key[i];
        //   line['value'] = value[i];
        //   line['desc'] = desc[i];

        //   tableDataAll.push(line);
        // }
        tableData.splice(0, tableData.length);
        for (var i = 0; i < tableDataAll.length; i++) {
          tableData.push(tableDataAll[i]);
        }
      })
    }
  },
  mounted: function () {
    var _this = this;
    document.getElementsByTagName('input')[0].onkeydown = function (e) {
      if (e.keyCode == 13) {
        _this.handleClick();
      }
    };
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style >
.messagetop{
  top: 30%!important;
}
</style>
