<template>
  <!-- 频道（540）页面 -->
   <div class="animated fadeIn">
    <div class="card">
      <div class="card-block">
        <div class="row">
          <div class="col-sm-5">
            <h4 class="card-title">频道（540）曲线图</h4>
            <div class="small text-muted"></div>
          </div><!--/.col-->
        </div><!--/.row-->
         <div id="channelArea" style="width: 100%; height: 400px; margin: 0 auto;text-align: -webkit-center;"></div>
      </div>
    </div><!--/.card-->
    <div class="row" style="margin-bottom:20px">
      <div id="wholeTable" style="width: 98%; margin: 0 auto">
      <el-row style="margin-bottom: -10px ">
        <el-col :span="14">
          <el-pagination :total="tableDataAll.length" :page-size="pageSize" :page-sizes="[5, 10, 15, 20]" :current-page="pageCurr"
          layout="total, sizes, prev, pager, next, jumper" @size-change="handleSizeChange" @current-change="handleCurrentChange"></el-pagination>
        </el-col>
        <el-col :span="2" :offset="1" style="margin-top: -4px">
          <el-button type="text" icon="upload2" @click="handleClick">导出</el-button>
        </el-col>
        <el-col :span="3" style="margin-top: -4px">
          <el-select placeholder="频道" filterable v-model="option" @change="handleSelectChange">
            <el-option v-for="item in options" :label="item.label" :value="item.value"></el-option>
          </el-select>
        </el-col>
        <el-col :span="3" style="margin-top: -4px">
          <el-date-picker type="daterange" placeholder="选择日期范围" :clearable="false" v-model="input" @change="handleChange"></el-date-picker>
        </el-col>
      </el-row>
      <el-tooltip  effect="dark" placement="bottom" >
        <div slot="content">文章更新量：当日曝光，但未在之前5日内曝光的文章<br/>曝光次数：该频道文章曝光次数<br/>曝光人数：该频道文章曝光的用户数<br/>频道页UV：频道首页停留3秒以上的用户<br/>转化率：阅读PV/EV<br/>分享率：分享次数/EV<br/></div>
      <i class="el-icon-warning" style="float: right;margin:7px 15px"></i>
      </el-tooltip>
        <el-table v-loading="isLoading"   element-loading-text="拼命加载中"  stripe :data="tableData" :row-class-name="tableRowClassName">
          <el-table-column align="center" v-for="item in columns" :prop="item.prop" :label="item.label" :min-width="item.width" sortable>
          </el-table-column>
        </el-table>
    </div>
    </div>
  </div><!--/.row-->

</template>

<script>
import echarts from 'echarts'
var save = [],
  option = '',
  options = [],
  input = '',
  startDate = '',
  endDate = '',
  pageSize = 10,
  pageCurr = 1,
  myChart,
  columns = [
    {
      prop: 'date',
      label: '日期',
      width: '120px'
    },
    {
      prop: 'channel',
      label: '频道',
      width: '90px'
    },
    {
      prop: 'newArticle',
      label: '文章更新量',
      width: '90px'
    },
    {
      prop: 'ev',
      label: '曝光次数',
      width: '120px'
    },
    {
      prop: 'euv',
      label: '曝光人数',
      width: '100px'
    },
    {
      prop: 'ev_avg',
      label: '人均曝光次数',
      width: '120px'
    },
    {
      prop: 'pv',
      label: '文章阅读',
      width: '120px'
    },
    {
      prop: 'ctr',
      label: '转化率',
      width: '100px'
    },
    {
      prop: 'ch_pv',
      label: '频道页pv',
      width: '120px'
    },
    {
      prop: 'ch_uv',
      label: '频道页uv',
      width: '120px'
    },
    {
      prop: 'pv_avg',
      label: '人均阅读文章pv',
      width: '100px'
    },
    {
      prop: 'ch_pv_avg',
      label: '人均频道页pv',
      width: '100px'
    },
    {
      prop: 'duration_avg',
      label: '人均频道浏览时长（分）',
      width: '100px'
    },
    {
      prop: 'share',
      label: '分享次数',
      width: '90px'
    },
    {
      prop: 'share_rate',
      label: '分享率',
      width: '90px'
    },
    {
      prop: 'store',
      label: '收藏次数',
      width: '90px'
    },
    {
      prop: 'comment',
      label: '评论次数',
      width: '90px'
    }
  ],
  tableData = [],
  tableDataAll = [],
  tableDataAllDate = [],
  tableDataAllNewArticle = [],
  tableDataAllEv = [],
  tableDataAllEuv = [],
  tableDataAllEv_avg = [],
  tableDataAllPv = [],
  tableDataAllCtr = [],
  tableDataAllCh_pv = [],
  tableDataAllCh_uv = [],
  tableDataAllPv_avg = [],
  tableDataAllCh_pv_avg = [],
  tableDataAllDuration_avg = [],
  tableDataAllShare = [],
  tableDataAllShare_rate = [],
  tableDataAllStore = [],
  tableDataAllComment = [];
export default {
  data () {
    return {
      isLoading: false,
      save: save,
      option: option,
      options: options,
      input: input,
      startDate: startDate,
      endDate: endDate,
      pageSize: pageSize,
      pageCurr: pageCurr,
      columns: columns,
      tableData: tableData,
      tableDataAll: tableDataAll,
      tableDataAllDate: tableDataAllDate,
      tableDataAllNewArticle: tableDataAllNewArticle,
      tableDataAllEv: tableDataAllEv,
      tableDataAllEuv: tableDataAllEuv,
      tableDataAllEv_avg: tableDataAllEv_avg,
      tableDataAllPv: tableDataAllPv,
      tableDataAllCtr: tableDataAllCtr,
      tableDataAllCh_pv: tableDataAllCh_pv,
      tableDataAllCh_uv: tableDataAllCh_uv,
      tableDataAllPv_avg: tableDataAllPv_avg,
      tableDataAllCh_pv_avg: tableDataAllCh_pv_avg,
      tableDataAllDuration_avg: tableDataAllDuration_avg,
      tableDataAllShare: tableDataAllShare,
      tableDataAllShare_rate: tableDataAllShare_rate,
      tableDataAllStore: tableDataAllStore,
      tableDataAllComment: tableDataAllComment
    }
  },
  methods: {
    //download
    handleClick(ev) {
      var url = 'http://10.80.128.150:58080/channel/channel540Data/excel?startDate='+this.startDate+'&endDate='+this.endDate+'&col='+encodeURI(JSON.stringify(columns));
      console.log(url);
      window.open(url);
    },
    // 选择
    handleSelectChange() {
      tableDataAllDate.splice(0, tableDataAllDate.length);
      tableDataAllNewArticle.splice(0, tableDataAllNewArticle.length);
      tableDataAllEv.splice(0, tableDataAllEv.length);
      tableDataAllEuv.splice(0, tableDataAllEuv.length);
      tableDataAllEv_avg.splice(0, tableDataAllEv_avg.length);
      tableDataAllPv.splice(0, tableDataAllPv.length);
      tableDataAllCtr.splice(0, tableDataAllCtr.length);
      tableDataAllCh_pv.splice(0, tableDataAllCh_pv.length);
      tableDataAllCh_uv.splice(0, tableDataAllCh_uv.length);
      tableDataAllPv_avg.splice(0, tableDataAllPv_avg.length);
      tableDataAllCh_pv_avg.splice(0, tableDataAllCh_pv_avg.length);
      tableDataAllDuration_avg.splice(0, tableDataAllDuration_avg.length);
      tableDataAllShare.splice(0, tableDataAllShare.length);
      tableDataAllShare_rate.splice(0, tableDataAllShare_rate.length);
      tableDataAllStore.splice(0, tableDataAllStore.length);
      tableDataAllComment.splice(0, tableDataAllComment.length);
      tableDataAllEv.length=0
      console.log(tableDataAllEv)
      console.log(tableDataAllDate)
      var count = 0;
      console.log(save)
      for (var i in save) {
        var line = save[i];
        if (line['channel'] == this.option) {
          tableDataAll.push(line);
          count++;
          tableDataAllDate.unshift(line['date']);
          tableDataAllNewArticle.unshift(line['newArticle']);
          tableDataAllEv.unshift(line['ev']);
          tableDataAllEuv.unshift(line['euv']);
          tableDataAllEv_avg.unshift(line['ev_avg']);
          tableDataAllPv.unshift(line['pv']);
          tableDataAllCtr.unshift(parseFloat(line['ctr']));
          tableDataAllCh_pv.unshift(line['ch_pv']);
          tableDataAllCh_uv.unshift(line['ch_uv']);
          tableDataAllPv_avg.unshift(line['pv_avg']);
          tableDataAllCh_pv_avg.unshift(line['ch_pv_avg']);
          tableDataAllDuration_avg.unshift(line['duration_avg']);
          tableDataAllShare.unshift(line['share']);
          tableDataAllShare_rate.unshift(parseFloat(line['share_rate']));
          tableDataAllStore.unshift(line['store']);
          tableDataAllComment.unshift(line['comment']);
        }
      }
      console.log(tableDataAllEv)
      console.log(tableDataAllDate)
      this.pageCurr = 1;
      tableDataAll.splice(0, tableDataAll.length-count);
      tableData.splice(0, tableData.length);
      if (tableDataAll.length < 5) {
        this.pageSize = tableDataAll.length;
      } else {
        this.pageSize = 10;
      }
      for (var i = 0; i < this.pageSize; i++) {
        var line = tableDataAll[i];
        line['newArticle'] = line['newArticle'];
        line['ev'] = line['ev'];
        line['euv'] = line['euv'];
        line['ev_avg'] = line['ev_avg'];
        line['pv'] = line['pv'];
        line['ch_pv'] = line['ch_pv'];
        line['ch_uv'] = line['ch_uv'];
        line['pv_avg'] = line['pv_avg'];
        line['ch_pv_avg'] = line['ch_pv_avg'];
        line['duration_avg'] = line['duration_avg'];
        line['share'] = line['share'];
        line['store'] = line['store'];
        line['comment'] = line['comment'];
        tableData.push(tableDataAll[i]);
      }
      console.log('11111')
      console.log(this.options)
    },
    // 选择
    handleChange(val) {
      this.startDate = val.slice(0, 10);
      this.endDate = val.slice(13, 23);
      this.getJSON();
    },
    // 分页
    handleSizeChange(val) {
      this.pageSize = val;
      this.pageCurr = 1;
      tableData.splice(0, tableData.length);
      console.log(tableDataAll.length)
      console.log(val)
      val=val>=tableDataAll.length?tableDataAll.length:val
      console.log(val)
      for (var i = 0; i < val; i++) {
        var line = tableDataAll[i];
        line['newArticle'] = line['newArticle'];
        line['ev'] = line['ev'];
        line['euv'] = line['euv'];
        line['ev_avg'] = line['ev_avg'];
        line['pv'] = line['pv'];
        line['ch_pv'] = line['ch_pv'];
        line['ch_uv'] = line['ch_uv'];
        line['pv_avg'] = line['pv_avg'];
        line['ch_pv_avg'] = line['ch_pv_avg'];
        line['duration_avg'] = line['duration_avg'];
        line['share'] = line['share'];
        line['store'] = line['store'];
        line['comment'] = line['comment'];
        tableData.push(tableDataAll[i]);
      }
    },
    // 换页
    handleCurrentChange(val) {
      this.pageCurr = val;
      tableData.splice(0, tableData.length);
      var end = (tableDataAll.length > (this.pageCurr)*(this.pageSize)) ? (this.pageCurr)*(this.pageSize) : tableDataAll.length;
      for (var i = (this.pageCurr-1)*(this.pageSize); i < end; i++) {
        var line = tableDataAll[i];
        line['newArticle'] = line['newArticle'];
        line['ev'] = line['ev'];
        line['euv'] = line['euv'];
        line['ev_avg'] = line['ev_avg'];
        line['pv'] = line['pv'];
        line['ch_pv'] = line['ch_pv'];
        line['ch_uv'] = line['ch_uv'];
        line['pv_avg'] = line['pv_avg'];
        line['ch_pv_avg'] = line['ch_pv_avg'];
        line['duration_avg'] = line['duration_avg'];
        line['share'] = line['share'];
        line['store'] = line['store'];
        line['comment'] = line['comment'];
        tableData.push(tableDataAll[i]);
      }
    },
    tableRowClassName(row, index) {
      if (index%2 != 0) {
        return 'odd-row';
      } else if (index%2 == 0) {
        return 'even-row';
      }
      return '';
    },
    getDay: function (day) {
      var today = new Date();
      var target = today.getTime()+1000*60*60*24*day;
      today.setTime(target);
      var year = today.getFullYear();
      var month = today.getMonth();
      var date = today.getDate();
      month = this.addZero(month+1);
      date = this.addZero(date);
      return year.toString()+'-'+month.toString()+'-'+date.toString();
    },
    addZero: function (time) {
      if (time.toString().length == 1) {
        time = '0'+time;
      }
      return time;
    },
    getJSON: function () {
      this.isLoading = true;
      if ((this.startDate) && (this.endDate)) {
      } else {
        this.startDate = this.getDay(-31);
        this.endDate = this.getDay(0);
      }
      var map = new Map();
      var url = 'http://sdk.data.ifeng.com/channel/channel_channel540Data.action?startDate='+this.startDate+'&endDate='+this.endDate;
      this.$http.get(url).then((response) => {
        this.isLoading = false;
        tableDataAll.splice(0, tableDataAll.length);
        var obj = response.data;
        var temps = obj['data'];
        for (var i in temps) {
          var temp = temps[i];
          var line = {};
          line['date'] = temp['date'];
          line['channel'] = temp['channel'];
          line['newArticle'] = temp['newArticle'];
          line['ev'] = temp['ev'];
          line['euv'] = temp['euv'];
          line['ev_avg'] = temp['ev_avg'].toFixed(3);
          line['pv'] = temp['pv'];
          line['ctr'] = (temp['ctr']*100).toFixed(3)+'%';
          line['ch_pv'] = temp['ch_pv'];
          line['ch_uv'] = temp['ch_uv'];
          line['pv_avg'] = temp['pv_avg'].toFixed(3);
          line['ch_pv_avg'] = temp['ch_pv_avg'].toFixed(3);
          line['duration_avg'] = (temp['duration_avg']/60).toFixed(3);
          line['share'] = temp['share'];
          line['share_rate'] = (temp['share_rate']*100).toFixed(3)+'%';
          line['store'] = temp['store'];
          line['comment'] = temp['comment'];
          tableDataAll.push(line);
          if (map.has(temp['channel'])) {
          } else {
            map.set(temp['channel'], 1);
          }
        }
        save = [].concat(tableDataAll);
        map.delete('头条');
        this.options.splice(0, this.options.length);
        for (var key of map.keys()) {
          var option = {
            value: key,
            label: key
          };
          this.options.push(option);
        }
        tableDataAllDate.splice(0, tableDataAllDate.length);
        tableDataAllNewArticle.splice(0, tableDataAllNewArticle.length);
        tableDataAllEv.splice(0, tableDataAllEv.length);
        tableDataAllEuv.splice(0, tableDataAllEuv.length);
        tableDataAllEv_avg.splice(0, tableDataAllEv_avg.length);
        tableDataAllPv.splice(0, tableDataAllPv.length);
        tableDataAllCtr.splice(0, tableDataAllCtr.length);
        tableDataAllCh_pv.splice(0, tableDataAllCh_pv.length);
        tableDataAllCh_uv.splice(0, tableDataAllCh_uv.length);
        tableDataAllPv_avg.splice(0, tableDataAllPv_avg.length);
        tableDataAllCh_pv_avg.splice(0, tableDataAllCh_pv_avg.length);
        tableDataAllDuration_avg.splice(0, tableDataAllDuration_avg.length);
        tableDataAllShare.splice(0, tableDataAllShare.length);
        tableDataAllShare_rate.splice(0, tableDataAllShare_rate.length);
        tableDataAllStore.splice(0, tableDataAllStore.length);
        tableDataAllComment.splice(0, tableDataAllComment.length);
        var count = 0;
        for (var i in save) {
          var line = save[i];
          if (line['channel'] == (this.option || '娱乐')) {
            tableDataAll.push(line);
            count++;
            tableDataAllDate.unshift(line['date']);
            tableDataAllNewArticle.unshift(line['newArticle']);
            tableDataAllEv.unshift(line['ev']);
            tableDataAllEuv.unshift(line['euv']);
            tableDataAllEv_avg.unshift(line['ev_avg']);
            tableDataAllPv.unshift(line['pv']);
            tableDataAllCtr.unshift(parseFloat(line['ctr']));
            tableDataAllCh_pv.unshift(line['ch_pv']);
            tableDataAllCh_uv.unshift(line['ch_uv']);
            tableDataAllPv_avg.unshift(line['pv_avg']);
            tableDataAllCh_pv_avg.unshift(line['ch_pv_avg']);
            tableDataAllDuration_avg.unshift(line['duration_avg']);
            tableDataAllShare.unshift(line['share']);
            tableDataAllShare_rate.unshift(parseFloat(line['share_rate']));
            tableDataAllStore.unshift(line['store']);
            tableDataAllComment.unshift(line['comment']);
          }
        }
        tableDataAll.splice(0, tableDataAll.length-count);
        tableData.splice(0, tableData.length);
        if (tableDataAll.length < 5) {
          this.pageSize = tableDataAll.length;
        } else {
          this.pageSize = 10;
        }
        for (var i = 0; i < this.pageSize; i++) {
          var line = tableDataAll[i];
          line['newArticle'] = line['newArticle'];
          line['ev'] = line['ev'];
          line['euv'] = line['euv'];
          line['ev_avg'] = line['ev_avg'];
          line['pv'] = line['pv'];
          line['ch_pv'] = line['ch_pv'];
          line['ch_uv'] = line['ch_uv'];
          line['pv_avg'] = line['pv_avg'];
          line['ch_pv_avg'] = line['ch_pv_avg'];
          line['duration_avg'] = line['duration_avg'];
          line['share'] = line['share'];
          line['store'] = line['store'];
          line['comment'] = line['comment'];
          tableData.push(tableDataAll[i]);
        }
      })
    }
  },
  created: function () {
    this.getJSON();
  },
  beforeUpdate: function () {
    var option = {
      legend: {
        left: 'center',
        data: ['文章更新量', '曝光次数', '曝光人数', '人均曝光次数', '文章阅读', '转化率', '频道页pv', '频道页uv', '人均阅读文章pv', '人均频道页pv', '人均频道浏览时长（分）', '分享次数', '分享率', '收藏次数', '评论次数'],
        selectedMode: 'multiple',
        selected: {  
                    '文章更新量': false,  
                    '曝光次数': false,  
                    '曝光人数': false,  
                    '人均曝光次数': false,  
                    '文章阅读': true,  
                    '转化率': false,  
                    '频道页pv': true ,
                    '频道页uv': false,  
                    '人均阅读文章pv': false,
                    '人均频道页pv': false,  
                    '人均频道浏览时长（分）': false,  
                    '分享次数': false,  
                    '分享率': false,  
                    '收藏次数': false,  
                    '评论次数': false 
                }  
      },
      grid: {
        top:'20%',
        left: '2%',
        right: '4%',
        bottom: '3%',
        containLabel: true
    },
      tooltip: {
        trigger: 'axis',
        position: function (pt) {
          return [pt[0]-100, '10%'];
        }
      },
      toolbox: {
        right:'2%',
        top:'8%',
        show: true,
        feature : {
            mark : {show: true},
            dataZoom : {show: true},
            magicType: {type: ['line', 'bar']},
            restore : {show: true},
            saveAsImage : {show: true}
        }
    },
      xAxis: {
        type: 'category',
        boundaryGap: false,
        data: this.tableDataAllDate
      },
      yAxis: {
        type: 'value',
        boundaryGap: [0, '30%']
      },
      dataZoom: [
        {
          type: 'slider',
          show: true,
          xAxisIndex: [0],
          start: 0,
          end: 100
        },
        {
          type: 'inside',
          xAxisIndex: [0],
          start: 0,
          end: 100
        }
      ],
      series: [
        {
          name: '文章更新量',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.tableDataAllNewArticle
        },
        {
          name: '曝光次数',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.tableDataAllEv
        },
        {
          name: '曝光人数',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.tableDataAllEuv
        },
        {
          name: '人均曝光次数',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.tableDataAllEv_avg
        },
        {
          name: '文章阅读',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.tableDataAllPv
        },
        {
          name: '转化率',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.tableDataAllCtr
        },
        {
          name: '频道页pv',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.tableDataAllCh_pv
        },
        {
          name: '频道页uv',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.tableDataAllCh_uv
        },
        {
          name: '人均阅读文章pv',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.tableDataAllPv_avg
        },
        {
          name: '人均频道页pv',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.tableDataAllCh_pv_avg
        },
        {
          name: '人均频道浏览时长（分）',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.tableDataAllDuration_avg
        },
        {
          name: '分享次数',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.tableDataAllShare
        },
        {
          name: '分享率',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.tableDataAllShare_rate
        },
        {
          name: '收藏次数',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.tableDataAllStore
        },
        {
          name: '评论次数',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.tableDataAllComment
        }
      ]
    };
    myChart = echarts.init(document.getElementById('channelArea'));
    myChart.setOption(option);
  },
  mounted () {
        window.onresize = function(){
          myChart.resize();
        }
   }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
/*h1, h2 {
  font-weight: normal;
}

ul {
  list-style-type: none;
  padding: 0;
}

li {
  display: inline-block;
  margin: 0 10px;
}

a {
  color: #42b983;
}*/
</style>
