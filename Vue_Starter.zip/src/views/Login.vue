<template>
  <!-- 登录页面 -->
  <div id="login">

  </div>
</template>

<script>
var uid = '',
  token2 = '',
  name = '';
export default {
  data() {
    return {
      uid: uid,
      token2: token2,
      name: name
    }
  },
  methods: {
    // 存session
    getJSON: function (uid, token2) {
      var d = new Date();
      var url = 'http://10.50.1.130:38080/sso/sso_check.action?uid='+this.uid+'&token2='+this.token2;
      this.$http.get(url).then((response) => {
        console.log(response)
        var temp = response.data;
        if (temp.status == 0) {
          localStorage.setItem('uid', this.uid);
          localStorage.setItem('token2', this.token2);
          localStorage.setItem('name', temp.name);
          localStorage.setItem('date', d.toLocaleDateString());
          var mail = this.uid+'@ifeng.com';
          var url = 'http://10.50.1.130:38080/sso/sso_getAuthList.action?uname='+mail;
          var wholeFlag=0,wholeFullFalg=0,path='/home';
            $.ajax({ 
                    type: "get", 
                     url: url, 
                     cache:false, 
                     async:false, 
                     success: function(data){ 
                      var temps=data.data
                      for (var i in temps) {
                        var temp = temps[i];
                        var tempname = temp['resourcesViewName'];
                        if(tempname=='whole'){
                          wholeFlag=1;
                        }
                        if(tempname=='wholefull'){
                          wholeFullFalg=1;
                        }
                      }
                    } 
              });

            if(wholeFullFalg==1&&wholeFlag==1){
              /*path='/wholefull'*/
            }else if(wholeFullFalg==1&&wholeFlag==0){
              /*path='/wholefull'*/
            }else if(wholeFullFalg==0&&wholeFlag==1){
              /*path='/whole'*/
            }
            console.log('11111')
          console.log(path)
          this.$router.push({ path: path });
        } else {
          this.$router.push({ path: '/' });
        }
      })
    },
    // 重定向域登陆
    getLogin: function () {
      var d = new Date();
      if (localStorage.getItem('uid') && localStorage.getItem('date') == d.toLocaleDateString()) {
        this.$router.push({ path: '/home' });
      } else {
        if(localStorage.getItem('date') != d.toLocaleDateString()){
          
          //window.location.href = 'http://10.50.1.130:38080/sso/sso_userSso.action?rUrl='+'http%3a%2f%2f10.80.130.150%3a8081%2f%23%2f';//测试
           window.location.href = 'http://10.50.1.130:38080/sso/sso_userSso.action?rUrl='+'http%3a%2f%2f10.80.128.150%3a8081%2f%23%2f';//测试
          //window.location.href = 'http://10.50.1.130:38080/sso/sso_userSso.action?rUrl='+'http%3A%2F%2F172.30.161.169%3A8080%2F%23%2F';//测试
          //window.location.href = 'http://10.50.1.130:38080/sso/sso_userSso.action?rUrl='+'http%3a%2f%2f10.90.3.183%3a3000%2f%23%2f';
        }
        var url = window.location.href;
        var arr = url.split('&');
        for (var i in arr) {
          if (arr[i].indexOf('uid') != -1) {
            this.uid = arr[i].slice(arr[i].indexOf('uid')+4);
          }
          if (arr[i].indexOf('token2') != -1) {
            this.token2 = arr[i].slice(arr[i].indexOf('token2')+7,39);
          }
        }
        if ((this.uid.length != 0) && (this.token2.length != 0)) {
          this.getJSON(this.uid, this.token2);
        } 
      }
    }
  },
  created: function () {
    console.log('11111111')
	this.getLogin();
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style>
/*h1, h2 {
  font-weight: normal;
}

ul {
  list-style-type: none;
  padding: 0;
}

li {
  display: inline-block;
  margin: 0 10px;
}

a {
  color: #42b983;
}*/
</style>
