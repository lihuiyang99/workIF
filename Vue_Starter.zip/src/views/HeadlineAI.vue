<template>
  <!-- 推荐流页面 -->
  <div class="animated fadeIn">
    <div class="card">
      <div class="card-block">
        <div class="row">
          <div class="col-sm-5">
            <h4 class="card-title">推荐流曲线图</h4>
            <div class="small text-muted"></div>
          </div><!--/.col-->
        </div><!--/.row-->
         <div id="headlineArea" style="width: 100%; height: 400px; margin: 0 auto;text-align: -webkit-center;"></div>
      </div>
    </div><!--/.card-->
    <div class="row" style="margin-bottom:20px">
      <div id="wholeTable" style="width: 98%; margin: 0 auto">
      <el-row style="margin-bottom: -10px ">
       <el-col :span="19">
          <el-pagination :total="tableDataAll.length" :page-size="pageSize" :page-sizes="[5, 10, 15, 20]" :current-page="pageCurr"
          layout="total, sizes, prev, pager, next, jumper" @size-change="handleSizeChange" @current-change="handleCurrentChange"></el-pagination>
        </el-col>
        <el-col :span="3" style="margin-top: -4px">
          <el-date-picker type="daterange" placeholder="选择日期范围" :clearable="false" v-model="input" @change="handleChange"></el-date-picker>
        </el-col>
      </el-row>
      <el-tooltip  effect="dark" placement="bottom" >
        <div slot="content">推荐文章1日曝光留存率：前1日在头条推荐流曝光2屏幕以上的用户，本日仍然曝光2屏幕以上的用户所占的比例<br/></div>
      <i class="el-icon-warning" style="float: right;margin:7px 15px"></i>
      </el-tooltip>
       <el-table   v-loading="isLoading"   element-loading-text="拼命加载中"  :data="tableData" :row-class-name="tableRowClassName">
          <el-table-column align="center" v-for="item in columns" :prop="item.prop" :label="item.label" :width="item.width" sortable>
          </el-table-column>
        </el-table>
    </div>
  </div>
  </div><!--/.row-->

</template>

<script>
import echarts from 'echarts'
var input = '',
  myChart,
  startDate = '',
  endDate = '',
  pageSize = 10,
  pageCurr = 1,
  columns = [
    {
      prop: 'date',
      label: '日期',
      width: '120px'
    },
    {
      prop: 'article_cnt',
      label: '文章量',
      width: '90px'
    },
    {
      prop: 'ev',
      label: '文章曝光量EV',
      width: '120px'
    },
    {
      prop: 'euv',
      label: '曝光人数EUV',
      width: '120px'
    },
    {
      prop: 'ev_avg',
      label: '人均曝光量',
      width: '100px'
    },
    {
      prop: 'pv',
      label: '阅读PV',
      width: '110px'
    },
    {
      prop: 'uv',
      label: '阅读UV',
      width: '110px'
    },
    {
      prop: 'pv_avg',
      label: '人均阅读次数',
      width: '100px'
    },
    {
      prop: 'rate',
      label: '转化率',
      width: '90px'
    },
    {
      prop: 'cdr_pv',
      label: '下拉次数',
      width: '90px'
    },
    {
      prop: 'cdr_uv',
      label: '下拉人数',
      width: '110px'
    },
    {
      prop: 'cdr_avg',
      label: '人均下拉次数',
      width: '100px'
    },
    {
      prop: 'pnp_pv',
      label: '上拉次数',
      width: '110px'
    },
    {
      prop: 'pnp_uv',
      label: '上拉人数',
      width: '100px'
    },
    {
      prop: 'pnp_avg',
      label: '人均上拉次数',
      width: '100px'
    },
    {
      prop: 'pull_pv',
      label: '上下拉次数',
      width: '100px'
    },
    {
      prop: 'pull_uv',
      label: '上下拉人数',
      width: '100px'
    },
    {
      prop: 'pull_avg',
      label: '人均上下拉次数',
      width: '100px'
    },
    {
      prop: 'duration_avg',
      label: '人均文章阅读时长（分）',
      width: '120px'
    },
    {
      prop: 'share',
      label: '分享次数',
      width: '100px'
    },
    {
      prop: 'share_rate',
      label: '分享率',
      width: '100px'
    },
    {
      prop: 'store',
      label: '收藏次数',
      width: '100px'
    },
    {
      prop: 'store_rate',
      label: '收藏率',
      width: '100px'
    },
    {
      prop: 'comment',
      label: '评论次数',
      width: '100px'
    },
    {
      prop: 'comment_rate',
      label: '评论率',
      width: '100px'
    },
    {
      prop: 'retention_1',
      label: '1日曝光留存率',
      width: '100px'
    },
    {
      prop: 'retention_7',
      label: '7日曝光留存率',
      width: '100px'
    }
  ],
  tableData = [],
  tableDataAll = [],
  tableDataAllDate = [],
  tableDataAllArticle_cnt = [],
  tableDataAllEv = [],
  tableDataAllEuv = [],
  tableDataAllEv_avg = [],
  tableDataAllPv = [],
  tableDataAllUv = [],
  tableDataAllPv_avg = [],
  tableDataAllRate = [],
  tableDataAllCdr_pv = [],
  tableDataAllCdr_uv = [],
  tableDataAllCdr_avg = [],
  tableDataAllPnp_pv = [],
  tableDataAllPnp_uv = [],
  tableDataAllPnp_avg = [],
  tableDataAllPull_pv = [],
  tableDataAllPull_uv = [],
  tableDataAllPull_avg = [],
  tableDataAllDuration_avg = [],
  tableDataAllShare = [],
  tableDataAllShare_rate = [],
  tableDataAllStore = [],
  tableDataAllStore_rate = [],
  tableDataAllComment = [],
  tableDataAllComment_rate = [],
  tableDataAllRetention_1 = [],
  tableDataAllRetention_7 = [];
export default {
  data () {
    return {
      isLoading: false,
      input: input,
      startDate: startDate,
      endDate: endDate,
      pageSize: pageSize,
      pageCurr: pageCurr,
      columns: columns,
      tableData: tableData,
      tableDataAll: tableDataAll,
      tableDataAllDate: tableDataAllDate,
      tableDataAllArticle_cnt: tableDataAllArticle_cnt,
      tableDataAllEv: tableDataAllEv,
      tableDataAllEuv: tableDataAllEuv,
      tableDataAllEv_avg: tableDataAllEv_avg,
      tableDataAllPv: tableDataAllPv,
      tableDataAllUv: tableDataAllUv,
      tableDataAllPv_avg: tableDataAllPv_avg,
      tableDataAllRate: tableDataAllRate,
      tableDataAllCdr_pv: tableDataAllCdr_pv,
      tableDataAllCdr_uv: tableDataAllCdr_uv,
      tableDataAllCdr_avg: tableDataAllCdr_avg,
      tableDataAllPnp_pv: tableDataAllPnp_pv,
      tableDataAllPnp_uv: tableDataAllPnp_uv,
      tableDataAllPnp_avg: tableDataAllPnp_avg,
      tableDataAllPull_pv: tableDataAllPull_pv,
      tableDataAllPull_uv: tableDataAllPull_uv,
      tableDataAllPull_avg: tableDataAllPull_avg,
      tableDataAllDuration_avg: tableDataAllDuration_avg,
      tableDataAllShare: tableDataAllShare,
      tableDataAllShare_rate: tableDataAllShare_rate,
      tableDataAllStore: tableDataAllStore,
      tableDataAllStore_rate: tableDataAllStore_rate,
      tableDataAllComment: tableDataAllComment,
      tableDataAllComment_rate: tableDataAllComment_rate,
      tableDataAllRetention_1: tableDataAllRetention_1,
      tableDataAllRetention_7: tableDataAllRetention_7
    }
  },
  methods: {
    // 选择
    handleChange(val) {
      this.startDate = val.slice(0, 4)+'-'+val.slice(5, 7)+'-'+val.slice(8, 10);
      this.endDate = val.slice(13, 17)+'-'+val.slice(18, 20)+'-'+val.slice(21, 23);
      this.getJSON();
    },
    // 分页
    handleSizeChange(val) {
      this.pageSize = val;
      this.pageCurr = 1;
      tableData.splice(0, tableData.length);
      val=val>=tableDataAll.length?tableDataAll.length:val
      for (var i = 0; i < val; i++) {
        var line = tableDataAll[i];
        line['article_cnt'] = line['article_cnt'].toLocaleString();
        line['ev'] = line['ev'].toLocaleString();
        line['euv'] = line['euv'].toLocaleString();
        line['ev_avg'] = line['ev_avg'].toLocaleString();
        line['pv'] = line['pv'].toLocaleString();
        line['uv'] = line['uv'].toLocaleString();
        line['pv_avg'] = line['pv_avg'].toLocaleString();
        line['cdr_pv'] = line['cdr_pv'].toLocaleString();
        line['cdr_uv'] = line['cdr_uv'].toLocaleString();
        line['cdr_avg'] = line['cdr_avg'].toLocaleString();
        line['pnp_pv'] = line['pnp_pv'].toLocaleString();
        line['pnp_uv'] = line['pnp_uv'].toLocaleString();
        line['pnp_avg'] = line['pnp_avg'].toLocaleString();
        line['pull_pv'] = line['pull_pv'].toLocaleString();
        line['pull_uv'] = line['pull_uv'].toLocaleString();
        line['pull_avg'] = line['pull_avg'].toLocaleString();
        line['duration_avg'] = line['duration_avg'].toLocaleString();
        line['share'] = line['share'].toLocaleString();
        line['store'] = line['store'].toLocaleString();
        line['comment'] = line['comment'].toLocaleString();
        tableData.push(tableDataAll[i]);
      }
    },
    // 换页
    handleCurrentChange(val) {
      this.pageCurr = val;
      tableData.splice(0, tableData.length);
      var end = (tableDataAll.length > (this.pageCurr)*(this.pageSize)) ? (this.pageCurr)*(this.pageSize) : tableDataAll.length;
      for (var i = (this.pageCurr-1)*(this.pageSize); i < end; i++) {
        var line = tableDataAll[i];
        line['article_cnt'] = line['article_cnt'].toLocaleString();
        line['ev'] = line['ev'].toLocaleString();
        line['euv'] = line['euv'].toLocaleString();
        line['ev_avg'] = line['ev_avg'].toLocaleString();
        line['pv'] = line['pv'].toLocaleString();
        line['uv'] = line['uv'].toLocaleString();
        line['pv_avg'] = line['pv_avg'].toLocaleString();
        line['cdr_pv'] = line['cdr_pv'].toLocaleString();
        line['cdr_uv'] = line['cdr_uv'].toLocaleString();
        line['cdr_avg'] = line['cdr_avg'].toLocaleString();
        line['pnp_pv'] = line['pnp_pv'].toLocaleString();
        line['pnp_uv'] = line['pnp_uv'].toLocaleString();
        line['pnp_avg'] = line['pnp_avg'].toLocaleString();
        line['pull_pv'] = line['pull_pv'].toLocaleString();
        line['pull_uv'] = line['pull_uv'].toLocaleString();
        line['pull_avg'] = line['pull_avg'].toLocaleString();
        line['duration_avg'] = line['duration_avg'].toLocaleString();
        line['share'] = line['share'].toLocaleString();
        line['store'] = line['store'].toLocaleString();
        line['comment'] = line['comment'].toLocaleString();
        tableData.push(tableDataAll[i]);
      }
    },
    tableRowClassName(row, index) {
      if (index%2 != 0) {
        return 'odd-row';
      } else if (index%2 == 0) {
        return 'even-row';
      }
      return '';
    },
    getDay: function (day) {
      var today = new Date();
      var target = today.getTime()+1000*60*60*24*day;
      today.setTime(target);
      var year = today.getFullYear();
      var month = today.getMonth();
      var date = today.getDate();
      month = this.addZero(month+1);
      date = this.addZero(date);
      return year.toString()+'-'+month.toString()+'-'+date.toString();
    },
    addZero: function (time) {
      if (time.toString().length == 1) {
        time = '0'+time;
      }
      return time;
    },
    getJSON: function () {
      this.isLoading = true;
      if ((this.startDate) && (this.endDate)) {
      } else {
        this.startDate = this.getDay(-31);
        this.endDate = this.getDay(0);
      }
      var url='http://10.80.128.150:58080/headline_stats/split/data?startDate='+this.startDate+'&endDate='+this.endDate+'&refType=ai'
      console.log(url)
      /*var url = 'http://10.50.1.130:58080/headline_stats/ai?startdate='+this.startDate+'&enddate='+this.endDate;*/
      this.$http.get(url).then((response) => {
        console.log(response)
        this.isLoading = false;
        tableDataAll.splice(0, tableDataAll.length);
        tableDataAllDate.splice(0, tableDataAllDate.length);
        tableDataAllArticle_cnt.splice(0, tableDataAllArticle_cnt.length);
        tableDataAllEv.splice(0, tableDataAllEv.length);
        tableDataAllEuv.splice(0, tableDataAllEuv.length);
        tableDataAllEv_avg.splice(0, tableDataAllEv_avg.length);
        tableDataAllPv.splice(0, tableDataAllPv.length);
        tableDataAllUv.splice(0, tableDataAllUv.length);
        tableDataAllPv_avg.splice(0, tableDataAllPv_avg.length);
        tableDataAllRate.splice(0, tableDataAllRate.length);
        tableDataAllCdr_pv.splice(0, tableDataAllCdr_pv.length);
        tableDataAllCdr_uv.splice(0, tableDataAllCdr_uv.length);
        tableDataAllCdr_avg.splice(0, tableDataAllCdr_avg.length);
        tableDataAllPnp_pv.splice(0, tableDataAllPnp_pv.length);
        tableDataAllPnp_uv.splice(0, tableDataAllPnp_uv.length);
        tableDataAllPnp_avg.splice(0, tableDataAllPnp_avg.length);
        tableDataAllPull_pv.splice(0, tableDataAllPull_pv.length);
        tableDataAllPull_uv.splice(0, tableDataAllPull_uv.length);
        tableDataAllPull_avg.splice(0, tableDataAllPull_avg.length);
        tableDataAllDuration_avg.splice(0, tableDataAllDuration_avg.length);
        tableDataAllShare.splice(0, tableDataAllShare.length);
        tableDataAllShare_rate.splice(0, tableDataAllShare_rate.length);
        tableDataAllStore.splice(0, tableDataAllStore.length);
        tableDataAllStore_rate.splice(0, tableDataAllStore_rate.length);
        tableDataAllComment.splice(0, tableDataAllComment.length);
        tableDataAllComment_rate.splice(0, tableDataAllComment_rate.length);
        tableDataAllRetention_1.splice(0, tableDataAllRetention_1.length);
        tableDataAllRetention_7.splice(0, tableDataAllRetention_7.length);
        var temps = response.data;
        for (var i in temps) {
          var temp = temps[i];
          var line = {};
          line['date'] = temp['date']
          line['article_cnt'] = temp['articleCnt'];
          line['ev'] = temp['ev'];
          line['euv'] = temp['euv'];
          line['ev_avg'] = temp['evAvg'].toFixed(3);
          line['pv'] = temp['pv'];
          line['uv'] = temp['uv'];
          line['pv_avg'] = temp['pvAvg'].toFixed(3);
          line['rate'] = (temp['rate']*100).toFixed(3)+'%';
          line['cdr_pv'] = temp['cdrPv'];
          line['cdr_uv'] = temp['cdrUv'];
          line['cdr_avg'] = temp['cdrAvg'].toFixed(3);
          line['pnp_pv'] = temp['pnpPv'];
          line['pnp_uv'] = temp['pnpUv'];
          line['pnp_avg'] = temp['pnpAvg'].toFixed(3);
          line['pull_pv'] = temp['pullPv'];
          line['pull_uv'] = temp['pullUv'];
          line['pull_avg'] = temp['pullAvg'].toFixed(3);
          line['duration_avg'] = temp['durationAvg'].toFixed(3);
          line['share'] = temp['share'];
          line['share_rate'] = (temp['shareRate']*100).toFixed(3)+'%';
          line['store'] = temp['store'];
          line['store_rate'] = (temp['storeRate']*100).toFixed(3)+'%';
          line['comment'] = temp['comment'];
          line['comment_rate'] = (temp['commentRate']*100).toFixed(3)+'%';
          line['retention_1'] = (temp['retention1']*100).toFixed(3)+'%';
          line['retention_7'] = (temp['retention7']*100).toFixed(3)+'%';
          tableDataAll.unshift(line);
          tableDataAllDate.push(line['date']);
          tableDataAllArticle_cnt.push(line['article_cnt']);
          tableDataAllEv.push(line['ev']);
          tableDataAllEuv.push(line['euv']);
          tableDataAllEv_avg.push(line['ev_avg']);
          tableDataAllPv.push(line['pv']);
          tableDataAllUv.push(line['uv']);
          tableDataAllPv_avg.push(line['pv_avg']);
          tableDataAllRate.push(parseFloat(line['rate']));
          tableDataAllCdr_pv.push(line['cdr_pv']);
          tableDataAllCdr_uv.push(line['cdr_uv']);
          tableDataAllCdr_avg.push(line['cdr_avg']);
          tableDataAllPnp_pv.push(line['pnp_pv']);
          tableDataAllPnp_uv.push(line['pnp_uv']);
          tableDataAllPnp_avg.push(line['pnp_avg']);
          tableDataAllPull_pv.push(line['pull_pv']);
          tableDataAllPull_uv.push(line['pull_uv']);
          tableDataAllPull_avg.push(line['pull_avg']);
          tableDataAllDuration_avg.push(line['duration_avg']);
          tableDataAllShare.push(line['share']);
          tableDataAllShare_rate.push(parseFloat(line['share_rate']));
          tableDataAllStore.push(line['store']);
          tableDataAllStore_rate.push(parseFloat(line['store_rate']));
          tableDataAllComment.push(line['comment']);
          tableDataAllComment_rate.push(parseFloat(line['comment_rate']));
          tableDataAllRetention_1.push(parseFloat(line['retention_1']));
          tableDataAllRetention_7.push(parseFloat(line['retention_7']));
        }
        tableData.splice(0, tableData.length);
        if (tableDataAll.length < 5) {
          this.pageSize = tableDataAll.length;
        } else {
          this.pageSize = 10;
        }
        for (var i = 0; i < this.pageSize; i++) {
          var line = tableDataAll[i];
          line['article_cnt'] = line['article_cnt'].toLocaleString();
          line['ev'] = line['ev'].toLocaleString();
          line['euv'] = line['euv'].toLocaleString();
          line['ev_avg'] = line['ev_avg'].toLocaleString();
          line['pv'] = line['pv'].toLocaleString();
          line['uv'] = line['uv'].toLocaleString();
          line['pv_avg'] = line['pv_avg'].toLocaleString();
          line['cdr_pv'] = line['cdr_pv'].toLocaleString();
          line['cdr_uv'] = line['cdr_uv'].toLocaleString();
          line['cdr_avg'] = line['cdr_avg'].toLocaleString();
          line['pnp_pv'] = line['pnp_pv'].toLocaleString();
          line['pnp_uv'] = line['pnp_uv'].toLocaleString();
          line['pnp_avg'] = line['pnp_avg'].toLocaleString();
          line['pull_pv'] = line['pull_pv'].toLocaleString();
          line['pull_uv'] = line['pull_uv'].toLocaleString();
          line['pull_avg'] = line['pull_avg'].toLocaleString();
          line['duration_avg'] = line['duration_avg'].toLocaleString();
          line['share'] = line['share'].toLocaleString();
          line['store'] = line['store'].toLocaleString();
          line['comment'] = line['comment'].toLocaleString();
          tableData.push(tableDataAll[i]);
        }
      })
    }
  },
  created: function () {
    this.getJSON();
  },
  beforeUpdate: function () {
    var option = {
      legend: {
        left: 'center',
        data: ['文章量', '文章曝光量EV', '曝光人数EUV', '人均曝光量', '阅读PV', '阅读UV', '人均阅读次数', '转化率', '下拉次数', '下拉人数', '人均下拉次数', '上拉次数', '上拉人数', '人均上拉次数', '上下拉次数', '上下拉人数', '人均上下拉次数', '人均文章阅读时长（分）', '分享次数', '分享率', '收藏次数', '收藏率', '评论次数', '评论率', '1日曝光留存率', '7日曝光留存率'],
        selectedMode: 'multiple',
        selected: {  
                    '文章量': false,  
                    '文章曝光量EV': false,  
                    '曝光人数EUV': false,  
                    '人均曝光量': false,  
                    '阅读PV': false,  
                    '阅读UV': false, 
                    '人均阅读次数': false,  
                    '转化率': false,
                    '下拉次数': false,  
                    '下拉人数': false,  
                    '人均下拉次数': false,  
                    '上拉次数': false,  
                    '上拉人数': false, 
                    '评论次数': false,  
                    '人均上拉次数': false,
                    '上下拉人数': false,  
                    '人均上下拉次数': false,
                    '上下拉次数': false,  
                    '人均文章阅读时长（分）': false,  
                    '分享次数': false,  
                    '分享率': false,  
                    '收藏次数': false,  
                    '收藏率': false, 
                    '评论次数': false,  
                    '评论率': false,
                    '1日曝光留存率': true,  
                    '7日曝光留存率': true
                }  
      },
      tooltip: {
        trigger: 'axis',
        position: function (pt) {
          return [pt[0]-100, '10%'];
        }
      },
        toolbox: {
        right:'2%',
        top:'10%',
        show: true,
        feature : {
            mark : {show: true},
            dataZoom : {show: true},
            magicType: {type: ['line', 'bar']},
            restore : {show: true},
            saveAsImage : {show: true}
        }
    },
      xAxis: {
        type: 'category',
        boundaryGap: false,
        data: this.tableDataAllDate
      },
      yAxis: {
        type: 'value',
        boundaryGap: [0, '30%']
      },
      dataZoom: [
        {
          type: 'slider',
          show: true,
          xAxisIndex: [0],
          start: 0,
          end: 100
        },
        {
          type: 'inside',
          xAxisIndex: [0],
          start: 0,
          end: 100
        }
      ],
      series: [
        {
          name: '文章量',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.tableDataAllArticle_cnt
        },
        {
          name: '文章曝光量EV',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.tableDataAllEv
        },
        {
          name: '曝光人数EUV',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.tableDataAllEuv
        },
        {
          name: '人均曝光量',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.tableDataAllEv_avg
        },
        {
          name: '阅读PV',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.tableDataAllPv
        },
        {
          name: '阅读UV',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.tableDataAllUv
        },
        {
          name: '人均阅读次数',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.tableDataAllPv_avg
        },
        {
          name: '转化率',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.tableDataAllRate
        },
        {
          name: '下拉次数',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.tableDataAllCdr_pv
        },
        {
          name: '下拉人数',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.tableDataAllCdr_uv
        },
        {
          name: '人均下拉次数',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.tableDataAllCdr_avg
        },
        {
          name: '上拉次数',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.tableDataAllPnp_pv
        },
        {
          name: '上拉人数',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.tableDataAllPnp_uv
        },
        {
          name: '人均上拉次数',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.tableDataAllPnp_avg
        },
        {
          name: '上下拉次数',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.tableDataAllPull_pv
        },
        {
          name: '上下拉人数',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.tableDataAllPull_uv
        },
        {
          name: '人均上下拉次数',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.tableDataAllPull_avg
        },
        {
          name: '人均文章阅读时长（分）',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.tableDataAllDuration_avg
        },
        {
          name: '分享次数',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.tableDataAllShare
        },
        {
          name: '分享率',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.tableDataAllShare_rate
        },
        {
          name: '收藏次数',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.tableDataAllStore
        },
        {
          name: '收藏率',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.tableDataAllStore_rate
        },
        {
          name: '评论次数',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.tableDataAllComment
        },
        {
          name: '评论率',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.tableDataAllComment_rate
        },
        {
          name: '1日曝光留存率',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.tableDataAllRetention_1
        },
        {
          name: '7日曝光留存率',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.tableDataAllRetention_7
        }
      ],
      grid: {
        top: '20%',
        left: '2%',
        right: '2%',
        bottom: '3%',
        containLabel: true
      }
    };
    myChart = echarts.init(document.getElementById('headlineArea'));
    myChart.setOption(option);
  },
  mounted () {
        window.onresize = function(){
          myChart.resize();
        }
   }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
/*h1, h2 {
  font-weight: normal;
}

ul {
  list-style-type: none;
  padding: 0;
}

li {
  display: inline-block;
  margin: 0 10px;
}

a {
  color: #42b983;
}*/
</style>
