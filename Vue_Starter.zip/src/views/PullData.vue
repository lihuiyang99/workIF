<template>
  <!-- 用户推荐历史页面 -->
  <div class="animated fadeIn">
    
    <div class="row" style="margin-bottom:20px">
      <div id="wholeTable" style="width: 98%; margin: 0 auto">
      <el-row style="margin-bottom: 10px ">
         <el-col :span="2">
          <el-button type="primary" icon="search" :loading="isLoading" @click="handleClick">搜索</el-button>
        </el-col> 
        <el-col :span="15" :offset="1">
          <el-autocomplete placeholder="请输入kind值，点击右侧删除按钮清空搜索历史" style="width: 90%" v-model="input"
          :fetch-suggestions="querySearchAsync"  @select="handleSelect"></el-autocomplete>
        </el-col>
        <el-col :span="3" style="margin-top: -4px">
          <el-date-picker type="daterange" placeholder="选择日期范围" :clearable="false" v-model="inputdep" @change="handleChange"></el-date-picker>
        </el-col>
      </el-row>
      <el-tooltip  effect="dark" placement="bottom" >
        <div class="tooltipMsg" slot="content">推荐原因字段解释：<br/>数据来源#推送原因#辅助说明<br/><br/>
              数据来源：<br/> 
          
        </div>
        <i class="el-icon-warning" style="float: right;margin:7px 15px"></i>
      </el-tooltip>
      <el-row style="margin:10px 0">
         <el-col :span="16" >
           <el-pagination :total="tableDataAll.length" :page-size="pageSize" :page-sizes="[5, 10, 20, 50, 100, 500]" :current-page="pageCurr"
      layout="total, sizes, prev, pager, next, jumper" @size-change="handleSizeChange" @current-change="handleCurrentChange"></el-pagination>
        </el-col>
        <el-col :span="2" :offset="1" style="margin-top: -4px">
          <el-button type="text" icon="upload2" @click="handleClickOut">导出</el-button>
        </el-col>
      </el-row>
     
      
    <el-table v-loading="isLoading"   element-loading-text="拼命加载中" :data="tableData" :row-class-name="tableRowClassName">
        <el-table-column align="center" prop="date" label="日期" min-width="120px" sortable></el-table-column>
       <!--  <el-table-column align="center" prop="id" label="id" min-width="120px" sortable></el-table-column> -->
        <el-table-column align="center" prop="kind" label="kind" min-width="150px" sortable></el-table-column>
        <el-table-column align="center" prop="pv" label="pv" min-width="120px" sortable></el-table-column>
        <el-table-column align="center" prop="uv" label="uv" min-width="120px" sortable></el-table-column>
      </el-table>
    </div>
    </div>
  </div><!--/.row-->
 
</template>

<script>
var 
  input = '',
  inputdep='',
  history = [],
  pageSize = 10,
  pageCurr = 1,
  tableData = [],
  tableDataAll = [],
  getAllkindArr=[],
  startDate='',
  endDate='',
  tableData=[],
  tableDataAll=[],
  excelColumns = [
    {
      prop: 'date',
      label: '日期',
      width: '140px'
    },
    {
      prop: 'kind',
      label: 'kind',
      width: '150px'
    },
    {
      prop: 'pv',
      label: 'pv',
      width: '150px'
    },
    {
      prop: 'uv',
      label: 'uv',
      width: '150px'
    }
  ];
export default {
  data () {
    return {
      isLoading: false,
      input: input,
      inputdep:inputdep,
      history: history,
      pageSize: pageSize,
      pageCurr: pageCurr,
      tableData: tableData,
      tableDataAll: tableDataAll,
      restaurants: [],
      getAllkindArr:getAllkindArr,
      timeout:  null,
      startDate:startDate,
      endDate:endDate
    }
  },
  methods: {
    getAllkind(){
      var url='http://10.80.128.150:58080/outsideKind/kinds';
       $.ajax( {  
                    url:url,// 跳转到 action  
                     type:'get',  
                     dataType:'json', 
                     async:false,
                     success:function(response) { 
                      getAllkindArr.length=0;
                      $.each(response,function(index,item){
                        
                        if(item==null){
                          item=item+'_'
                          getAllkindArr.push({"value":item})
                        }else{
                          getAllkindArr.push({"value":item})
                        }
                        
                      })
                      
                      },  
                      error : function() {  
                           // view("异常！");  
                          alert("异常！");  
                      }  
                 });
    },
    loadAll(){
      var arr=getAllkindArr
      return  arr
    },
    querySearchAsync(queryString, cb) {
        var restaurants = this.restaurants;
        var results = queryString ? restaurants.filter(this.createStateFilter(queryString)) : restaurants;

        clearTimeout(this.timeout);
        this.timeout = setTimeout(() => {
          cb(results);
        }, 100 * Math.random());
      },
      createStateFilter(queryString) {
        return (state) => {
          
          return (state.value.indexOf(queryString.toLowerCase()) === 0);
        };
      },
      handleSelect(item) {
        
      },
      handleChange(val){
        this.startDate = val.slice(0, 10);
        this.endDate = val.slice(13, 23);
        this.getJSON();
      },
    // 搜索
    handleClick(ev) {
      this.getJSON();
    },
    handleClickOut(){
      var url='http://10.80.128.150:58080/outsideKind/data/excel?startDate='+this.startDate+'&endDate='+this.endDate+'&kind='+this.input+'&col='+encodeURI(JSON.stringify(excelColumns));
      window.open(url);
    },
    // 分页
    handleSizeChange(val) {
      this.pageSize = val;
      this.pageCurr = 1;
      tableData.splice(0, tableData.length);
      for (var i = 0; i < val; i++) {
        if (tableDataAll[i]!=undefined) {
            tableData.push(tableDataAll[i]);
        }
      }
    },
    // 换页
    handleCurrentChange(val) {
      this.pageCurr = val;
      tableData.splice(0, tableData.length);
      var end = (tableDataAll.length > (this.pageCurr)*(this.pageSize)) ? (this.pageCurr)*(this.pageSize) : tableDataAll.length;
      for (var i = (this.pageCurr-1)*(this.pageSize); i < end; i++) {
        tableData.push(tableDataAll[i]);
      }
    },
    tableRowClassName(row, index) {
      if (index%2 != 0) {
        return 'odd-row';
      } else if (index%2 == 0) {
        return 'even-row';
      }
      return '';
    },
    // 跳转
    handleButtonClick(ev) {
      console.log(ev)
      if (ev.target.innerText.indexOf('cmpp') != -1) {
        var url = 'http://share.iclient.ifeng.com/sharenews.f?aid='+ev.target.innerText;
        window.open(url)
      }else if(ev.target.innerText.indexOf('sport') != -1){
        var url = 'http://share.iclient.ifeng.com/sharenews.f?aid='+ev.target.innerText;
        window.open(url)
      }else{
        var url = 'http://share.iclient.ifeng.com/sharenews.f?guid='+ev.target.innerText;
        window.open(url)
      }
    },
    getDay: function (day) {
      var today = new Date();
      var target = today.getTime()+1000*60*60*24*day;
      today.setTime(target);
      var year = today.getFullYear();
      var month = today.getMonth();
      var date = today.getDate();
      month = this.addZero(month+1);
      date = this.addZero(date);
      return year.toString()+'-'+month.toString()+'-'+date.toString();
    },
    getDayDate: function (day) {
      var today = new Date(day);
      var year = today.getFullYear();
      var month = today.getMonth();
      var date = today.getDate();
      month = this.addZero(month+1);
      date = this.addZero(date);
      return year.toString()+'/'+month.toString()+'/'+date.toString();
    },
    addZero: function (time) {
      if (time.toString().length == 1) {
        time = '0'+time;
      }
      return time;
    },
    getJSON: function () {
      this.isLoading = true;
      console.log(this.input)
      if ((this.startDate) && (this.endDate)) {
        } else {
          this.startDate = this.getDay(-30);
          this.endDate = this.getDay(0);
        }
        console.log(this.getDay(-30))
        console.log(this.getDay(0))
      var url='http://10.80.128.150:58080/outsideKind/data?startDate='+this.startDate+'&endDate='+this.endDate+'&kind='+this.input;
      console.log(url)
      /*var url = 'http://10.50.1.130:58080/video_rec_history?userkey='+this.input;*/
      this.$http.get(url).then((response) => {
        this.isLoading = false;
        console.log(response)
        tableDataAll.splice(0, tableDataAll.length);
         if(response.data!=''){
          var temps = response.data;
          for (var i in temps) {
          var temp = temps[i];
          var line = {};
          line['date'] = this.getDayDate(temp['date']);
          line['id'] = temp['id'];
          line['kind'] = temp['kind'];
          line['pv'] = temp['pv'];
          line['uv'] = temp['uv'];
          tableDataAll.push(line);
        }
        console.log(tableDataAll)
        tableData.splice(0, tableData.length);
        for (var i = 0; i < this.pageSize; i++) {
          console.log(tableDataAll[i])
          if (tableDataAll[i]!=undefined) {
              tableData.push(tableDataAll[i]);
          }
          
        }
         }else{
          tableDataAll.length=0;
          tableData.length=0;
         }
        
      })
    }
  },
  mounted: function () {
    this.getAllkind()
    this.restaurants = this.loadAll();
    
    /*document.getElementsByTagName('input')[0].onkeydown = function (e) {
      if (e.keyCode == 13) {
        _this.handleClick();
      }
    };*/
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
span{
  -webkit-user-select: initial;
  user-select: initial;
}
</style>
