<template>
  <!-- 编辑流 && 推荐流页面 -->
  <div class="animated fadeIn">
    <div class="card">
      <div class="card-block">
        <div class="row">
          <div class="col-sm-5">
            <h4 class="card-title">编辑流 && 推荐流曲线图</h4>
            <div class="small text-muted"></div>
          </div><!--/.col-->
        </div><!--/.row-->
         <div id="headlineArea" style="width: 100%; height: 400px; margin: 0 auto;text-align: -webkit-center;"></div>
      </div>
    </div><!--/.card-->
    <div class="row" style="margin-bottom:20px">
      <div id="wholeTable" style="width: 98%; margin: 0 auto">
      <el-row style="margin-bottom: -10px ">
        <el-col :span="16">
          <el-pagination :total="tableDataAll.length" :page-size="pageSize" :page-sizes="[5, 10, 15, 20]" :current-page="pageCurr"
          layout="total, sizes, prev, pager, next, jumper" @size-change="handleSizeChange" @current-change="handleCurrentChange"></el-pagination>
        </el-col>
        <el-col :span="2" :offset="1" style="margin-top: -4px">
          <el-button type="text" icon="upload2" @click="handleClick">导出</el-button>
        </el-col>
        <el-col :span="3" style="margin-top: -4px">
          <el-date-picker type="daterange" placeholder="选择日期范围" :clearable="false" v-model="input" @change="handleChange"></el-date-picker>
        </el-col>
      </el-row>
      <el-tooltip  effect="dark" placement="bottom" >
        <div slot="content">文章1量：头条频道被曝光的文章数量；阅读PV：阅读头条频道文章的次数<br/>阅读UV：阅读头条频道文章的人数；人均阅读次数：阅读PV/阅读UV<br/>转化率：阅读PV/文章曝光量<br/>人均文章阅读时长：人均在头条频道阅读文章的时间（分钟）<br/>分享次数：分享头条文章的次数；分享率：分享次数/文章曝光量<br/>收藏次数：收藏头条文章的次数；收藏率：收藏次数/文章曝光量<br/>评论次数：评论推荐文章的次数；评论率：评论次数/下拉文章次数EV<br/>1日曝光留存率：前1日在头条曝光2屏幕以上的用户，本日仍然曝光2屏幕以上的用户所占的比例<br/>7日曝光留存率：前7日在头条曝光2屏幕以上的用户，本日仍然曝光2屏幕以上的用户所占的比例<br/></div>
      <i class="el-icon-warning" style="float: right;margin:7px 15px"></i>
      </el-tooltip>
        <el-table   v-loading="isLoading"   element-loading-text="拼命加载中"  :data="tableData" :row-class-name="tableRowClassName">
          <el-table-column align="center" v-for="item in columns" :prop="item.prop" :label="item.label" :min-width="item.width" sortable>
          </el-table-column>
        </el-table>
    </div>
  </div>
  </div><!--/.row-->
</template>

<script>
import echarts from 'echarts'
var input = '',
  myChart,
  startDate = '',
  endDate = '',
  pageSize = 10,
  pageCurr = 1,
  columns = [
    {
      prop: 'date',
      label: '日期',
      width: '120px'
    },
    {
      prop: 'article_cnt',
      label: '文章量',
      width: '100px'
    },
    {
      prop: 'ev',
      label: '文章曝光量EV',
      width: '120px'
    },
    {
      prop: 'euv',
      label: '曝光人数EUV',
      width: '120px'
    },
    {
      prop: 'ev_avg',
      label: '人均曝光量',
      width: '100px'
    },
    {
      prop: 'pv',
      label: '阅读PV',
      width: '120px'
    },
    {
      prop: 'uv',
      label: '阅读UV',
      width: '110px'
    },
    {
      prop: 'pv_avg',
      label: '人均阅读次数',
      width: '100px'
    },
    {
      prop: 'rate',
      label: '转化率',
      width: '90px'
    },
    {
      prop: 'duration_avg',
      label: '人均文章阅读时长（分）',
      width: '130px'
    },
    {
      prop: 'share',
      label: '分享次数',
      width: '100px'
    },
    {
      prop: 'share_rate',
      label: '分享率',
      width: '100px'
    },
    {
      prop: 'store',
      label: '收藏次数',
      width: '100px'
    },
    {
      prop: 'store_rate',
      label: '收藏率',
      width: '100px'
    },
    {
      prop: 'comment',
      label: '评论次数',
      width: '100px'
    },
    {
      prop: 'comment_rate',
      label: '评论率',
      width: '100px'
    },
    {
      prop: 'retention_1',
      label: '1日曝光留存率',
      width: '100px'
    },
    {
      prop: 'retention_7',
      label: '7日曝光留存率',
      width: '100px'
    }
  ],
  columnsXls = [
    {
      prop: 'date',
      label: '日期',
      width: '120px'
    },
    {
      prop: 'articleCnt',
      label: '文章量',
      width: '100px'
    },
    {
      prop: 'ev',
      label: '文章曝光量EV',
      width: '120px'
    },
    {
      prop: 'euv',
      label: '曝光人数EUV',
      width: '120px'
    },
    {
      prop: 'evAvg',
      label: '人均曝光量',
      width: '100px'
    },
    {
      prop: 'pv',
      label: '阅读PV',
      width: '120px'
    },
    {
      prop: 'uv',
      label: '阅读UV',
      width: '110px'
    },
    {
      prop: 'pvAvg',
      label: '人均阅读次数',
      width: '100px'
    },
    {
      prop: 'rate',
      label: '转化率',
      width: '90px'
    },
    {
      prop: 'durationAvg',
      label: '人均文章阅读时长（分）',
      width: '130px'
    },
    {
      prop: 'share',
      label: '分享次数',
      width: '100px'
    },
    {
      prop: 'shareRate',
      label: '分享率',
      width: '100px'
    },
    {
      prop: 'store',
      label: '收藏次数',
      width: '100px'
    },
    {
      prop: 'storeRate',
      label: '收藏率',
      width: '100px'
    },
    {
      prop: 'comment',
      label: '评论次数',
      width: '100px'
    },
    {
      prop: 'commentRate',
      label: '评论率',
      width: '100px'
    },
    {
      prop: 'retention1',
      label: '1日曝光留存率',
      width: '100px'
    },
    {
      prop: 'retention7',
      label: '7日曝光留存率',
      width: '100px'
    }
  ],
  tableData = [],
  tableDataAll = [],
  tableDataAllDate = [],
  tableDataAllArticle_cnt = [],
  tableDataAllEv = [],
  tableDataAllEuv = [],
  tableDataAllEv_avg = [],
  tableDataAllPv = [],
  tableDataAllUv = [],
  tableDataAllPv_avg = [],
  tableDataAllRate = [],
  tableDataAllDuration_avg = [],
  tableDataAllShare = [],
  tableDataAllShare_rate = [],
  tableDataAllStore = [],
  tableDataAllStore_rate = [],
  tableDataAllComment = [],
  tableDataAllComment_rate = [],
  tableDataAllRetention_1 = [],
  tableDataAllRetention_7 = [];
export default {
  data () {
    return {
      isLoading: false,
      input: input,
      startDate: startDate,
      endDate: endDate,
      pageSize: pageSize,
      pageCurr: pageCurr,
      columns: columns,
      tableData: tableData,
      tableDataAll: tableDataAll,
      tableDataAllDate: tableDataAllDate,
      tableDataAllArticle_cnt: tableDataAllArticle_cnt,
      tableDataAllEv: tableDataAllEv,
      tableDataAllEuv: tableDataAllEuv,
      tableDataAllEv_avg: tableDataAllEv_avg,
      tableDataAllPv: tableDataAllPv,
      tableDataAllUv: tableDataAllUv,
      tableDataAllPv_avg: tableDataAllPv_avg,
      tableDataAllRate: tableDataAllRate,
      tableDataAllDuration_avg: tableDataAllDuration_avg,
      tableDataAllShare: tableDataAllShare,
      tableDataAllShare_rate: tableDataAllShare_rate,
      tableDataAllStore: tableDataAllStore,
      tableDataAllStore_rate: tableDataAllStore_rate,
      tableDataAllComment: tableDataAllComment,
      tableDataAllComment_rate: tableDataAllComment_rate,
      tableDataAllRetention_1: tableDataAllRetention_1,
      tableDataAllRetention_7: tableDataAllRetention_7
    }
  },
  methods: {
    //download
    handleClick(ev) {
      /*var url='http://10.50.1.130:58080/headline_stats/data/excel?startDate='+this.startDate+'&endDate='+this.endDate+'&col='+encodeURI(JSON.stringify(columns));*/
      var url ='http://10.50.1.130:58080/headline_stats/data/excel?startDate='+this.startDate+'&endDate='+this.endDate+'&col='+encodeURI(JSON.stringify(columnsXls));
      console.log(url);
      window.open(url);
    },
    // 选择
    handleChange(val) {
      this.startDate = val.slice(0, 4)+'-'+val.slice(5, 7)+'-'+val.slice(8, 10);
      this.endDate = val.slice(13, 17)+'-'+val.slice(18, 20)+'-'+val.slice(21, 23);
      this.getJSON();
    },
    // 分页
    handleSizeChange(val) {
      this.pageSize = val;
      this.pageCurr = 1;
      tableData.splice(0, tableData.length);
      val=val>=tableDataAll.length?tableDataAll.length:val
      for (var i = 0; i < val; i++) {
        var line = tableDataAll[i];
        line['article_cnt'] = line['article_cnt'].toLocaleString();
        line['ev'] = line['ev'].toLocaleString();
        line['euv'] = line['euv'].toLocaleString();
        line['ev_avg'] = line['ev_avg'].toLocaleString();
        line['pv'] = line['pv'].toLocaleString();
        line['uv'] = line['uv'].toLocaleString();
        line['pv_avg'] = line['pv_avg'].toLocaleString();
        line['duration_avg'] = line['duration_avg'].toLocaleString();
        line['share'] = line['share'].toLocaleString();
        line['store'] = line['store'].toLocaleString();
        line['comment'] = line['comment'].toLocaleString();
        tableData.push(tableDataAll[i]);
      }
    },
    // 换页
    handleCurrentChange(val) {
      this.pageCurr = val;
      tableData.splice(0, tableData.length);
      var end = (tableDataAll.length > (this.pageCurr)*(this.pageSize)) ? (this.pageCurr)*(this.pageSize) : tableDataAll.length;
      for (var i = (this.pageCurr-1)*(this.pageSize); i < end; i++) {
        var line = tableDataAll[i];
        line['article_cnt'] = line['article_cnt'].toLocaleString();
        line['ev'] = line['ev'].toLocaleString();
        line['euv'] = line['euv'].toLocaleString();
        line['ev_avg'] = line['ev_avg'].toLocaleString();
        line['pv'] = line['pv'].toLocaleString();
        line['uv'] = line['uv'].toLocaleString();
        line['pv_avg'] = line['pv_avg'].toLocaleString();
        line['duration_avg'] = line['duration_avg'].toLocaleString();
        line['share'] = line['share'].toLocaleString();
        line['store'] = line['store'].toLocaleString();
        line['comment'] = line['comment'].toLocaleString();
        tableData.push(tableDataAll[i]);
      }
    },
    tableRowClassName(row, index) {
      if (index%2 != 0) {
        return 'odd-row';
      } else if (index%2 == 0) {
        return 'even-row';
      }
      return '';
    },
    getDay: function (day) {
      var today = new Date();
      var target = today.getTime()+1000*60*60*24*day;
      today.setTime(target);
      var year = today.getFullYear();
      var month = today.getMonth();
      var date = today.getDate();
      month = this.addZero(month+1);
      date = this.addZero(date);
      return year.toString()+'-'+month.toString()+'-'+date.toString();
    },
    addZero: function (time) {
      if (time.toString().length == 1) {
        time = '0'+time;
      }
      return time;
    },
    getJSON: function () {
      this.isLoading = true;
      if ((this.startDate) && (this.endDate)) {
      } else {
        this.startDate = this.getDay(-31);
        this.endDate = this.getDay(0);
      }
      console.log(this.startDate)
      var url='http://10.80.128.150:58080/headline_stats/data?startDate='+this.startDate+'&endDate='+this.endDate
      /*var url = 'http://10.50.1.130:58080/headline_stats/all?startdate='+this.startDate+'&enddate='+this.endDate;*/
      this.$http.get(url).then((response) => {
        console.log(response)
        this.isLoading = false;
        tableDataAll.splice(0, tableDataAll.length);
        tableDataAllDate.splice(0, tableDataAllDate.length);
        tableDataAllArticle_cnt.splice(0, tableDataAllArticle_cnt.length);
        tableDataAllEv.splice(0, tableDataAllEv.length);
        tableDataAllEuv.splice(0, tableDataAllEuv.length);
        tableDataAllEv_avg.splice(0, tableDataAllEv_avg.length);
        tableDataAllPv.splice(0, tableDataAllPv.length);
        tableDataAllUv.splice(0, tableDataAllUv.length);
        tableDataAllPv_avg.splice(0, tableDataAllPv_avg.length);
        tableDataAllRate.splice(0, tableDataAllRate.length);
        tableDataAllDuration_avg.splice(0, tableDataAllDuration_avg.length);
        tableDataAllShare.splice(0, tableDataAllShare.length);
        tableDataAllShare_rate.splice(0, tableDataAllShare_rate.length);
        tableDataAllStore.splice(0, tableDataAllStore.length);
        tableDataAllStore_rate.splice(0, tableDataAllStore_rate.length);
        tableDataAllComment.splice(0, tableDataAllComment.length);
        tableDataAllComment_rate.splice(0, tableDataAllComment_rate.length);
        tableDataAllRetention_1.splice(0, tableDataAllRetention_1.length);
        tableDataAllRetention_7.splice(0, tableDataAllRetention_7.length);
        var temps = response.data;
        for (var i in temps) {
          var temp = temps[i];
          var line = {};
          line['date'] = temp['date'];
          line['article_cnt'] = temp['articleCnt'];
          line['ev'] = temp['ev'];
          line['euv'] = temp['euv'];
          line['ev_avg'] = temp['evAvg'].toFixed(3);
          line['pv'] = temp['pv'];
          line['uv'] = temp['uv'];
          line['pv_avg'] = temp['pvAvg'].toFixed(3);
          line['rate'] = (temp['rate']*100).toFixed(3)+'%';
          line['duration_avg'] = temp['durationAvg'].toFixed(3);
          line['share'] = temp['share'];
          line['share_rate'] = (temp['shareRate']*100).toFixed(3)+'%';
          line['store'] = temp['store'];
          line['store_rate'] = (temp['storeRate']*100).toFixed(3)+'%';
          line['comment'] = temp['comment'];
          line['comment_rate'] = (temp['commentRate']*100).toFixed(3)+'%';
          line['retention_1'] = (temp['retention1']*100).toFixed(3)+'%';
          line['retention_7'] = (temp['retention7']*100).toFixed(3)+'%';
          tableDataAll.unshift(line);
          tableDataAllDate.push(line['date']);
          tableDataAllArticle_cnt.push(line['article_cnt']);
          tableDataAllEv.push(line['ev']);
          tableDataAllEuv.push(line['euv']);
          tableDataAllEv_avg.push(line['ev_avg']);
          tableDataAllPv.push(line['pv']);
          tableDataAllUv.push(line['uv']);
          tableDataAllPv_avg.push(line['pv_avg']);
          tableDataAllRate.push(parseFloat(line['rate']));
          tableDataAllDuration_avg.push(line['duration_avg']);
          tableDataAllShare.push(line['share']);
          tableDataAllShare_rate.push(parseFloat(line['share_rate']));
          tableDataAllStore.push(line['store']);
          tableDataAllStore_rate.push(parseFloat(line['store_rate']));
          tableDataAllComment.push(line['comment']);
          tableDataAllComment_rate.push(parseFloat(line['comment_rate']));
          tableDataAllRetention_1.push(parseFloat(line['retention_1']));
          tableDataAllRetention_7.push(parseFloat(line['retention_7']));
        }
        tableData.splice(0, tableData.length);
        if (tableDataAll.length < 5) {
          this.pageSize = tableDataAll.length;
        } else {
          this.pageSize = 10;
        }
        for (var i = 0; i < this.pageSize; i++) {
          var line = tableDataAll[i];
          line['article_cnt'] = line['article_cnt'].toLocaleString();
          line['ev'] = line['ev'].toLocaleString();
          line['euv'] = line['euv'].toLocaleString();
          line['ev_avg'] = line['ev_avg'].toLocaleString();
          line['pv'] = line['pv'].toLocaleString();
          line['uv'] = line['uv'].toLocaleString();
          line['pv_avg'] = line['pv_avg'].toLocaleString();
          line['duration_avg'] = line['duration_avg'].toLocaleString();
          line['share'] = line['share'].toLocaleString();
          line['store'] = line['store'].toLocaleString();
          line['comment'] = line['comment'].toLocaleString();
          tableData.push(tableDataAll[i]);
        }
      })
    }
  },
  created: function () {
    this.getJSON();
  },
  beforeUpdate: function () {
    var option = {
      legend: {
        left: 'center',
        data: ['文章量', '文章曝光量EV', '曝光人数EUV', '人均曝光量', '阅读PV', '阅读UV', '人均阅读次数', '转化率', '人均文章阅读时长（分）', '分享次数', '分享率', '收藏次数', '收藏率', '评论次数', '评论率', '1日曝光留存率', '7日曝光留存率'],
        selectedMode: 'multiple',
        selected: {  
                    '文章量': false,  
                    '文章曝光量EV': false,  
                    '曝光人数EUV': false,  
                    '人均曝光量': false,  
                    '阅读PV': false,  
                    '阅读UV': false, 
                    '人均阅读次数': false,  
                    '转化率': false,
                    '人均文章阅读时长（分）': false,  
                    '分享次数': false,  
                    '分享率': false,  
                    '收藏次数': false,  
                    '收藏率': false, 
                    '评论次数': false,  
                    '评论率': false,
                    '1日曝光留存率': true,  
                    '7日曝光留存率': true
                }  
      },
      tooltip: {
        trigger: 'axis',
        position: function (pt) {
          return [pt[0]-100, '10%'];
        }
      },
      toolbox: {
        right:'2%',
        top:'8%',
        show: true,
        feature : {
            mark : {show: true},
            dataZoom : {show: true},
            magicType: {type: ['line', 'bar']},
            restore : {show: true},
            saveAsImage : {show: true}
        }
    },
      xAxis: {
        type: 'category',
        boundaryGap: false,
        data: this.tableDataAllDate
      },
      yAxis: {
        type: 'value',
        boundaryGap: [0, '30%']
      },
      dataZoom: [
        {
          type: 'slider',
          show: true,
          xAxisIndex: [0],
          start: 0,
          end: 100
        },
        {
          type: 'inside',
          xAxisIndex: [0],
          start: 0,
          end: 100
        }
      ],
      series: [
        {
          name: '文章量',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.tableDataAllArticle_cnt
        },
        {
          name: '文章曝光量EV',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.tableDataAllEv
        },
        {
          name: '曝光人数EUV',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.tableDataAllEuv
        },
        {
          name: '人均曝光量',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.tableDataAllEv_avg
        },
        {
          name: '阅读PV',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.tableDataAllPv
        },
        {
          name: '阅读UV',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.tableDataAllUv
        },
        {
          name: '人均阅读次数',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.tableDataAllPv_avg
        },
        {
          name: '转化率',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.tableDataAllRate
        },
        {
          name: '人均文章阅读时长（分）',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.tableDataAllDuration_avg
        },
        {
          name: '分享次数',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.tableDataAllShare
        },
        {
          name: '分享率',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.tableDataAllShare_rate
        },
        {
          name: '收藏次数',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.tableDataAllStore
        },
        {
          name: '收藏率',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.tableDataAllStore_rate
        },
        {
          name: '评论次数',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.tableDataAllComment
        },
        {
          name: '评论率',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.tableDataAllComment_rate
        },
        {
          name: '1日曝光留存率',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.tableDataAllRetention_1
        },
        {
          name: '7日曝光留存率',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.tableDataAllRetention_7
        }
      ],
      grid: {
        top: '20%',
        left: '2%',
        right: '2%',
        bottom: '3%',
        containLabel: true
      }
    };
    myChart = echarts.init(document.getElementById('headlineArea'));
    myChart.setOption(option);
  },
  mounted () {
        window.onresize = function(){
          myChart.resize();
        }
   }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
/*h1, h2 {
  font-weight: normal;
}

ul {
  list-style-type: none;
  padding: 0;
}

li {
  display: inline-block;
  margin: 0 10px;
}

a {
  color: #42b983;
}*/
</style>
