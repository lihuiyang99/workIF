<script>
import { Line } from 'vue-chartjs'


var data=[],startDate,
      endDate;
      var label=[];
      var numArr=[];
export default Line.extend({
   data(){
    return{
      /*label:label,
      data:data,*/
      startDate: startDate,
      endDate: endDate,
    }
  },
  methods:{
    getDay: function (day) {
      var today = new Date();
      var target = today.getTime()+1000*60*60*24*day;
      today.setTime(target);
      var year = today.getFullYear();
      var month = today.getMonth();
      var date = today.getDate();
      month = this.addZero(month+1);
      date = this.addZero(date);
      return year.toString()+'-'+month.toString()+'-'+date.toString();
    },
    addZero: function (time) {
      if (time.toString().length == 1) {
        time = '0'+time;
      }
      return time;
    },
    getJSON:function(){
        /*this.data=[];
        this.label=[];*/
        this.startDate = this.getDay(-7);
        this.endDate = this.getDay(0);
        var url = 'http://sdk.data.ifeng.com/macro/macro_macroData.action?startDate='+this.startDate+'&endDate='+this.endDate;
        $.ajax({
             type: "GET",
             url: url,
             async:false,
             dataType: "json",
             success: function(response){
                  data=[];
                   label=[];
                  var jsonData=response.data;
                  for(var i=0;i<jsonData.length;i++){
                    data.unshift(Number(jsonData[i]['newUser']))
                    label.unshift(jsonData[i]['date'])
                  }
               }
         });
        
    }
  },
  props: ['height'],
  created: function () {
  /*this.getJSON();*/
  },
  mounted () {
    this.getJSON();
    var datasets = [
      {
        label: '新增',
        backgroundColor: '67c2ef',
        borderColor: 'rgba(255,255,255,.55)',
        data: data
      }
    ]
    this.renderChart({
      labels: label,
      datasets: datasets
    }, {
      maintainAspectRatio: false,
      legend: {
        display: false
      },
      scales: {
        xAxes: [{
          gridLines: {
            color: 'transparent',
            zeroLineColor: 'transparent'
          },
          ticks: {
            fontSize: 2,
            fontColor: 'transparent'
          }

        }],
        yAxes: [{
          display: false,
          ticks: {
            display: false,
           /* min: Math.min.apply(Math, datasets[0].data) - 5,
            max: Math.max.apply(Math, datasets[0].data) + 5*/
          }
        }]
      },
      elements: {
        line: {
          tension: 0.00001,
          borderWidth: 1
        },
        point: {
          radius: 4,
          hitRadius: 10,
          hoverRadius: 4
        }
      }
    })
  }
})
</script>
