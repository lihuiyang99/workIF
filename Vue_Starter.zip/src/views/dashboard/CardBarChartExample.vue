<script>
import { Bar } from 'vue-chartjs'


var data=[],startDate,
      endDate;
      var label=[];
      var numArr=[];
export default Bar.extend({
  data(){
    return{
      /*label:label,
      data:data,*/
      startDate: startDate,
      endDate: endDate,
    }
  },
  methods:{
    getDay: function (day) {
      var today = new Date();
      var target = today.getTime()+1000*60*60*24*day;
      today.setTime(target);
      var year = today.getFullYear();
      var month = today.getMonth();
      var date = today.getDate();
      month = this.addZero(month+1);
      date = this.addZero(date);
      return year.toString()+'-'+month.toString()+'-'+date.toString();
    },
    addZero: function (time) {
      if (time.toString().length == 1) {
        time = '0'+time;
      }
      return time;
    },
    getJSON:function(){
        /*this.data=[];
        this.label=[];*/
        this.startDate = this.getDay(-7);
        this.endDate = this.getDay(0);
        var url = 'http://sdk.data.ifeng.com/macro/macro_macroData.action?startDate='+this.startDate+'&endDate='+this.endDate;
        $.ajax({
             type: "GET",
             url: url,
             async:false,
             dataType: "json",
             success: function(response){
                  data=[];
                   label=[];
                  var jsonData=response.data;
                  for(var i=0;i<jsonData.length;i++){
                    data.unshift(Number(jsonData[i]['ev']))
                    label.unshift(jsonData[i]['date'])
                  }
               }
         });
        
    }
  },
  created: function () {
  /*this.getJSON();*/
  },
  props: ['height'],
  mounted () {
    this.getJSON();
    var datasets = [
        {
          label: '曝光量',
          backgroundColor: 'rgba(255,255,255,.3)',
          borderColor: 'transparent',
          data: data
        }
      ]
    this.renderChart({
      labels: label,
      datasets: datasets
    }, {
      maintainAspectRatio: false,
      legend: {
        display: false
      },
      scales: {
        xAxes: [{
          display: false,
          categoryPercentage: 1,
          barPercentage: 0.5
        }],
        yAxes: [{
          display: false
        }]
      }
    })
  }
})
</script>
