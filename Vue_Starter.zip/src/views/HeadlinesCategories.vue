<template>
  <!-- 频道（540）页面 -->
   <div class="animated fadeIn">
    <div class="card">
      <div class="card-block">
        <div class="row">
          <div class="col-sm-12">
            <h4 class="card-title">头条分类曲线图</h4>
            <div class="small text-muted">
              <div class="contentTab" style="margin:20px">
                <el-button @click="getChart(0,'articleCnt')" :class="checkedCh==0?'getChbg':null">文章量</el-button>
                <el-button @click="getChart(1,'ev')" :class="checkedCh==1?'getChbg':null">曝光EV</el-button>
                <el-button @click="getChart(2,'euv')" :class="checkedCh==2?'getChbg':null">曝光EUV</el-button>
                <el-button @click="getChart(3,'evAvg')" :class="checkedCh==3?'getChbg':null">人均曝光量</el-button>
                <el-button @click="getChart(4,'pv')" :class="checkedCh==4?'getChbg':null">阅读PV</el-button>
                <el-button @click="getChart(5,'uv')" :class="checkedCh==5?'getChbg':null">阅读UV</el-button>
                <el-button @click="getChart(6,'pvAvg')" :class="checkedCh==6?'getChbg':null">人均阅读数</el-button>
                <el-button @click="getChart(7,'rate')" :class="checkedCh==7?'getChbg':null">转化率</el-button>
              </div>
            </div> 
          </div><!--/.col-->
        </div><!--/.row-->
         <div id="channelArea" v-show="tableTypeChart==0" style="width: 100%; height: 400px; margin: 0 auto;text-align: -webkit-center;"></div>
         <div id="channelArea1"  v-show="tableTypeChart==1"    style="width: 100%; height: 400px; margin: 0 auto;text-align: -webkit-center;"></div>
         <div id="channelArea2"  v-show="tableTypeChart==2"  style="width: 100%; height: 400px; margin: 0 auto;text-align: -webkit-center;"></div>
         <div id="channelArea3"  v-show="tableTypeChart==3"  style="width: 100%; height: 400px; margin: 0 auto;text-align: -webkit-center;"></div>
      </div>
    </div><!--/.card-->
    <div class="row" style="margin-bottom:20px">
      <div id="wholeTable" style="width: 98%; margin: 0 auto">
      <el-row style="margin-bottom: -10px ">
        <el-col :span="10">
          <el-pagination :total="tableDataAll.length" :page-size="pageSize" :page-sizes="[5, 10, 15, 20]" :current-page="pageCurr"
          layout="total, sizes, prev, pager, next, jumper" @size-change="handleSizeChange" @current-change="handleCurrentChange"></el-pagination>
        </el-col>
        <el-col :span="2" :offset="1" style="margin-top: -4px">
          <el-button type="text" icon="upload2" @click="handleClick">导出</el-button>
        </el-col>
        <el-col :span="3" style="margin-top: -4px">
          <el-select placeholder="编辑+推荐" filterable v-model="optionFlow" @change="handleSelectChangeFlow">
            <el-option v-for="item in optionsFlow" :label="item.label" :value="item.value"></el-option>
          </el-select>
        </el-col>
        <el-col :span="3" style="margin-top: -4px">
          <el-select placeholder="数据来源" filterable v-model="option" @change="handleSelectChange">
            <el-option v-for="item in options" :label="item.label" :value="item.value"></el-option>
          </el-select>
        </el-col>
        <el-col :span="3" style="margin-top: -4px">
          <el-date-picker type="daterange" placeholder="选择日期范围" :clearable="false" v-model="inputdep" @change="handleChange"></el-date-picker>
        </el-col>
      </el-row>
      <el-tooltip  effect="dark" placement="bottom" >
        <div slot="content">文章更新量：当日曝光，但未在之前5日内曝光的文章<br/>曝光次数：该频道文章曝光次数<br/>曝光人数：该频道文章曝光的用户数<br/>频道页UV：频道首页停留3秒以上的用户<br/>转化率：阅读PV/EV<br/>分享率：分享次数/EV<br/></div>
      <i class="el-icon-warning" style="float: right;margin:7px 15px"></i>
      </el-tooltip>
        <el-table  v-loading="isLoading"   element-loading-text="拼命加载中"  v-show="tableType==1" stripe :data="tableData" :row-class-name="tableRowClassName">
          <el-table-column align="center" v-for="item in columns" v-if="item.show=='true'" :prop="item.prop" :label="item.label" :min-width="item.width" sortable>
          </el-table-column>
        </el-table>
         <el-table  v-loading="isLoading"   element-loading-text="拼命加载中"   v-show="tableType==0"  stripe :data="tableData" :row-class-name="tableRowClassName">
          <el-table-column align="center" v-for="item in columnsEn" v-if="item.show=='true'" :prop="item.prop" :label="item.label" :min-width="item.width" sortable>
          </el-table-column>
        </el-table>
    </div>
    </div>
  </div><!--/.row-->

</template>

<script>
import echarts from 'echarts'
var save = [],
  tableType=1,
  tableTypeChart=0,
  option = 'source',
  optionFlow = 'all',
  optionsFlow = [{label:'编辑+推荐',value:'all'},{label:'编辑',value:'editor'},{label:'推荐',value:'ai'}],
  options = [{label:'数据来源',value:'source'},{label:'推荐类型',value:'reason'},{label:'文章类型',value:'type'},{label:'推荐引擎ab测试',value:'engine'}],
  input = '',
  inputdep='',
  startDate = '',
  endDate = '',
  pageSize = 10,
  pageCurr = 1,
  checkedCh=0,
  myChart,
  myChart1,
  myChart2,
  myChart3,
  columns = [
    {
      prop: 'date',
      label: '日期',
      width: '120px',
      show:'true'
    },
    {
      prop: 'source',
      label: '数据来源',
      width: '150px',
      show:'true'
    },
    {
      prop: 'reason',
      label: '推荐类型',
      width: '150px',
      show:'true'
    },
    {
      prop: 'type',
      label: '文章类型',
      width: '150px',
      show:'true'
    },
    {
      prop: 'engine',
      label: '引擎标识',
      width: '150px',
      show:'true'
    },
    {
      prop: 'articleCnt',
      label: '文章量',
      width: '90px',
      show:'true'
    },
    {
      prop: 'ev',
      label: '曝光EV',
      width: '120px',
      show:'true'
    },
    {
      prop: 'euv',
      label: '曝光EUV',
      width: '100px',
      show:'true'
    },
    {
      prop: 'evAvg',
      label: '人均曝光量',
      width: '120px',
      show:'true'
    },
    {
      prop: 'pv',
      label: '阅读PV',
      width: '120px',
      show:'true'
    },
    {
      prop: 'uv',
      label: '阅读UV',
      width: '100px',
      show:'true'
    },
    {
      prop: 'pvAvg',
      label: '人均阅读数',
      width: '120px',
      show:'true'
    },
    {
      prop: 'rate',
      label: '转化率',
      width: '120px',
      show:'true'
    },
    {
      prop: 'share',
      label: '分享数',
      width: '100px',
      show:'true'
    },
    {
      prop: 'shareRate',
      label: '分享率',
      width: '100px',
      show:'true'
    },
    {
      prop: 'store',
      label: '收藏数',
      width: '100px',
      show:'true'
    },
    {
      prop: 'storeRate',
      label: '收藏率',
      width: '90px',
      show:'true'
    },
    {
      prop: 'comment',
      label: '评论数',
      width: '90px',
      show:'true'
    },
    {
      prop: 'commentRate',
      label: '评论率',
      width: '90px',
      show:'true'
    },
    {
      prop: 'durationUv',
      label: '文章阅读时长人数',
      width: '120px',
      show:'true'
    },
    {
      prop: 'durationAvg',
      label: '人均文章阅读时长(分钟)',
      width: '120px',
      show:'true'
    },
    {
      prop: 'expoRate',
      label: '曝光占比',
      width: '100px',
      show:'true'
    },
    {
      prop: 'rate1',
      label: '1日留存',
      width: '100px',
      show:'true'
    },
    {
      prop: 'rate7',
      label: '7日留存',
      width: '100px',
      show:'true'
    }
  ],
  columnsEn = [
    {
      prop: 'date',
      label: '日期',
      width: '120px',
      show:'true'
    },
    {
      prop: 'engine',
      label: '引擎标识',
      width: '150px',
      show:'true'
    },
    {
      prop: 'articleCnt',
      label: '文章量',
      width: '90px',
      show:'true'
    },
    {
      prop: 'ev',
      label: '曝光EV',
      width: '120px',
      show:'true'
    },
    {
      prop: 'euv',
      label: '曝光EUV',
      width: '100px',
      show:'true'
    },
    {
      prop: 'evAvg',
      label: '人均曝光量',
      width: '120px',
      show:'true'
    },
    {
      prop: 'pv',
      label: '阅读PV',
      width: '120px',
      show:'true'
    },
    {
      prop: 'uv',
      label: '阅读UV',
      width: '100px',
      show:'true'
    },
    {
      prop: 'pvAvg',
      label: '人均阅读数',
      width: '120px',
      show:'true'
    },
    {
      prop: 'rate',
      label: '转化率',
      width: '120px',
      show:'true'
    },
    {
      prop: 'share',
      label: '分享数',
      width: '100px',
      show:'true'
    },
    {
      prop: 'shareRate',
      label: '分享率',
      width: '100px',
      show:'true'
    },
    {
      prop: 'store',
      label: '收藏数',
      width: '100px',
      show:'true'
    },
    {
      prop: 'storeRate',
      label: '收藏率',
      width: '90px',
      show:'true'
    },
    {
      prop: 'comment',
      label: '评论数',
      width: '90px',
      show:'true'
    },
    {
      prop: 'commentRate',
      label: '评论率',
      width: '90px',
      show:'true'
    },
    {
      prop: 'durationUv',
      label: '文章阅读时长人数',
      width: '120px',
      show:'true'
    },
    {
      prop: 'durationAvg',
      label: '人均文章阅读时长(分钟)',
      width: '120px',
      show:'true'
    },
    {
      prop: 'vdurationUv',
      label: '视频观看时长人数',
      width: '120px',
      show:'true'
    },
    {
      prop: 'vdurationAvg',
      label: '人均视频观看时长(分钟)',
      width: '120px',
      show:'true'
    },
    {
      prop: 'expoRate',
      label: '曝光占比',
      width: '100px',
      show:'true'
    },
    {
      prop: 'rate1',
      label: '1日留存',
      width: '100px',
      show:'true'
    },
    {
      prop: 'rate7',
      label: '7日留存',
      width: '100px',
      show:'true'
    }
  ],
  columnsEn1 = [
    {
      prop: 'date',
      label: '日期',
      width: '120px',
      show:'true'
    },
    {
      prop: 'engine',
      label: '引擎标识',
      width: '150px',
      show:'true'
    },
    {
      prop: 'articleCnt',
      label: '文章量',
      width: '90px',
      show:'true'
    },
    {
      prop: 'ev',
      label: '曝光EV',
      width: '120px',
      show:'true'
    },
    {
      prop: 'euv',
      label: '曝光EUV',
      width: '100px',
      show:'true'
    },
    {
      prop: 'evAvg',
      label: '人均曝光量',
      width: '120px',
      show:'true'
    },
    {
      prop: 'pv',
      label: '阅读PV',
      width: '120px',
      show:'true'
    },
    {
      prop: 'uv',
      label: '阅读UV',
      width: '100px',
      show:'true'
    },
    {
      prop: 'pvAvg',
      label: '人均阅读数',
      width: '120px',
      show:'true'
    },
    {
      prop: 'rate',
      label: '转化率',
      width: '120px',
      show:'true'
    },
    {
      prop: 'share',
      label: '分享数',
      width: '100px',
      show:'true'
    },
    {
      prop: 'shareRate',
      label: '分享率',
      width: '100px',
      show:'true'
    },
    {
      prop: 'store',
      label: '收藏数',
      width: '100px',
      show:'true'
    },
    {
      prop: 'storeRate',
      label: '收藏率',
      width: '90px',
      show:'true'
    },
    {
      prop: 'comment',
      label: '评论数',
      width: '90px',
      show:'true'
    },
    {
      prop: 'commentRate',
      label: '评论率',
      width: '90px',
      show:'true'
    },
    {
      prop: 'durationUv',
      label: '文章阅读时长人数',
      width: '120px',
      show:'true'
    },
    {
      prop: 'durationAvg',
      label: '人均文章阅读时长(分钟)',
      width: '120px',
      show:'true'
    },
    {
      prop: 'vDurationUv',
      label: '视频观看时长人数',
      width: '120px',
      show:'true'
    },
    {
      prop: 'vDurationAvg',
      label: '人均视频观看时长(分钟)',
      width: '120px',
      show:'true'
    },
    {
      prop: 'expoRate',
      label: '曝光占比',
      width: '100px',
      show:'true'
    },
    {
      prop: 'rate1',
      label: '1日留存',
      width: '100px',
      show:'true'
    },
    {
      prop: 'rate7',
      label: '7日留存',
      width: '100px',
      show:'true'
    }
  ],
  columns1 = [
    {
      prop: 'date',
      label: '日期',
      width: '120px',
      show:'true'
    },
    {
      prop: 'source',
      label: '数据来源',
      width: '150px',
      show:'true'
    },
    {
      prop: 'articleCnt',
      label: '文章量',
      width: '90px',
      show:'true'
    },
    {
      prop: 'ev',
      label: '曝光EV',
      width: '120px',
      show:'true'
    },
    {
      prop: 'euv',
      label: '曝光EUV',
      width: '100px',
      show:'true'
    },
    {
      prop: 'evAvg',
      label: '人均曝光量',
      width: '120px',
      show:'true'
    },
    {
      prop: 'pv',
      label: '阅读PV',
      width: '120px',
      show:'true'
    },
    {
      prop: 'uv',
      label: '阅读UV',
      width: '100px',
      show:'true'
    },
    {
      prop: 'pvAvg',
      label: '人均阅读数',
      width: '120px',
      show:'true'
    },
    {
      prop: 'rate',
      label: '转化率',
      width: '120px',
      show:'true'
    },
    {
      prop: 'share',
      label: '分享数',
      width: '100px',
      show:'true'
    },
    {
      prop: 'shareRate',
      label: '分享率',
      width: '100px',
      show:'true'
    },
    {
      prop: 'store',
      label: '收藏数',
      width: '100px',
      show:'true'
    },
    {
      prop: 'storeRate',
      label: '收藏率',
      width: '90px',
      show:'true'
    },
    {
      prop: 'comment',
      label: '评论数',
      width: '90px',
      show:'true'
    },
    {
      prop: 'commentRate',
      label: '评论率',
      width: '90px',
      show:'true'
    },
    {
      prop: 'durationUv',
      label: '文章阅读时长人数',
      width: '120px',
      show:'true'
    },
    {
      prop: 'durationAvg',
      label: '人均文章阅读时长(分钟)',
      width: '120px',
      show:'true'
    },
    {
      prop: 'expoRate',
      label: '曝光占比',
      width: '100px',
      show:'true'
    },
    {
      prop: 'rate1',
      label: '1日留存',
      width: '100px',
      show:'true'
    },
    {
      prop: 'rate7',
      label: '7日留存',
      width: '100px',
      show:'true'
    }
  ],
  columns2 = [
    {
      prop: 'date',
      label: '日期',
      width: '120px',
      show:'true'
    },
    {
      prop: 'reason',
      label: '推荐类型',
      width: '150px',
      show:'true'
    },
    {
      prop: 'articleCnt',
      label: '文章量',
      width: '90px',
      show:'true'
    },
    {
      prop: 'ev',
      label: '曝光EV',
      width: '120px',
      show:'true'
    },
    {
      prop: 'euv',
      label: '曝光EUV',
      width: '100px',
      show:'true'
    },
    {
      prop: 'evAvg',
      label: '人均曝光量',
      width: '120px',
      show:'true'
    },
    {
      prop: 'pv',
      label: '阅读PV',
      width: '120px',
      show:'true'
    },
    {
      prop: 'uv',
      label: '阅读UV',
      width: '100px',
      show:'true'
    },
    {
      prop: 'pvAvg',
      label: '人均阅读数',
      width: '120px',
      show:'true'
    },
    {
      prop: 'rate',
      label: '转化率',
      width: '120px',
      show:'true'
    },
    {
      prop: 'share',
      label: '分享数',
      width: '100px',
      show:'true'
    },
    {
      prop: 'shareRate',
      label: '分享率',
      width: '100px',
      show:'true'
    },
    {
      prop: 'store',
      label: '收藏数',
      width: '100px',
      show:'true'
    },
    {
      prop: 'storeRate',
      label: '收藏率',
      width: '90px',
      show:'true'
    },
    {
      prop: 'comment',
      label: '评论数',
      width: '90px',
      show:'true'
    },
    {
      prop: 'commentRate',
      label: '评论率',
      width: '90px',
      show:'true'
    },
    {
      prop: 'durationUv',
      label: '文章阅读时长人数',
      width: '120px',
      show:'true'
    },
    {
      prop: 'durationAvg',
      label: '人均文章阅读时长(分钟)',
      width: '120px',
      show:'true'
    },
    {
      prop: 'expoRate',
      label: '曝光占比',
      width: '100px',
      show:'true'
    },
    {
      prop: 'rate1',
      label: '1日留存',
      width: '100px',
      show:'true'
    },
    {
      prop: 'rate7',
      label: '7日留存',
      width: '100px',
      show:'true'
    }
  ],
  columns3 = [
    {
      prop: 'date',
      label: '日期',
      width: '120px',
      show:'true'
    },
    {
      prop: 'type',
      label: '文章类型',
      width: '150px',
      show:'true'
    },
    {
      prop: 'articleCnt',
      label: '文章量',
      width: '90px',
      show:'true'
    },
    {
      prop: 'ev',
      label: '曝光EV',
      width: '120px',
      show:'true'
    },
    {
      prop: 'euv',
      label: '曝光EUV',
      width: '100px',
      show:'true'
    },
    {
      prop: 'evAvg',
      label: '人均曝光量',
      width: '120px',
      show:'true'
    },
    {
      prop: 'pv',
      label: '阅读PV',
      width: '120px',
      show:'true'
    },
    {
      prop: 'uv',
      label: '阅读UV',
      width: '100px',
      show:'true'
    },
    {
      prop: 'pvAvg',
      label: '人均阅读数',
      width: '120px',
      show:'true'
    },
    {
      prop: 'rate',
      label: '转化率',
      width: '120px',
      show:'true'
    },
    {
      prop: 'share',
      label: '分享数',
      width: '100px',
      show:'true'
    },
    {
      prop: 'shareRate',
      label: '分享率',
      width: '100px',
      show:'true'
    },
    {
      prop: 'store',
      label: '收藏数',
      width: '100px',
      show:'true'
    },
    {
      prop: 'storeRate',
      label: '收藏率',
      width: '90px',
      show:'true'
    },
    {
      prop: 'comment',
      label: '评论数',
      width: '90px',
      show:'true'
    },
    {
      prop: 'commentRate',
      label: '评论率',
      width: '90px',
      show:'true'
    },
    {
      prop: 'durationUv',
      label: '文章阅读时长人数',
      width: '120px',
      show:'true'
    },
    {
      prop: 'durationAvg',
      label: '人均文章阅读时长(分钟)',
      width: '120px',
      show:'true'
    },
    {
      prop: 'expoRate',
      label: '曝光占比',
      width: '100px',
      show:'true'
    },
    {
      prop: 'rate1',
      label: '1日留存',
      width: '100px',
      show:'true'
    },
    {
      prop: 'rate7',
      label: '7日留存',
      width: '100px',
      show:'true'
    }
  ],
  tableData = [],
  tableDataAll = [],
  tableDataAllDate = [],//日期
  tableDataAllSource = [],//数据来源
  tableDataAllArticleCnt = [],//文章量
  tableDataAllEv = [],//曝光EV
  tableDataAllEuv = [],//曝光EUV
  tableDataAllEvAvg = [],//人均曝光量
  tableDataAllPv = [],//阅读PV
  tableDataAllUv = [],//阅读UV
  tableDataAllPvAvg = [],//人均阅读数
  tableDataAllRate = [],//转化率
  tableDataAllShare = [],//分享数
  tableDataAllShareRate = [],//分享率
  tableDataAllStore = [],//收藏数
  tableDataAllStoreRate = [],//收藏率
  tableDataAllComment = [],//评论数
  tableDataAllcommentRate = [],//评论率
  tableDataAllDurationUv = [],//文章阅读时长人数
  tableDataAllDurationAvg = [],//人均文章阅读时长(分钟)
  tableDataAllVdurationUv = [],//文章阅读时长人数
  tableDataAllVdurationAvg = [],//人均文章阅读时长(分钟)
  tableDataAllExpoRate = [],//曝光占比

  tableDataAlltype1 = [],//类型1
  tableDataAlltype2 = [],//类型2
  tableDataAlltype3 = [],//类型3
  tableDataAlltype4 = [],//类型4
  tableDataAlltype5 = [],//类型5
  tableDataAlltype6 = [],//类型6
  tableDataAlltype7 = [],//类型7
  tableDataAlltype8 = [],//类型8
  tableDataAlltype9 = [],//类型9
  tableDataAlltype10 = [],//类型1
  tableDataAlltype11 = [],//类型2
  tableDataAlltype12 = [],//类型3
  tableDataAlltype13= [],//类型4
  tableDataAlltype14= [],//类型5
  tableDataAlltype15= [],//类型6
  tableDataAlltype16= [],//类型7
  tableDataAlltype17= [],//类型8
  tableDataAlltype18= [],//类型9
  tableDataAlltypeTime=[];
export default {
  data () {
    return {
      isLoading: false,
      tableType:tableType,
      tableTypeChart:tableTypeChart,
      save: save,
      optionFlow:optionFlow,
      option: option,
      optionsFlow:optionsFlow,
      options:options,
      input: input,
      inputdep:inputdep,
      myChart:myChart,
      myChart1:myChart1,
      myChart2:myChart2,
      myChart3:myChart3,
      startDate: startDate,
      endDate: endDate,
      pageSize: pageSize,
      pageCurr: pageCurr,
      checkedCh:checkedCh,
      columns: columns,
      columnsEn:columnsEn,
      tableData: tableData,
      tableDataAll: tableDataAll,
      tableDataAllDate: tableDataAllDate,
      tableDataAllSource: tableDataAllSource,
      tableDataAllArticleCnt: tableDataAllArticleCnt,
      tableDataAllEv: tableDataAllEv,
      tableDataAllEuv: tableDataAllEuv,
      tableDataAllEvAvg: tableDataAllEvAvg,
      tableDataAllPv: tableDataAllPv,
      tableDataAllUv: tableDataAllUv,
      tableDataAllPvAvg: tableDataAllPvAvg,
      tableDataAllRate: tableDataAllRate,
      tableDataAllShare: tableDataAllShare,
      tableDataAllShareRate: tableDataAllShareRate,
      tableDataAllStore: tableDataAllStore,
      tableDataAllStoreRate: tableDataAllStoreRate,
      tableDataAllcommentRate: tableDataAllcommentRate,
      tableDataAllComment: tableDataAllComment,
      tableDataAllDurationUv: tableDataAllDurationUv,
      tableDataAllDurationAvg: tableDataAllDurationAvg,
      tableDataAllVdurationUv: tableDataAllVdurationUv,
      tableDataAllVdurationAvg: tableDataAllVdurationAvg,
      tableDataAllExpoRate: tableDataAllExpoRate,

      tableDataAlltypeTime:tableDataAlltypeTime,
      tableDataAlltype1:tableDataAlltype1,
      tableDataAlltype2:tableDataAlltype2,
      tableDataAlltype3:tableDataAlltype3,
      tableDataAlltype4:tableDataAlltype4,
      tableDataAlltype5:tableDataAlltype5,
      tableDataAlltype6 :tableDataAlltype6,
      tableDataAlltype7 :tableDataAlltype7,
      tableDataAlltype8 :tableDataAlltype8,
      tableDataAlltype9 :tableDataAlltype9,
      tableDataAlltype10:tableDataAlltype10,
      tableDataAlltype11:tableDataAlltype11,
      tableDataAlltype12:tableDataAlltype12,
      tableDataAlltype13:tableDataAlltype13,
      tableDataAlltype14:tableDataAlltype14,
      tableDataAlltype15:tableDataAlltype15,
      tableDataAlltype16:tableDataAlltype16,
      tableDataAlltype17:tableDataAlltype17,
      tableDataAlltype18:tableDataAlltype18
    }
  },
  methods: {
    //图标部分方法
    getChart(count,category){
       if ((this.startDate) && (this.endDate)) {
        } else {
          this.startDate = this.getDay(-30);
          this.endDate = this.getDay(0);
        }
        console.log(this.startDate)
        console.log(this.endDate)
        var urlChart='http://10.80.128.150:58080/rec_headline/'+this.option+'/single?startDate='+this.startDate+'&endDate='+this.endDate+'&refType=all&key='+category;
         this.gettype(urlChart,category)
         console.log(urlChart)
         console.log(category)
      if(count==0){
        this.checkedCh=0;
       
      }else if(count==1){
        this.checkedCh=1;

      }else if(count==2){
        this.checkedCh=2;

      }else if(count==3){
        this.checkedCh=3;

      }else if(count==4){
        this.checkedCh=4;

      }else if(count==5){
        this.checkedCh=5;

      }else if(count==6){
        this.checkedCh=6;

      }else if(count==7){
        this.checkedCh=7;

      }

    },
    //获取分组数据
    gettype(url,category){
      this.tableDataAlltype1.length=0;
      this.tableDataAlltype2.length=0;
      this.tableDataAlltype3.length=0;
      this.tableDataAlltype4.length=0;
      this.tableDataAlltype5.length=0;
      this.tableDataAlltype6.length=0;
      this.tableDataAlltype7.length=0;
      this.tableDataAlltype8.length=0;
      this.tableDataAlltype9.length=0;
      this.tableDataAlltype10.length=0;
      this.tableDataAlltype11.length=0;
      this.tableDataAlltype12.length=0;
      this.tableDataAlltype13.length=0;
      this.tableDataAlltype14.length=0;
      this.tableDataAlltype15.length=0;
      this.tableDataAlltype16.length=0;
      this.tableDataAlltype17.length=0;
      this.tableDataAlltype18.length=0;
      var that=this;
      this.tableDataAlltypeTime.length=0;
      this.$http.get(url).then((response)=>{
        console.log(response.data)
        console.log(category)
        $.each(response.data,function(index,item){
          $.each(item,function(index1,item1){
            if(item1.source=='nillDeepChel'){
              tableDataAlltype1.push(item1[category])
              
            }else if(item1.source=='nillContentMatch'){
              tableDataAlltype2.push(item1[category])
            }else if(item1.source=='nillPreferSource'){
              tableDataAlltype3.push(item1[category])
            }else if(item1.source=='nillCF'){
              tableDataAlltype4.push(item1[category])
            }else if(item1.source=='perfectNewContentMatch'){
              tableDataAlltype5.push(item1[category])
            }else if(item1.source=='perfectNewPreferSource'){
              tableDataAlltype6.push(item1[category])
            }else if(item1.source=='perfectNew'){
              tableDataAlltype7.push(item1[category])
            }else if(item1.source=='jpPool'){
              tableDataAlltype8.push(item1[category])
            }else if(item1.source=='bidding'){
              tableDataAlltype9.push(item1[category])
            }else if(item1.source=='perfectNewCF'){
              tableDataAlltype10.push(item1[category])
            }else if(item1.source=='MultiAlgMixRank'){
              tableDataAlltype11.push(item1[category])
            }else if(item1.source=='perfectNewDeepChel'){
              tableDataAlltype12.push(item1[category])
            }else if(item1.source=='videoRecomMachine'){
              tableDataAlltype13.push(item1[category])
            }else if(item1.source=='preload'){
              tableDataAlltype14.push(item1[category])
            }else if(item1.source=='editor'){
              tableDataAlltype15.push(item1[category])
              var date=that.getDayDate(item1.date)
              tableDataAlltypeTime.push(date)
            }else if(item1.source=='video'){
              tableDataAlltype16.push(item1[category])
            }else if(item1.source=='perfectOld'){
              tableDataAlltype17.push(item1[category])
            }else if(item1.source=='slide'){
              tableDataAlltype18.push(item1[category])
            }else if(item1.reason=='corec'){//推荐原因
              tableDataAlltype1.push(item1[category])
            }else if(item1.reason=='insert'){//推荐原因
              tableDataAlltype2.push(item1[category])
            }else if(item1.reason=='recom'){//推荐原因
              tableDataAlltype3.push(item1[category])
            }else if(item1.reason=='bidding'){//推荐原因
              tableDataAlltype4.push(item1[category])
            }else if(item1.reason=='MultiAlgMixRank'){//推荐原因
              tableDataAlltype5.push(item1[category])
            }else if(item1.reason=='local'){//推荐原因
              tableDataAlltype6.push(item1[category])
            }else if(item1.reason=='video'){//推荐原因
              tableDataAlltype7.push(item1[category])
            }else if(item1.reason=='editor'){//推荐原因
              var date=that.getDayDate(item1.date)
              tableDataAlltypeTime.push(date)
              tableDataAlltype8.push(item1[category])
            }else if(item1.reason=='hot'){//推荐原因
              tableDataAlltype9.push(item1[category])
            }else if(item1.reason=='cold'){//推荐原因
              tableDataAlltype10.push(item1[category])
            }else if(item1.reason=='view'){//推荐原因
              tableDataAlltype11.push(item1[category])
            }else if(item1.reason=='supply'){//推荐原因
              tableDataAlltype12.push(item1[category])
            }else if(item1.type=='doc'){//文章类型
              tableDataAlltype1.push(item1[category])
              var date=that.getDayDate(item1.date)
              tableDataAlltypeTime.push(date)
            }else if(item1.type=='video'){//文章类型
              tableDataAlltype2.push(item1[category])
            }else if(item1.type=='docpic'){//文章类型
              tableDataAlltype3.push(item1[category])
            }else if(item1.type=='article'){//文章类型
              tableDataAlltype4.push(item1[category])
            }else if(item1.type=='phvideo'){//文章类型
              tableDataAlltype5.push(item1[category])
            }else if(item1.type=='slide'){//文章类型
              tableDataAlltype6.push(item1[category])
            }else if(item1.type=='topic2'){//文章类型
              tableDataAlltype7.push(item1[category])
            }else if(item1.type=='text_live'){//文章类型
              tableDataAlltype8.push(item1[category])
            }else if(item1.engine=='baseline'){//引擎标识
              tableDataAlltype1.push(item1[category])
              
            }else if(item1.engine=='baseline_ctr'){//引擎标识
              tableDataAlltype2.push(item1[category])
            }else if(item1.engine=='editorJpPool'){//引擎标识
              tableDataAlltype3.push(item1[category])
            }else if(item1.engine=='baseline_ctr_headline_0718|1'){//引擎标识
              tableDataAlltype4.push(item1[category])
            }else if(item1.engine=='baseline_ctr_headline_0601|1'){//引擎标识
              tableDataAlltype5.push(item1[category])
            }else if(item1.engine=='baseline_ctr_exp-NoModel|1'){//引擎标识
              tableDataAlltype6.push(item1[category])
            }else if(item1.engine=='videoChannel'){//引擎标识
              tableDataAlltype7.push(item1[category])
            }else if(item1.engine=='exp'){//引擎标识
              tableDataAlltype8.push(item1[category])
            }else if(item1.engine=='restruct'){//引擎标识
              tableDataAlltype9.push(item1[category])
              var date=that.getDayDate(item1.date)
              tableDataAlltypeTime.push(date)
            }
          })
        })
      })
      console.log(tableDataAlltype1)
      console.log(tableDataAlltype2)
      console.log(tableDataAlltype3)
      console.log(tableDataAlltype4)
      console.log(tableDataAlltype5)
    },
    //download
    handleClick(ev) {
      if(this.tableTypeChart==0){//source
           var url='http://10.80.128.150:58080/rec_headline/source/excel?startDate='+this.startDate+'&endDate='+this.endDate+'&refType=all&col='+encodeURI(JSON.stringify(columns1))
            window.open(url);
      }else if(this.tableTypeChart==1){//reason
            var url='http://10.80.128.150:58080/rec_headline/reason/excel?startDate='+this.startDate+'&endDate='+this.endDate+'&refType=all&col='+encodeURI(JSON.stringify(columns2))
            window.open(url);
      }else if(this.tableTypeChart==2){//type
            
            var url='http://10.80.128.150:58080/rec_headline/type/excel?startDate='+this.startDate+'&endDate='+this.endDate+'&refType=all&col='+encodeURI(JSON.stringify(columns3))
            window.open(url);
      }else{//engine
            var url='http://10.80.128.150:58080/rec_headline/engine/excel?startDate='+this.startDate+'&endDate='+this.endDate+'&refType=all&col='+encodeURI(JSON.stringify(columnsEn1))
            window.open(url);
      }
     
    },
    handleSelectChangeFlow(){

      if(this.option=='source'){
        this.tableType=1;
        this.tableTypeChart=0;
        $.each(this.columns,function(index,item){
          if(item.label=='数据来源'){
            item.show='true'
          }
          if(item.label=='推荐类型'){
            item.show='false'
          }
          if(item.label=='引擎标识'){
            item.show='false'
          }
          if(item.label=='文章类型'){
            item.show='false'
          }
          if(item.label=='视频观看时长人数'){
            item.show='false'
          }
          if(item.label=='人均视频观看时长(分钟)'){
            item.show='false'
          }
        })
      }
      if(this.option=='reason'){
        this.tableType=1;
        this.tableTypeChart=1;
        $.each(this.columns,function(index,item){
          if(item.label=='数据来源'){
            item.show='false'
          }
          if(item.label=='推荐类型'){
            item.show='true'
          }
          if(item.label=='引擎标识'){
            item.show='false'
          }
          if(item.label=='文章类型'){
            item.show='false'
          }
          if(item.label=='视频观看时长人数'){
            item.show='false'
          }
          if(item.label=='人均视频观看时长(分钟)'){
            item.show='false'
          }
        })
      }
      if(this.option=='type'){
        this.tableType=1;
        this.tableTypeChart=2;
        $.each(this.columns,function(index,item){
          if(item.label=='数据来源'){
            item.show='false'
          }
          if(item.label=='推荐类型'){
            item.show='false'
          }
          if(item.label=='引擎标识'){
            item.show='false'
          }
          if(item.label=='文章类型'){
            item.show='true'
          }
          if(item.label=='视频观看时长人数'){
            item.show='false'
          }
          if(item.label=='人均视频观看时长(分钟)'){
            item.show='false'
          }
        })
      }
      if(this.option=='engine'){
        this.tableType=0;
        this.tableTypeChart=3;
        $.each(this.columns,function(index,item){
          if(item.label=='数据来源'){
            item.show='false'
          }
          if(item.label=='推荐类型'){
            item.show='false'
          }
          if(item.label=='引擎标识'){
            item.show='true'
          }
          if(item.label=='文章类型'){
            item.show='false'
          }
          if(item.label=='视频观看时长人数'){
            item.show='true'
          }
          if(item.label=='人均视频观看时长(分钟)'){
            item.show='true'
          }
        })
      }
      
      if ((this.startDate) && (this.endDate)) {
        } else {
          this.startDate = this.getDay(-30);
          this.endDate = this.getDay(0);
        }
      var url = 'http://10.80.128.150:58080/rec_headline/'+this.option+'?startDate='+this.startDate+'&endDate='+this.endDate+'&refType='+this.optionFlow;
      
      this.getJSON(url);
      this.getChart(0,'articleCnt')
    },
    // 选择
    handleSelectChange() {
      if(this.option=='source'){
         this.tableType=1;
         this.tableTypeChart=0;
        $.each(this.columns,function(index,item){
          if(item.label=='数据来源'){
            item.show='true'
          }
          if(item.label=='推荐类型'){
            item.show='false'
          }
          if(item.label=='引擎标识'){
            item.show='false'
          }
          if(item.label=='文章类型'){
            item.show='false'
          }
          if(item.label=='视频观看时长人数'){
            item.show='false'
          }
          if(item.label=='人均视频观看时长(分钟)'){
            item.show='false'
          }
        })
      }
      if(this.option=='reason'){
         this.tableType=1;
         this.tableTypeChart=1;
        $.each(this.columns,function(index,item){
          if(item.label=='数据来源'){
            item.show='false'
          }
          if(item.label=='推荐类型'){
            item.show='true'
          }
          if(item.label=='引擎标识'){
            item.show='false'
          }
          if(item.label=='文章类型'){
            item.show='false'
          }
          if(item.label=='视频观看时长人数'){
            item.show='false'
          }
          if(item.label=='人均视频观看时长(分钟)'){
            item.show='false'
          }
        })
      }
      if(this.option=='type'){
        this.tableType=1;
        this.tableTypeChart=2;
        $.each(this.columns,function(index,item){
          if(item.label=='数据来源'){
            item.show='false'
          }
          if(item.label=='推荐类型'){
            item.show='false'
          }
          if(item.label=='引擎标识'){
            item.show='false'
          }
          if(item.label=='文章类型'){
            item.show='true'
          }
          if(item.label=='视频观看时长人数'){
            item.show='false'
          }
          if(item.label=='人均视频观看时长(分钟)'){
            item.show='false'
          }
        })
      }
      if(this.option=='engine'){
        this.tableType=0;
        this.tableTypeChart=3;
        $.each(this.columns,function(index,item){
          if(item.label=='数据来源'){
            item.show='false'
          }
          if(item.label=='推荐类型'){
            item.show='false'
          }
          if(item.label=='引擎标识'){
            item.show='true'
          }
          if(item.label=='文章类型'){
            item.show='false'
          }
          if(item.label=='视频观看时长人数'){
            item.show='true'
          }
          if(item.label=='人均视频观看时长(分钟)'){
            item.show='true'
          }
        })
      }
      if ((this.startDate) && (this.endDate)) {
        } else {
          this.startDate = this.getDay(-30);
          this.endDate = this.getDay(0);
        }
      var url = 'http://10.80.128.150:58080/rec_headline/'+this.option+'?startDate='+this.startDate+'&endDate='+this.endDate+'&refType='+this.optionFlow;
      
      this.getJSON(url);
      this.getChart(0,'articleCnt')
    },
    // 选择
    handleChange(val) {
      this.startDate = val.slice(0, 10);
      this.endDate = val.slice(13, 23);
      var url = 'http://10.80.128.150:58080/rec_headline/'+this.option+'?startDate='+this.startDate+'&endDate='+this.endDate+'&refType='+this.optionFlow;
      this.getJSON(url,'articleCnt');
      this.getChart(0,'articleCnt')
      /*this.getJSON();*/
    },
    // 分页
    handleSizeChange(val) {
      this.pageSize = val;
      this.pageCurr = 1;
      tableData.splice(0, tableData.length);
      console.log(tableDataAll.length)
      console.log(val)
      val=val>=tableDataAll.length?tableDataAll.length:val
      console.log(val)
      for (var i = 0; i < val; i++) {
        var line = tableDataAll[i];
        line['newArticle'] = line['newArticle'];
        line['ev'] = line['ev'];
        line['euv'] = line['euv'];
        line['ev_avg'] = line['ev_avg'];
        line['pv'] = line['pv'];
        line['ch_pv'] = line['ch_pv'];
        line['ch_uv'] = line['ch_uv'];
        line['pv_avg'] = line['pv_avg'];
        line['ch_pv_avg'] = line['ch_pv_avg'];
        line['duration_avg'] = line['duration_avg'];
        line['share'] = line['share'];
        line['store'] = line['store'];
        line['comment'] = line['comment'];
        line['reason'] = line['reason'];
        line['type'] = line['type'];
        line['engine'] = line['engine'];
        tableData.push(tableDataAll[i]);
      }
    },
    // 换页
    handleCurrentChange(val) {
      this.pageCurr = val;
      tableData.splice(0, tableData.length);
      var end = (tableDataAll.length > (this.pageCurr)*(this.pageSize)) ? (this.pageCurr)*(this.pageSize) : tableDataAll.length;
      for (var i = (this.pageCurr-1)*(this.pageSize); i < end; i++) {
        var line = tableDataAll[i];
        line['newArticle'] = line['newArticle'];
        line['ev'] = line['ev'];
        line['euv'] = line['euv'];
        line['ev_avg'] = line['ev_avg'];
        line['pv'] = line['pv'];
        line['ch_pv'] = line['ch_pv'];
        line['ch_uv'] = line['ch_uv'];
        line['pv_avg'] = line['pv_avg'];
        line['ch_pv_avg'] = line['ch_pv_avg'];
        line['duration_avg'] = line['duration_avg'];
        line['share'] = line['share'];
        line['store'] = line['store'];
        line['comment'] = line['comment'];
        line['reason'] = line['reason'];
        line['type'] = line['type'];
        line['engine'] = line['engine'];
        tableData.push(tableDataAll[i]);
      }
    },
    tableRowClassName(row, index) {
      if (index%2 != 0) {
        return 'odd-row';
      } else if (index%2 == 0) {
        return 'even-row';
      }
      return '';
    },
    getDay: function (day) {
      var today = new Date();
      var target = today.getTime()+1000*60*60*24*day;
      today.setTime(target);
      var year = today.getFullYear();
      var month = today.getMonth();
      var date = today.getDate();
      month = this.addZero(month+1);
      date = this.addZero(date);
      return year.toString()+'-'+month.toString()+'-'+date.toString();
    },
    getDayDate: function (day) {
      var today = new Date(day);
      var year = today.getFullYear();
      var month = today.getMonth();
      var date = today.getDate();
      month = this.addZero(month+1);
      date = this.addZero(date);
      return year.toString()+'/'+month.toString()+'/'+date.toString();
    },
    addZero: function (time) {
      if (time.toString().length == 1) {
        time = '0'+time;
      }
      return time;
    },
    getJSON: function (url) {
      this.isLoading = true;
      var map = new Map();
      this.$http.get(url).then((response) => {
        this.isLoading = false;
        tableDataAll.splice(0, tableDataAll.length);
        tableDataAllDate.splice(0, tableDataAllDate.length);
        tableDataAllSource.splice(0, tableDataAllSource.length);
        tableDataAllArticleCnt.splice(0, tableDataAllArticleCnt.length);
        tableDataAllEv.splice(0, tableDataAllEv.length);
        tableDataAllEuv.splice(0, tableDataAllEuv.length);
        tableDataAllEvAvg.splice(0, tableDataAllEvAvg.length);
        tableDataAllPv.splice(0, tableDataAllPv.length);
        tableDataAllUv.splice(0, tableDataAllUv.length);
        tableDataAllPvAvg.splice(0, tableDataAllPvAvg.length);
        tableDataAllRate.splice(0, tableDataAllRate.length);
        tableDataAllShare.splice(0, tableDataAllShare.length);
        tableDataAllShareRate.splice(0, tableDataAllShareRate.length);
        tableDataAllStore.splice(0, tableDataAllStore.length);
        tableDataAllStoreRate.splice(0, tableDataAllStoreRate.length);
        tableDataAllComment.splice(0, tableDataAllComment.length);
        tableDataAllcommentRate.splice(0, tableDataAllcommentRate.length);
        tableDataAllDurationUv.splice(0, tableDataAllDurationUv.length);
        tableDataAllDurationAvg.splice(0, tableDataAllDurationAvg.length);
        tableDataAllVdurationUv.splice(0, tableDataAllVdurationUv.length);
        tableDataAllVdurationAvg.splice(0, tableDataAllVdurationAvg.length);
        var temps = response.data;
        for (var i in temps) {
          var temp = temps[i];
          var line = {};
          line['date'] = this.getDayDate(temp['date']);
          line['source'] = temp['source'];
          line['articleCnt'] = temp['articleCnt'];
          line['ev'] = temp['ev'];
          line['euv'] = temp['euv'];
          line['evAvg'] = temp['evAvg'].toFixed(3);
          line['pv'] = temp['pv'];
          line['uv'] = temp['uv'];
          line['pvAvg'] = temp['pvAvg'].toFixed(3);
          line['rate'] = (temp['rate']*100).toFixed(3)+'%';
          line['share'] = temp['share'];
          line['shareRate'] = (temp['shareRate']*100).toFixed(3)+'%';
          line['store'] = temp['store'];
          line['storeRate'] = (temp['storeRate']*100).toFixed(3)+'%';
          line['comment'] = temp['comment'];
          line['commentRate'] = (temp['commentRate']*100).toFixed(3)+'%';
          line['durationUv'] = temp['durationUv'];
          line['durationAvg'] = temp['durationAvg'].toFixed(3);
          line['vdurationUv'] = temp['vdurationUv']?temp['vdurationUv']:0;
          line['vdurationAvg'] = temp['vdurationAvg']?temp['vdurationAvg'].toFixed(3):0;
          line['expoRate'] = (temp['expoRate']*100).toFixed(3)+'%';
          line['rate1'] = (temp['rate1']*100).toFixed(3)+'%';
          line['rate7'] = (temp['rate7']*100).toFixed(3)+'%';
          line['reason'] = temp['reason'];
          line['type'] = temp['type'];
          line['engine'] = temp['engine'];
          tableDataAll.push(line);
          tableDataAllDate.push(line['date']);
          tableDataAllSource.push(line['source']);
          tableDataAllArticleCnt.push(line['articleCnt']);
          tableDataAllEv.push(line['ev']);
          tableDataAllEuv.push(line['euv']);
          tableDataAllEvAvg.push(line['evAvg']);
          tableDataAllPv.push(line['pv']);
          tableDataAllUv.push(line['uv']);
          tableDataAllPvAvg.push(line['pvAvg']);
          tableDataAllRate.push(parseFloat(line['rate']));
          tableDataAllShare.push(parseFloat(line['share']));
          tableDataAllShareRate.push(line['shareRate']);
          tableDataAllStore.push(line['store']);
          tableDataAllStoreRate.push(line['storeRate']);
          tableDataAllComment.push(line['comment']);
          tableDataAllcommentRate.push(line['commentRate']);
          tableDataAllDurationUv.push(line['durationUv']);
          tableDataAllDurationAvg.push(line['durationUv']);
          
          tableDataAllVdurationUv.push(line['vdurationUv']);
          tableDataAllVdurationAvg.push(line['vdurationAvg']);
          tableDataAllExpoRate.push(line['expoRate']);
          
        }
        tableData.splice(0, tableData.length);
        if (tableDataAll.length < 5) {
          this.pageSize = tableDataAll.length;
        } else {
          this.pageSize = 10;
        }
        for (var i = 0; i < this.pageSize; i++) {
          var line = tableDataAll[i];
          line['date'] = this.getDayDate(line['date']);
          line['source'] = line['source'];
          line['articleCnt'] = line['articleCnt'];
          line['ev'] = line['ev'];
          line['euv'] = line['euv'];
          line['evAvg'] = line['evAvg'];
          line['pv'] = line['pv'];
          line['uv'] = line['uv'];
          line['pvAvg'] = line['pvAvg'];
          line['rate'] = line['rate'];
          line['share'] = line['share'];
          line['shareRate'] = line['shareRate'];
          line['store'] = line['store'];
          line['storeRate'] = line['storeRate'];
          line['comment'] = line['comment'];
          line['commentRate'] =line['commentRate'];
          line['durationUv'] = line['durationUv'];
          line['durationAvg'] = line['durationAvg'];
          line['vdurationUv'] = line['vdurationUv'];
          line['vdurationAvg'] = line['vdurationAvg'];
          line['expoRate'] = line['expoRate'];
          line['rate1'] = line['rate1'];
          line['rate7'] = line['rate7'];
          line['reason'] = line['reason'];
          line['type'] = line['type'];
          line['engine'] = line['engine'];
          tableData.push(tableDataAll[i]);
        }
      })
    }

  },
  created: function () {
        $.each(this.columns,function(index,item){
          if(item.label=='推荐类型'){
            item.show='false'
          }
          if(item.label=='引擎标识'){
            item.show='false'
          }
          if(item.label=='文章类型'){
            item.show='false'
          }
          if(item.label=='视频观看时长人数'){
            item.show='false'
          }
          if(item.label=='人均视频观看时长(分钟)'){
            item.show='false'
          }
        })
        if ((this.startDate) && (this.endDate)) {
        } else {
          this.startDate = this.getDay(-30);
          this.endDate = this.getDay(0);
        }
        
      var url = 'http://10.80.128.150:58080/rec_headline/source?startDate='+this.startDate+'&endDate='+this.endDate+'&refType=all';
        this.getJSON(url);
      var urlChart='http://10.80.128.150:58080/rec_headline/source/single?startDate='+this.startDate+'&endDate='+this.endDate+'&refType=all&key=articleCnt'
        this.gettype(urlChart,'articleCnt')
  },
  beforeUpdate: function () {
    var option = {
      legend: {
        left: 'center',
        data: [ 'nillDeepChel', 'nillContentMatch', 'nillPreferSource', 'nillCF', 'perfectNewContentMatch', 'perfectNewPreferSource', 'perfectNew', 'jpPool', 'bidding', 'perfectNewCF', 'MultiAlgMixRank', 'perfectNewDeepChel', 'videoRecomMachine', 'preload','editor', 'video','perfectOld','slide'],
        selectedMode: 'multiple',
        selected: {  
                    'nillDeepChel': true,  
                    'nillContentMatch': false,  
                    'nillPreferSource': false,  
                    'nillCF': false,  
                    'perfectNewContentMatch': false,  
                    'perfectNewPreferSource': false ,
                    'perfectNew': false,  
                    'jpPool': false,
                    'bidding': false,  
                    'perfectNewCF': false,  
                    'MultiAlgMixRank': false,  
                    'perfectNewDeepChel': false,  
                    'videoRecomMachine': false,  
                    'preload': false,
                    'editor': false,  
                    'video': false, 
                    'perfectOld': false,  
                    'slide': false
                }  
      },
      grid: {
        top:'20%',
        left: '2%',
        right: '4%',
        bottom: '3%',
        containLabel: true
    },
      tooltip: {
        trigger: 'axis',
        position: function (pt) {
          return [pt[0]-100, '10%'];
        }
      },
      toolbox: {
        right:'2%',
        top:'8%',
        show: true,
        feature : {
            mark : {show: true},
            dataZoom : {show: true},
            magicType: {type: ['line', 'bar']},
            restore : {show: true},
            saveAsImage : {show: true}
        }
    },
      xAxis: {
        type: 'category',
        boundaryGap: false,
        data: this.tableDataAlltypeTime
      },
      yAxis: {
        type: 'value',
        boundaryGap: [0, '30%']
      },
      dataZoom: [
        {
          type: 'slider',
          show: true,
          xAxisIndex: [0],
          start: 0,
          end: 100
        },
        {
          type: 'inside',
          xAxisIndex: [0],
          start: 0,
          end: 100
        }
      ],

      series: [
        {
          name: 'nillDeepChel',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.tableDataAlltype1
        },
        {
          name: 'nillContentMatch',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.tableDataAlltype2
        },
        {
          name: 'nillPreferSource',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.tableDataAlltype3
        },
        {
          name: 'nillCF',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.tableDataAlltype4
        },
        {
          name: 'perfectNewContentMatch',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.tableDataAlltype5
        },
        {
          name: 'perfectNewPreferSource',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.tableDataAlltype6
        },
        {
          name: 'perfectNew',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.tableDataAlltype7
        },
        {
          name: 'jpPool',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.tableDataAlltype8
        },
        {
          name: 'bidding',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.tableDataAlltype9
        },
        {
          name: 'perfectNewCF',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.tableDataAlltype10
        },
        {
          name: 'MultiAlgMixRank',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.tableDataAlltype11
        },
        {
          name: 'perfectNewDeepChel',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.tableDataAlltype12
        },
        {
          name: 'videoRecomMachine',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.tableDataAlltype13
        },
        {
          name: 'preload',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.tableDataAlltype14
        },
        {
          name: 'editor',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.tableDataAlltype15
        },
        {
          name: 'video',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.tableDataAlltype16
        },
        {
          name: 'perfectOld',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.tableDataAlltype17
        },
        {
          name: 'slide',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.tableDataAlltype18
        }
      ]
    };
    myChart = echarts.init(document.getElementById('channelArea'));
    myChart.setOption(option);

    //myChart1

    var option1 = {
      legend: {
        left: 'center',
        data: [ 'corec', 'insert', 'recom', 'bidding', 'MultiAlgMixRank', 'local', 'video', 'editor', 'hot', 'cold', 'view', 'supply'],
        selectedMode: 'multiple',
        selected: {  
                    'corec': true,  
                    'insert': false,  
                    'recom': false,  
                    'bidding': false,  
                    'MultiAlgMixRank': false,  
                    'local': false ,
                    'video': false,  
                    'editor': false,
                    'hot': false,  
                    'cold': false,  
                    'view': false,  
                    'supply': false
                }  
      },
      grid: {
        top:'20%',
        left: '2%',
        right: '4%',
        bottom: '3%',
        containLabel: true
    },
      tooltip: {
        trigger: 'axis',
        position: function (pt) {
          return [pt[0]-100, '10%'];
        }
      },
      toolbox: {
        right:'2%',
        top:'8%',
        show: true,
        feature : {
            mark : {show: true},
            dataZoom : {show: true},
            magicType: {type: ['line', 'bar']},
            restore : {show: true},
            saveAsImage : {show: true}
        }
    },
      xAxis: {
        type: 'category',
        boundaryGap: false,
        data: this.tableDataAlltypeTime
      },
      yAxis: {
        type: 'value',
        boundaryGap: [0, '30%']
      },
      dataZoom: [
        {
          type: 'slider',
          show: true,
          xAxisIndex: [0],
          start: 0,
          end: 100
        },
        {
          type: 'inside',
          xAxisIndex: [0],
          start: 0,
          end: 100
        }
      ],

      series: [
        {
          name: 'corec',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.tableDataAlltype1
        },
        {
          name: 'insert',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.tableDataAlltype2
        },
        {
          name: 'recom',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.tableDataAlltype3
        },
        {
          name: 'bidding',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.tableDataAlltype4
        },
        {
          name: 'MultiAlgMixRank',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.tableDataAlltype5
        },
        {
          name: 'local',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.tableDataAlltype6
        },
        {
          name: 'video',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.tableDataAlltype7
        },
        {
          name: 'editor',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.tableDataAlltype8
        },
        {
          name: 'hot',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.tableDataAlltype9
        },
        {
          name: 'cold',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.tableDataAlltype10
        },
        {
          name: 'view',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.tableDataAlltype11
        },
        {
          name: 'supply',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.tableDataAlltype12
        }
      ]
    };
    this.$nextTick(() => {
      myChart1 = echarts.init(document.getElementById('channelArea1'));
      myChart1.setOption(option1);
      myChart1.resize();
    })
    

    //myChart1

    var option2 = {
      legend: {
        left: 'center',
        data: [ 'doc', 'video', 'docpic', 'article', 'phvideo', 'slide', 'topic2','text_live'],
        selectedMode: 'multiple',
        selected: {  
                    'doc': true,  
                    'video': false,  
                    'docpic': false,  
                    'article': false,  
                    'phvideo': false,  
                    'slide': false ,
                    'topic2': false, 
                    'text_live':false 

                }  
      },
      grid: {
        top:'20%',
        left: '2%',
        right: '4%',
        bottom: '3%',
        containLabel: true
    },
      tooltip: {
        trigger: 'axis',
        position: function (pt) {
          return [pt[0]-100, '10%'];
        }
      },
      toolbox: {
        right:'2%',
        top:'8%',
        show: true,
        feature : {
            mark : {show: true},
            dataZoom : {show: true},
            magicType: {type: ['line', 'bar']},
            restore : {show: true},
            saveAsImage : {show: true}
        }
    },
      xAxis: {
        type: 'category',
        boundaryGap: false,
        data: this.tableDataAlltypeTime
      },
      yAxis: {
        type: 'value',
        boundaryGap: [0, '30%']
      },
      dataZoom: [
        {
          type: 'slider',
          show: true,
          xAxisIndex: [0],
          start: 0,
          end: 100
        },
        {
          type: 'inside',
          xAxisIndex: [0],
          start: 0,
          end: 100
        }
      ],

      series: [
        {
          name: 'doc',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.tableDataAlltype1
        },
        {
          name: 'video',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.tableDataAlltype2
        },
        {
          name: 'docpic',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.tableDataAlltype3
        },
        {
          name: 'article',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.tableDataAlltype4
        },
        {
          name: 'phvideo',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.tableDataAlltype5
        },
        {
          name: 'slide',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.tableDataAlltype6
        },
        {
          name: 'topic2',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.tableDataAlltype7
        },
        {
          name: 'text_live',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.tableDataAlltype8
        }
      ]
    };
    this.$nextTick(() => {
      myChart2 = echarts.init(document.getElementById('channelArea2'));
      myChart2.setOption(option2);
      myChart2.resize();
    })
    

    //myChart1

    var option3 = {
      legend: {
        left: 'center',
        data: [  'baseline_ctr', 'editorJpPool', 'baseline','baseline_ctr_headline_0718|1', 'baseline_ctr_headline_0601|1', 'baseline_ctr_exp-NoModel|1', 'videoChannel','exp','restruct'],
        selectedMode: 'multiple',
        selected: {  
                    'baseline': false,  
                    'baseline_ctr': true,  
                    'editorJpPool': false,  
                    'baseline_ctr_headline_0718|1': false,  
                    'baseline_ctr_headline_0601|1': false,  
                    'baseline_ctr_exp-NoModel|1': false ,
                    'videoChannel': false,
                    'exp': false ,
                    'restruct': false,  

                }  
      },
      grid: {
        top:'20%',
        left: '2%',
        right: '4%',
        bottom: '3%',
        containLabel: true
    },
      tooltip: {
        trigger: 'axis',
        position: function (pt) {
          return [pt[0]-100, '10%'];
        }
      },
      toolbox: {
        right:'2%',
        top:'8%',
        show: true,
        feature : {
            mark : {show: true},
            dataZoom : {show: true},
            magicType: {type: ['line', 'bar']},
            restore : {show: true},
            saveAsImage : {show: true}
        }
    },
      xAxis: {
        type: 'category',
        boundaryGap: false,
        data: this.tableDataAlltypeTime
      },
      yAxis: {
        type: 'value',
        boundaryGap: [0, '30%']
      },
      dataZoom: [
        {
          type: 'slider',
          show: true,
          xAxisIndex: [0],
          start: 0,
          end: 100
        },
        {
          type: 'inside',
          xAxisIndex: [0],
          start: 0,
          end: 100
        }
      ],

      series: [
        
        {
          name: 'baseline_ctr',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.tableDataAlltype2
        },
        {
          name: 'editorJpPool',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.tableDataAlltype3
        },
        {
          name: 'baseline',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.tableDataAlltype1
        },
        {
          name: 'baseline_ctr_headline_0718|1',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.tableDataAlltype4
        },
        {
          name: 'baseline_ctr_headline_0601|1',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.tableDataAlltype5
        },
        {
          name: 'baseline_ctr_exp-NoModel|1',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.tableDataAlltype6
        },
        {
          name: 'videoChannel',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.tableDataAlltype7
        },
        {
          name: 'exp',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.tableDataAlltype8
        },
        {
          name: 'restruct',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.tableDataAlltype9
        }
      ]
    };
    this.$nextTick(() => {
       myChart3 = echarts.init(document.getElementById('channelArea3'));
        myChart3.setOption(option3);
        myChart3.resize();
    })
   


  },
  mounted () {
        

        window.onresize = function(){
          myChart.resize();
          myChart1.resize();
          myChart2.resize();
          myChart3.resize();
        }
   }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
.getChbg{
    background-color: #20a0ff!important;
    color: #fff!important;
  }
</style>
