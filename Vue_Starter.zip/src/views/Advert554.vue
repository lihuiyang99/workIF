<template>
  <!-- 频道（540）页面 -->
   <div class="animated fadeIn">
    <div class="card">
      <div class="card-block">
        <div class="row">
          <div class="col-sm-5">
            <h4 class="card-title">广告总数据曲线图(554以上)</h4>
            <div class="small text-muted"></div>
          </div><!--/.col-->
        </div><!--/.row-->
         <div id="channelArea" style="width: 100%; height: 400px; margin: 0 auto;text-align: -webkit-center;"></div>
      </div>
    </div><!--/.card-->
    <div class="row" style="margin-bottom:20px">
      <div id="wholeTable" style="width: 98%; margin: 0 auto">
      <el-row style="margin-bottom: -10px ">
        <el-col :span="19">
          <el-pagination :total="tableDataAll.length" :page-size="pageSize" :page-sizes="[5, 10, 15, 20]" :current-page="pageCurr"
          layout="total, sizes, prev, pager, next, jumper" @size-change="handleSizeChange" @current-change="handleCurrentChange"></el-pagination>
        </el-col>
        <!-- <el-col :span="2" :offset="1" style="margin-top: -4px">
          <el-button type="text" icon="upload2" @click="handleClick">导出</el-button>
        </el-col> -->
        <!-- <el-col :span="3" style="margin-top: -4px">
          <el-select placeholder="频道" filterable v-model="option" @change="handleSelectChange">
            <el-option v-for="item in options" :label="item.label" :value="item.value"></el-option>
          </el-select>
        </el-col> -->
        <el-col :span="3" style="margin-top: -4px">
          <el-date-picker type="daterange" placeholder="选择日期范围" :clearable="false" v-model="input" @change="handleChange"></el-date-picker>
        </el-col>
      </el-row>
      <el-tooltip  effect="dark" placement="bottom" >
        <div slot="content">广告库存：广告的最大可曝光次数<br/>广告曝光：广告的曝光次数<br/>广告点击：广告的点击次数<br/>填充率：广告曝光/广告库存<br/>点击率：广告点击/广告曝光<br/>单用户贡献值：广告曝光/DAU<br/>
        </div>
      <i class="el-icon-warning" style="float: right;margin:7px 15px"></i>
      </el-tooltip>
        <el-table v-loading="isLoading"   element-loading-text="拼命加载中"  stripe :data="tableData" :row-class-name="tableRowClassName">
          <el-table-column align="center" v-for="item in columns" :prop="item.prop" :label="item.label" :min-width="item.width" sortable>
          </el-table-column>
        </el-table>
    </div>
    </div>
  </div><!--/.row-->

</template>

<script>
import echarts from 'echarts'
var save = [],
  option = '',
  options = [],
  input = '',
  startDate = '',
  endDate = '',
  pageSize = 10,
  pageCurr = 1,
  myChart,
  columns = [
    {
      prop: 'date',
      label: '日期',
      width: '120px'
    },
    {
      prop: 'store',
      label: '广告库存',
      width: '120px'
    },
    {
      prop: 'ev',
      label: '广告曝光',
      width: '120px'
    },
    {
      prop: 'pv',
      label: '广告点击',
      width: '120px'
    },
    {
      prop: 'dau',
      label: '用户数',
      width: '100px'
    },
    {
      prop: 'ev_rate',
      label: '填充率',
      width: '120px'
    },
    {
      prop: 'pv_rate',
      label: '点击率',
      width: '120px'
    },
    {
      prop: 'score',
      label: '单用户贡献值',
      width: '80px'
    }
  ],
  tableData = [],
  tableDataAll = [],
  tableDataAllDate = [],
  tableDataAllStore = [],
  tableDataAllEv = [],
  tableDataAllPv = [],
  tableDataAllDau = [],
  tableDataAllEvRate = [],
  tableDataAllPvRate = [],
  tableDataAllScore = [];
export default {
  data () {
    return {
      isLoading: false,
      save: save,
      option: option,
      options: options,
      input: input,
      startDate: startDate,
      endDate: endDate,
      pageSize: pageSize,
      pageCurr: pageCurr,
      columns: columns,
      tableData: tableData,
      tableDataAll: tableDataAll,
      tableDataAllDate: tableDataAllDate,
      tableDataAllStore: tableDataAllStore,
      tableDataAllEv: tableDataAllEv,   
      tableDataAllPv: tableDataAllPv,
      tableDataAllDau: tableDataAllDau,
      tableDataAllEvRate: tableDataAllEvRate,
      tableDataAllPvRate: tableDataAllPvRate,
      tableDataAllScore: tableDataAllScore
    }
  },
  methods: {
    //download
    // handleClick(ev) {
    //   var url = 'http://10.50.1.130:58080/channel/channel540Data/excel?startDate='+this.startDate+'&endDate='+this.endDate+'&col='+encodeURI(JSON.stringify(columns));
    //   console.log(url);
    //   window.open(url);
    // },
    // 选择
    handleSelectChange() {
      tableDataAllDate.splice(0, tableDataAllDate.length);
      tableDataAllStore.splice(0, tableDataAllStore.length);
      tableDataAllEv.splice(0, tableDataAllEv.length);
      tableDataAllPv.splice(0, tableDataAllPv.length);
      tableDataAllDau.splice(0, tableDataAllDau.length);
      tableDataAllEvRate.splice(0, tableDataAllEvRate.length);
      tableDataAllPvRate.splice(0, tableDataAllPvRate.length);
      tableDataAllScore.splice(0, tableDataAllScore.length);
      tableDataAllEv.length=0
      console.log(tableDataAllEv)
      console.log(tableDataAllDate)
      var count = 0;
      console.log(save)
      for (var i in save) {
        var line = save[i];
        if (line['channel'] == this.option) {
          tableDataAll.push(line);
          count++;
          tableDataAllDate.unshift(line['date']);
          tableDataAllStore.unshift(line['store']);
          tableDataAllEv.unshift(line['ev']);
          tableDataAllPv.unshift(line['pv']);
          tableDataAllDau.unshift(parseFloat(line['dau']));
          tableDataAllEvRate.unshift(line['ev_rate']);
          tableDataAllPvRate.unshift(line['pv_rate']);
          tableDataAllScore.unshift(line['score']);
        }
      }
      this.pageCurr = 1;
      tableDataAll.splice(0, tableDataAll.length-count);
      tableData.splice(0, tableData.length);
      if (tableDataAll.length < 5) {
        this.pageSize = tableDataAll.length;
      } else {
        this.pageSize = 10;
      }
      for (var i = 0; i < this.pageSize; i++) {
        var line = tableDataAll[i];
        line['store'] = line['store'];
        line['ev'] = line['ev'];
        line['pv'] = line['pv'];
        line['dau'] = line['dau'];
        line['ev_rate'] = line['ev_rate'];
        line['pv_rate'] = line['pv_rate'];
        line['score'] = line['score'];
        tableData.push(tableDataAll[i]);
      }
    },
    // 选择
    handleChange(val) {
      this.startDate = val.slice(0, 10);
      this.endDate = val.slice(13, 23);
      this.getJSON();
    },
    // 分页
    handleSizeChange(val) {
      this.pageSize = val;
      this.pageCurr = 1;
      tableData.splice(0, tableData.length);
      console.log(tableDataAll.length)
      console.log(val)
      val=val>=tableDataAll.length?tableDataAll.length:val
      console.log(val)
      for (var i = 0; i < val; i++) {
        var line = tableDataAll[i];
        line['store'] = line['store'];
        line['ev'] = line['ev'];
        line['pv'] = line['pv'];
        line['dau'] = line['dau'];
        line['ev_rate'] = line['ev_rate'];
        line['pv_rate'] = line['pv_rate'];
        line['score'] = line['score'];
        tableData.push(tableDataAll[i]);
      }
    },
    // 换页
    handleCurrentChange(val) {
      this.pageCurr = val;
      tableData.splice(0, tableData.length);
      var end = (tableDataAll.length > (this.pageCurr)*(this.pageSize)) ? (this.pageCurr)*(this.pageSize) : tableDataAll.length;
      for (var i = (this.pageCurr-1)*(this.pageSize); i < end; i++) {
        var line = tableDataAll[i];
        line['store'] = line['store'];
        line['ev'] = line['ev'];
        line['pv'] = line['pv'];
        line['dau'] = line['dau'];
        line['ev_rate'] = line['ev_rate'];
        line['pv_rate'] = line['pv_rate'];
        line['score'] = line['score'];
        tableData.push(tableDataAll[i]);
      }
    },
    tableRowClassName(row, index) {
      if (index%2 != 0) {
        return 'odd-row';
      } else if (index%2 == 0) {
        return 'even-row';
      }
      return '';
    },
    getDay: function (day) {
      var today = new Date();
      var target = today.getTime()+1000*60*60*24*day;
      today.setTime(target);
      var year = today.getFullYear();
      var month = today.getMonth();
      var date = today.getDate();
      month = this.addZero(month+1);
      date = this.addZero(date);
      return year.toString()+'-'+month.toString()+'-'+date.toString();
    },
    addZero: function (time) {
      if (time.toString().length == 1) {
        time = '0'+time;
      }
      return time;
    },
    getJSON: function () {
      this.isLoading = true;
      if ((this.startDate) && (this.endDate)) {
      } else {
        this.startDate = this.getDay(-31);
        this.endDate = this.getDay(0);
      }
      var map = new Map();
      var url = 'http://10.80.128.150:58080/advert/advert554?startDate='+this.startDate+'&endDate='+this.endDate;
      this.$http.get(url).then((response) => {
        this.isLoading = false;
        tableDataAll.splice(0, tableDataAll.length);
        var temps = response.data;
        console.log(temps)
        for (var i in temps) {
          var temp = temps[i];
          var line = {};
          line['date'] = temp['date'];
          line['store'] = temp['store'];
          line['ev'] = temp['ev'];
          line['pv'] = temp['pv'];
          line['dau'] = temp['dau'];
          line['ev_rate'] = (temp['ev_rate']*100).toFixed(3)+'%';
          line['pv_rate'] = (temp['pv_rate']*100).toFixed(3)+'%';
          line['score'] = temp['score'].toFixed(3);
          tableDataAll.push(line);
          // if (map.has(temp['channel'])) {
          // } else {
          //   map.set(temp['channel'], 1);
          // }
        }
        save = [].concat(tableDataAll);
        // map.delete('头条');
        // this.options.splice(0, this.options.length);
        // for (var key of map.keys()) {
        //   var option = {
        //     value: key,
        //     label: key
        //   };
        //   this.options.push(option);
        // }
        tableDataAllDate.splice(0, tableDataAllDate.length);
        tableDataAllStore.splice(0, tableDataAllStore.length);
        tableDataAllEv.splice(0, tableDataAllEv.length);
        tableDataAllPv.splice(0, tableDataAllPv.length);
        tableDataAllDau.splice(0, tableDataAllDau.length);
        tableDataAllEvRate.splice(0, tableDataAllEvRate.length);
        tableDataAllPvRate.splice(0, tableDataAllPvRate.length);
        tableDataAllScore.splice(0, tableDataAllScore.length);
        var count = 0;
        for (var i in save) {
          var line = save[i];
          // if (line['channel'] == (this.option || '娱乐')) {
            tableDataAll.push(line);
            count++;
            tableDataAllDate.unshift(line['date']);
            tableDataAllStore.unshift(line['store']);
            tableDataAllEv.unshift(line['ev']);
            tableDataAllPv.unshift(line['pv']);
            tableDataAllDau.unshift(parseFloat(line['dau']));
            tableDataAllEvRate.unshift(line['ev_rate']);
            tableDataAllPvRate.unshift(line['pv_rate']);
            tableDataAllScore.unshift(line['score']);
          // }
        }
        tableDataAll.splice(0, tableDataAll.length-count);
        tableData.splice(0, tableData.length);
        if (tableDataAll.length < 5) {
          this.pageSize = tableDataAll.length;
        } else {
          this.pageSize = 10;
        }
        for (var i = 0; i < this.pageSize; i++) {
          var line = tableDataAll[i];
          line['store'] = line['store'];
          line['ev'] = line['ev'];
          line['pv'] = line['pv'];
          line['dau'] = line['dau'];
          line['ev_rate'] = line['ev_rate'];
          line['pv_rate'] = line['pv_rate'];
          line['score'] = line['score'];
          tableData.push(tableDataAll[i]);
        }
      })
    }
  },
  created: function () {
    this.getJSON();
  },
  beforeUpdate: function () {
    var option = {
      legend: {
        left: 'center',
        data: ['广告库存', '广告曝光', '广告点击', '用户数', '填充率', '点击率', '单用户贡献值'],
        selectedMode: 'multiple',
        selected: {  
                    '广告库存': false,  
                    '广告曝光': true,  
                    '广告点击': true,  
                    '人均曝光次数': false,  
                    '用户数': false,  
                    '填充率': false,  
                    '点击率': false ,
                    '单用户贡献值': false
                }  
      },
      grid: {
        top:'20%',
        left: '2%',
        right: '4%',
        bottom: '3%',
        containLabel: true
    },
      tooltip: {
        trigger: 'axis',
        position: function (pt) {
          return [pt[0]-100, '10%'];
        }
      },
      toolbox: {
        right:'2%',
        top:'8%',
        show: true,
        feature : {
            mark : {show: true},
            dataZoom : {show: true},
            magicType: {type: ['line', 'bar']},
            restore : {show: true},
            saveAsImage : {show: true}
        }
    },
      xAxis: {
        type: 'category',
        boundaryGap: false,
        data: this.tableDataAllDate
      },
      yAxis: {
        type: 'value',
        boundaryGap: [0, '30%']
      },
      dataZoom: [
        {
          type: 'slider',
          show: true,
          xAxisIndex: [0],
          start: 0,
          end: 100
        },
        {
          type: 'inside',
          xAxisIndex: [0],
          start: 0,
          end: 100
        }
      ],
      series: [
        {
          name: '广告库存',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.tableDataAllStore
        },
        {
          name: '广告曝光',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.tableDataAllEv
        },
        {
          name: '广告点击',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.tableDataAllPv
        },
        {
          name: '用户数',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.tableDataAllDau
        },
        {
          name: '填充率',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.tableDataAllEvRate
        },
        {
          name: '点击率',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.tableDataAllPvRate
        },
        {
          name: '单用户贡献值',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.tableDataAllScore
        }
      ]
    };
    myChart = echarts.init(document.getElementById('channelArea'));
    myChart.setOption(option);
  },
  mounted () {
        window.onresize = function(){
          myChart.resize();
        }
   }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
/*h1, h2 {
  font-weight: normal;
}

ul {
  list-style-type: none;
  padding: 0;
}

li {
  display: inline-block;
  margin: 0 10px;
}

a {
  color: #42b983;
}*/
</style>
