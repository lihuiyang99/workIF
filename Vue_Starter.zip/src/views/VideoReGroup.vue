<template>
  <!-- 推荐流页面 -->
  <div class="animated fadeIn">
    <div class="card">
      <div class="card-block">
        <div class="row">
          <div class="col-sm-5">
            <h4 class="card-title">推荐流曲线图</h4>
            <div class="small text-muted"></div>
          </div><!--/.col-->
        </div><!--/.row-->
         <div id="headlineArea" style="width: 100%; height: 400px; margin: 0 auto;text-align: -webkit-center;"></div>
      </div>
    </div><!--/.card-->
    <div class="row" style="margin-bottom:20px">
      <div id="wholeTable" style="width: 98%; margin: 0 auto">
      <el-row style="margin-bottom: -10px ">
       <el-col :span="19">
          <el-pagination :total="tableDataAll.length" :page-size="pageSize" :page-sizes="[5, 10, 15, 20]" :current-page="pageCurr"
          layout="total, sizes, prev, pager, next, jumper" @size-change="handleSizeChange" @current-change="handleCurrentChange"></el-pagination>
        </el-col>
        <el-col :span="3" style="margin-top: -4px">
          <el-date-picker type="daterange" placeholder="选择日期范围" :clearable="false" v-model="input" @change="handleChange"></el-date-picker>
        </el-col>
      </el-row>
      <el-tooltip  effect="dark" placement="bottom" >
        <div slot="content">推荐文章1日曝光留存率：前1日在头条推荐流曝光2屏幕以上的用户，本日仍然曝光2屏幕以上的用户所占的比例<br/></div>
      <i class="el-icon-warning" style="float: right;margin:7px 15px"></i>
      </el-tooltip>
       <el-table   v-loading="isLoading"   element-loading-text="拼命加载中"  :data="tableData" :row-class-name="tableRowClassName">
          <el-table-column align="center" v-for="item in columns" :prop="item.prop" :label="item.label" :width="item.width" sortable>
          </el-table-column>
        </el-table>
    </div>
  </div>
  </div><!--/.row-->

</template>

<script>
import echarts from 'echarts'
var input = '',
  myChart,
  startDate = '',
  endDate = '',
  pageSize = 10,
  pageCurr = 1,
  columns = [
    {
      prop: 'date',
      label: '日期',
      width: '115px'
    },
    {
      prop: 'groupName',
      label: '分组',
      width: '120px'
    },
    {
      prop: 'articleCount',
      label: '文章量',
      width: '100px'
    },
    {
      prop: 'expoEv',
      label: '曝光EV',
      width: '105px'
    },
    {
      prop: 'expoEuv',
      label: '曝光EUV',
      width: '105px'
    },
    {
      prop: 'expoAvg',
      label: '人均曝光量',
      width: '105px'
    },
    {
      prop: 'playVv',
      label: '观看VV',
      width: '105px'
    },
    {
      prop: 'playVuv',
      label: '观看VUV',
      width: '106px'
    },
    {
      prop: 'playAvg',
      label: '人均观看数',
      width: '90px'
    },
    {
      prop: 'rate',
      label: '转换率',
      width: '90px'
    },
    {
      prop: 'durationUv',
      label: '视频观看时长人数',
      width: '120px'
    },
    {
      prop: 'durationAvg',
      label: '人均视频观看时长（分钟）',
      width: '150px'
    },
    {
      prop: 'shareCount',
      label: '分享数',
      width: '110px'
    },
    {
      prop: 'shareRate',
      label: '分享率',
      width: '100px'
    },
    {
      prop: 'expoRate',
      label: '曝光占比',
      width: '100px'
    }
    
  ],
  tableData = [],
  tableDataAll = [],
  tableDataAllDate = [],
  tableDataAllGroupName = [],
  tableDataAllArticleCount= [],
  tableDataAllExpoEv = [],
  tableDataAllExpoEuv= [],
  tableDataAllExpoAvg= [],
  tableDataAllPlayVv= [],
  tableDataAllPlayVuv = [],
  tableDataAllPlayAvg = [],
  tableDataAllRate = [],
  tableDataAllDurationUv = [],
  tableDataAllDurationAvg = [],
  tableDataAllShareCount = [],
  tableDataAllShareRate = [],
  tableDataAllExpoRate = []
export default {
  data () {
    return {
      isLoading: false,
      input: input,
      startDate: startDate,
      endDate: endDate,
      pageSize: pageSize,
      pageCurr: pageCurr,
      columns: columns,
      tableData: tableData,
      tableDataAll: tableDataAll,
      tableDataAllDate: tableDataAllDate,
     tableDataAllGroupName:tableDataAllGroupName,
     tableDataAllArticleCount:tableDataAllArticleCount,
     tableDataAllExpoEv:tableDataAllExpoEv,
     tableDataAllExpoEuv:tableDataAllExpoEuv,
     tableDataAllExpoAvg:tableDataAllExpoAvg,
     tableDataAllPlayVv:tableDataAllPlayVv,
     tableDataAllPlayVuv:tableDataAllPlayVuv,
     tableDataAllPlayAvg:tableDataAllPlayAvg,
     tableDataAllRate:tableDataAllRate,
     tableDataAllDurationUv:tableDataAllDurationUv,
     tableDataAllDurationAvg:tableDataAllDurationAvg,
     tableDataAllShareCount:tableDataAllShareCount,
     tableDataAllShareRate:tableDataAllShareRate,
     tableDataAllExpoRate:tableDataAllExpoRate
    }
  },
  methods: {
    // 选择
    handleChange(val) {
      this.startDate = val.slice(0, 4)+'-'+val.slice(5, 7)+'-'+val.slice(8, 10);
      this.endDate = val.slice(13, 17)+'-'+val.slice(18, 20)+'-'+val.slice(21, 23);
      this.getJSON();
    },
    // 分页
    handleSizeChange(val) {
      this.pageSize = val;
      this.pageCurr = 1;
      tableData.splice(0, tableData.length);
      val=val>=tableDataAll.length?tableDataAll.length:val
      for (var i = 0; i < val; i++) {
        var line = tableDataAll[i];
        line['date'] = line['date']
          line['groupName'] = line['groupName'];
          line['articleCount'] = line['articleCount'];
          line['expoEv'] = line['expoEv'];
          line['expoEuv'] = line['expoEuv'];
          line['expoAvg'] = line['expoAvg'];
          line['playAvg'] = line['playAvg'];
          line['playVv'] = line['playVv'];
          line['playVuv'] = line['playVuv'];
          line['playAvg'] = line['playAvg'];
          line['rate'] = line['rate'];
          line['durationUv'] = line['durationUv'];
          line['durationAvg'] = line['durationAvg'];
          line['shareCount'] = line['shareCount'];
           line['shareRate'] = line['shareRate'];
          line['expoRate'] = line['expoRate'];
        tableData.push(tableDataAll[i]);
      }
    },
    // 换页
    handleCurrentChange(val) {
      this.pageCurr = val;
      tableData.splice(0, tableData.length);
      var end = (tableDataAll.length > (this.pageCurr)*(this.pageSize)) ? (this.pageCurr)*(this.pageSize) : tableDataAll.length;
      for (var i = (this.pageCurr-1)*(this.pageSize); i < end; i++) {
        var line = tableDataAll[i];
        line['date'] = line['date']
          line['groupName'] = line['groupName'];
          line['articleCount'] = line['articleCount'];
          line['expoEv'] = line['expoEv'];
          line['expoEuv'] = line['expoEuv'];
          line['expoAvg'] = line['expoAvg'];
          line['playAvg'] = line['playAvg'];
          line['playVv'] = line['playVv'];
          line['playVuv'] = line['playVuv'];
          line['playAvg'] = line['playAvg'];
          line['rate'] = line['rate'];
          line['durationUv'] = line['durationUv'];
          line['durationAvg'] = line['durationAvg'];
          line['shareCount'] = line['shareCount'];
           line['shareRate'] = line['shareRate'];
          line['expoRate'] = line['expoRate'];
        tableData.push(tableDataAll[i]);
      }
    },
    tableRowClassName(row, index) {
      if (index%2 != 0) {
        return 'odd-row';
      } else if (index%2 == 0) {
        return 'even-row';
      }
      return '';
    },
    gettodayDay: function (target) {
      var today = new Date();
      today.setTime(target);
      var year = today.getFullYear();
      var month = today.getMonth();
      var date = today.getDate();
      month = this.addZero(month+1);
      date = this.addZero(date);
      return year.toString()+'-'+month.toString()+'-'+date.toString();
    },
    getDaytime: function (target) {
      var today = new Date();
      today.setTime(target);
      var hour = today.getHours();
      var minute = today.getMinutes();
      var second = today.getSeconds();
      hour = this.addZero(hour);
      minute = this.addZero(minute);
      second = this.addZero(second);
      return hour.toString()+':'+minute.toString()+':'+second.toString();
    },
    getDay: function (day) {
      var today = new Date();
      var target = today.getTime()+1000*60*60*24*day;
      today.setTime(target);
      var year = today.getFullYear();
      var month = today.getMonth();
      var date = today.getDate();
      month = this.addZero(month+1);
      date = this.addZero(date);
      return year.toString()+'-'+month.toString()+'-'+date.toString();
    },
    addZero: function (time) {
      if (time.toString().length == 1) {
        time = '0'+time;
      }
      return time;
    },
    getJSON: function () {
      this.isLoading = true;
      if ((this.startDate) && (this.endDate)) {
      } else {
        this.startDate = this.getDay(-31);
        this.endDate = this.getDay(0);
      }
      var url='http://10.80.128.150:58080/video/recommend/group?startDate='+this.startDate+'&endDate='+this.endDate
      this.$http.get(url).then((response) => {
        console.log(response)
        this.isLoading = false;
        tableDataAll.splice(0, tableDataAll.length);
        tableDataAllDate.splice(0, tableDataAllDate.length);
        tableDataAllGroupName.splice(0, tableDataAllGroupName.length);
        tableDataAllArticleCount.splice(0, tableDataAllArticleCount.length);
        tableDataAllExpoEv.splice(0, tableDataAllExpoEv.length);
        tableDataAllExpoEuv.splice(0, tableDataAllExpoEuv.length);
        tableDataAllExpoAvg.splice(0, tableDataAllExpoAvg.length);
        tableDataAllPlayVv.splice(0, tableDataAllPlayVv.length);
        tableDataAllPlayVuv.splice(0, tableDataAllPlayVuv.length);
        tableDataAllPlayAvg.splice(0, tableDataAllPlayAvg.length);
        tableDataAllRate.splice(0, tableDataAllRate.length);
        tableDataAllDurationUv.splice(0, tableDataAllDurationUv.length);
        tableDataAllDurationAvg.splice(0, tableDataAllDurationAvg.length);
        tableDataAllShareCount.splice(0, tableDataAllShareCount.length);
        tableDataAllShareRate.splice(0, tableDataAllShareRate.length);
        tableDataAllExpoRate.splice(0, tableDataAllExpoRate.length);
        var temps = response.data;
        for (var i in temps) {
          var temp = temps[i];
          var line = {};
         
          line['date'] = this.gettodayDay(temp['date']);
          line['groupName'] = temp['groupName'];
          line['articleCount'] = temp['articleCount'];
          line['expoEv'] = temp['expoEv'];
          line['expoEuv'] = temp['expoEuv'];
          line['expoAvg'] = temp['expoAvg'];
          line['playAvg'] = temp['playAvg'];
          line['playVv'] = temp['playVv'];
          line['playVuv'] = temp['playVuv'];
          line['playAvg'] = temp['playAvg'];
          line['rate'] = temp['rate'];
          line['durationUv'] = temp['durationUv'];
          line['durationAvg'] = temp['durationAvg'];
          line['shareCount'] = temp['shareCount'];
           line['shareRate'] = temp['shareRate'];
          line['expoRate'] = temp['expoRate'];
          tableDataAll.unshift(line);
          tableDataAllDate.push(line['date']);
          tableDataAllGroupName.push(line['groupName']);
          tableDataAllArticleCount.push(line['expoEv']);
          tableDataAllExpoEv.push(line['expoEv']);
          tableDataAllExpoEuv.push(line['expoEuv']);
          tableDataAllExpoAvg.push(line['expoAvg']);
          tableDataAllPlayVv.push(line['playVv']);
          tableDataAllPlayVuv.push(line['playVuv']);
          tableDataAllPlayAvg.push(line['playAvg']);
          tableDataAllRate.push(line['rate']);
          tableDataAllDurationUv.push(line['durationUv']);
          tableDataAllDurationAvg.push(line['durationAvg']);
          tableDataAllShareCount.push(line['shareCount']);
          tableDataAllShareRate.push(line['shareRate']);
          tableDataAllExpoRate.push(line['expoRate']);
         
        }
        tableData.splice(0, tableData.length);
        if (tableDataAll.length < 5) {
          this.pageSize = tableDataAll.length;
        } else {
          this.pageSize = 10;
        }
        for (var i = 0; i < this.pageSize; i++) {
          var line = tableDataAll[i];
          line['date'] = line['date']
          line['groupName'] = line['groupName'];
          line['articleCount'] = line['articleCount'];
          line['expoEv'] = line['expoEv'];
          line['expoEuv'] = line['expoEuv'];
          line['expoAvg'] = line['expoAvg'];
          line['playAvg'] = line['playAvg'];
          line['playVv'] = line['playVv'];
          line['playVuv'] = line['playVuv'];
          line['playAvg'] = line['playAvg'];
          line['rate'] = line['rate'];
          line['durationUv'] = line['durationUv'];
          line['durationAvg'] = line['durationAvg'];
          line['shareCount'] = line['shareCount'];
           line['shareRate'] = line['shareRate'];
          line['expoRate'] = line['expoRate'];
          tableData.push(tableDataAll[i]);
        }
      })
    }
  },
  created: function () {
    this.getJSON();
  },
  beforeUpdate: function () {
    var option = {
      legend: {
        left: 'center',
        data: [ '文章量', '曝光EV', '曝光EUV', '人均曝光量', '观看VV', '观看VUV', '人均观看数', '转换率', '视频观看时长人数', '人均视频观看时长（分钟）', '分享数', '曝光占比'],
        selectedMode: 'multiple',
        selected: {  
                    '文章量': true,  
                    '曝光EV': false,  
                    '曝光EUV': false,  
                    '人均曝光量': false,  
                    '观看VV': false,  
                    '观看VUV': false, 
                    '人均观看数': false,  
                    '转化率': false,
                    '视频观看时长人数': false,  
                    '人均视频观看时长（分钟）': false,  
                    '分享数': false,  
                    '曝光占比': false
                }  
      },
      tooltip: {
        trigger: 'axis',
        position: function (pt) {
          return [pt[0]-100, '10%'];
        }
      },
        toolbox: {
        right:'2%',
        top:'10%',
        show: true,
        feature : {
            mark : {show: true},
            dataZoom : {show: true},
            magicType: {type: ['line', 'bar']},
            restore : {show: true},
            saveAsImage : {show: true}
        }
    },
      xAxis: {
        type: 'category',
        boundaryGap: false,
        data: this.tableDataAllDate
      },
      yAxis: {
        type: 'value',
        boundaryGap: [0, '30%']
      },
      dataZoom: [
        {
          type: 'slider',
          show: true,
          xAxisIndex: [0],
          start: 0,
          end: 100
        },
        {
          type: 'inside',
          xAxisIndex: [0],
          start: 0,
          end: 100
        }
      ],
      series: [
        {
          name: '文章量',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.tableDataAllExpoPv
        },
        {
          name: '曝光EV',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.tableDataAllExpoUv
        },
        {
          name: '人均曝光量',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.tableDataAllExpoAvg
        },
        {
          name: '观看VV',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.tableDataAllPlayPv
        },
        {
          name: '观看VUV',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.tableDataAllPlayUv
        },
        {
          name: '人均观看数',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.tableDataAllPlayAvg
        },
        {
          name: '视频观看时长人数',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.tableDataAllPlayTimeAvg
        },
        {
          name: '人均视频观看时长（分钟）',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.tableDataAllRate
        },
        {
          name: '分享数',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.tableDataAllDownPullPv
        },
        {
          name: '曝光占比',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.tableDataAllDownPullUv
        }
      ],
      grid: {
        top: '20%',
        left: '2%',
        right: '2%',
        bottom: '3%',
        containLabel: true
      }
    };
    myChart = echarts.init(document.getElementById('headlineArea'));
    myChart.setOption(option);
  },
  mounted () {
        window.onresize = function(){
          myChart.resize();
        }
   }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
/*h1, h2 {
  font-weight: normal;
}

ul {
  list-style-type: none;
  padding: 0;
}

li {
  display: inline-block;
  margin: 0 10px;
}

a {
  color: #42b983;
}*/
</style>
