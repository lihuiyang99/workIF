<template>
  <div class="animated fadeIn">
      <div class="contentChart" :class="myModal==true?'chartShow':'chartHide'">
          <div class="contentInner">
            <h2>精品池文章数据5分钟粒度统计    <i class="el-icon-close" style="float: right;margin: 10px;" @click="myModal=false"></i></h2>
            <div class="contentTab">
              <!-- <div class="btn-toolbar float-left" role="toolbar" aria-label="Toolbar with button groups">
                <div class="btn-group mr-3" data-toggle="buttons" aria-label="First group">
                  <label class="btn btn-outline-secondary" :class="checkedCh==0?'getChbg':null">
                    <input type="radio" name="options" id="option3"  @click="getChartYestoday"> 昨天
                  </label>
                  <label class="btn btn-outline-secondary" :class="checkedCh==1?'getChbg':null">
                    <input type="radio" name="options" id="option4"  @click="getChart"> 今天
                  </label>
                </div>
              </div> -->
              <el-button @click="getChartYestoday" :class="checkedCh==0?'getChbg':null">昨天</el-button>
              <el-button @click="getChart" :class="checkedCh==1?'getChbg':null">今天</el-button>
              <el-button @click="getChartDay" v-if="value1!=''" :class="checkedCh==2?'getChbg':null">{{value1}}</el-button>
            </div>
            <div id="articleArea" style="width: 800px; height: 300px; margin: 0 auto;text-align: -webkit-center;"></div>
          </div>
          
          
      </div>
    <div class="card">
      <div class="card-block">
        <div class="row">
          <div class="col-sm-5">
            <h4 class="card-title mb-0">精品池</h4>
          </div><!--/.col-->
          <div class="col-sm-7 hidden-sm-down">
          </div><!--/.col-->
        </div><!--/.row-->
        <!-- <main-chart-example class="chart-wrapper" style="height:300px;margin-top:40px;" height="300"></main-chart-example> -->
      </div>
     <div class="row" style="margin-bottom:20px">
      <div id="wholeTable" style="width: 98%; margin: 0 auto">
        <el-row style="margin-bottom: -10px ">
          <el-col :span="12">
            <el-pagination :total="tableDataAll.length" :page-size="pageSize" :page-sizes="[5, 10, 20, 50,100,500]" :current-page="pageCurr"
            layout="total, sizes, prev, pager, next, jumper" @size-change="handleSizeChange" @current-change="handleCurrentChange"></el-pagination>
          </el-col>
          <el-col :span="2" :offset="1" style="margin-top: -4px">
            <el-button type="text" icon="upload2" @click="handleClick">导出</el-button>
          </el-col>
          <el-col :span="3" style="margin-top: -4px">
             <div class="btn-toolbar float-right" role="toolbar" aria-label="Toolbar with button groups">
              <div class="btn-group mr-3" data-toggle="buttons" aria-label="First group">
                <label class="btn btn-outline-secondary" :class="checked==0?'getJbg':null">
                  <input type="radio" name="options" id="option1"  @click="getJSONYestoday"> 昨天
                </label>
                <label class="btn btn-outline-secondary" :class="checked==1?'getJbg':null">
                  <input type="radio" name="options" id="option2"  @click="getJSON"> 今天
                </label>
              </div>
            </div>
          </el-col>
          <el-col :span="3" style="margin-top: -4px">
               <el-date-picker v-model="value1"  type="date" placeholder="选择日期" :picker-options="pickerOptions0" @change="handleChange"> </el-date-picker>(选择近30天的某一天)
          </el-col>
        </el-row>
        <el-tooltip  effect="dark" placement="bottom" >
          <div  slot="content">
            推荐原因字段解释：<br/>数据来源#推送原因#辅助说明<br/><br/>
            信息流人均点击：信息流点击次数/信息流点击人数<br/>
            点击率：信息流点击人数/信息流曝光次数；<br/>
            退出率：用户未阅读文章便退出客户端的比例<br/>
          </div>
        <i class="el-icon-warning" style="float: right;margin:7px 15px"></i>
        </el-tooltip>
          <el-table  v-loading="isLoading"   element-loading-text="拼命加载中"  stripe :data="tableData" :row-class-name="tableRowClassName"  @sort-change="sortMethod">
          <el-table-column align="center" prop="id" label="文章id" min-width="150px" sortable>
              <template scope="scope">
                <el-button type="text" style="user-select: initial;" icon="document" size="mini" @click="handleButtonClick">{{scope.row.id}}</el-button>
              </template>
            </el-table-column>
            <el-table-column align="center" prop="title" label="标题" min-width="180px" sortable></el-table-column>
            <el-table-column align="center" prop="ev" label="信息流曝光" min-width="120px" sortable></el-table-column>
            <el-table-column align="center" prop="pv" label="信息流点击" min-width="120px" sortable></el-table-column>
            <el-table-column align="center" prop="rate" label="转化率" min-width="90px" sortable></el-table-column>
            <el-table-column align="center" prop="share" label="分享次数" min-width="90px" sortable></el-table-column>
            <el-table-column align="center" prop="shareRate" label="分享率" min-width="90px" sortable></el-table-column>
            <el-table-column align="center" prop="store" label="收藏次数" min-width="90px" sortable></el-table-column>
            <el-table-column align="center" prop="storeRate" label="收藏率" min-width="90px" sortable></el-table-column>
            <el-table-column align="center" prop="comment" label="评论次数" min-width="90px" sortable></el-table-column>
            <el-table-column align="center" prop="commentRate" label="评论率" min-width="90px" sortable></el-table-column>
            <el-table-column
              prop="tag"
              fixed="right"
              label="查看文章信息"
              width="80"  >
              <template scope="scope" >
                <el-button @click="handleClickLook(scope.$index, scope.row)" type="text" size="small"><button type="button" class="btn btn-secondary" @click="myModal = true">查看</button></el-button>
              </template>
            </el-table-column>
          </el-table>
      </div>
    </div>
      </div>
    </div><!--/.card-->
  </div>

</template>

<script>
import echarts from 'echarts'
import modal from 'vue-strap/src/Modal'
var 
  input = '',
  history = [],
  num1,num2,num3,num4,
  startDate = '',
  endDate = '',
  pageSize = 10,
  pageCurr = 1,
  myChart,
  checked=1,
  checkedCh=1,
  columns = [
    {
      prop: 'id',
      label: '文章id',
      'min-width':'120px'
    },
    {
      prop: 'title',
      label: '标题',
      'min-width':'150px'
    },
    {
      prop: 'ev',
      label: '信息流曝光',
      'min-width':'120px'
    },
    {
      prop: 'pv',
      label: '信息流点击',
      'min-width': '110px'
    },
    {
      prop: 'rate',
      label: '转化率',
      'min-width': '110px'
    },
    {
      prop: 'clickRate',
      label: '点击率',
      'min-width': '100px'
    },
    {
      prop: 'share',
      label: '分享次数',
      width: '90px'
    },
    {
      prop: 'shareRate',
      label: '分享率',
      width: '90px'
    },
    {
      prop: 'store',
      label: '收藏次数',
      width: '90px'
    },
    {
      prop: 'storeRate',
      label: '收藏率',
      width: '90px'
    },
    {
      prop: 'comment',
      label: '评论次数',
      width: '90px'
    },
    {
      prop: 'commentRate',
      label: '评论率',
      width: '90px'
    }

  ],
  
  //column for excel
   excelColumns = [
   {
      prop: 'id',
      label: '文章id',
      'min-width':'120px'
    },
    {
      prop: 'ev',
      label: '信息流曝光',
      'min-width':'120px'
    },
    {
      prop: 'pv',
      label: '信息流点击',
      'min-width': '110px'
    },
    {
      prop: 'rate',
      label: '转化率',
      'min-width': '110px'
    },
    {
      prop: 'share',
      label: '分享次数',
      width: '90px'
    },
    {
      prop: 'shareRate',
      label: '分享率',
      width: '90px'
    },
    {
      prop: 'store',
      label: '收藏次数',
      width: '90px'
    },
    {
      prop: 'storeRate',
      label: '收藏率',
      width: '90px'
    },
    {
      prop: 'comment',
      label: '评论次数',
      width: '90px'
    },
    {
      prop: 'commentRate',
      label: '评论率',
      width: '90px'
    }
  ],
  tableDataAllEv = [],
  tableDataAllPv = [],
  tableData1 = [],
  tableDataAll1 = [],
  tableData = [],
  tableDataAll = [],
  tableDataAllDate = [],
  tableDataAllNewUser = [],
  tableDataAllDau = [],
  tableDataAllThirdparty = [],
  
  tableDataAllPvAvg = [],
  tableDataAllUseTime = [],
  tableDataAllNumStart = [],
  tableDataAllClickRate = [],
  tableDataAllExitRate = [],
  tableDataAllShare = [],
  tableDataAllShareUv = [],
  tableDataAllVv = [],
  tableDataAllVvAvg = [],


  tableDataAllTime = [],
  tableDataAllComment=[],
  tableDataAllStore=[],

  tableDataAllClickRate=[],
  tableDataAllRate=[],
  tableDataAllCommentRate=[],
  tableDataAllShareRate=[],
  tableDataAllStoreRate=[],






  articleId='';
export default {
  name: 'dashboard',
  components: {
    modal
  },
  data () {
    return {
      isLoading:false,
      input:input,
      history:history,
      myModal: false,
      num1:num1,
      num2:num2,
      num3:num3,
      num4:num4,
      checked:checked,
      checkedCh:checkedCh,
      input: input,
      startDate: startDate,
      endDate: endDate,
      pageSize: pageSize,
      pageCurr: pageCurr,
      columns: columns,
      articleId:articleId,
      tableDataAllTime:tableDataAllTime,
      tableDataAllComment:tableDataAllComment,
      tableDataAllStore:tableDataAllStore,
      tableDataAllShare:tableDataAllShare,
      tableDataAllClickRate:tableDataAllClickRate,
      tableDataAllCommentRate:tableDataAllCommentRate,
      tableDataAllShareRate:tableDataAllShareRate,
      tableDataAllStoreRate:tableDataAllStoreRate,
      tableData1: tableData1,
      tableDataAll1: tableDataAll1,


      tableData: tableData,
      tableDataAll: tableDataAll,
      tableDataAllEv: tableDataAllEv,
      tableDataAllPv: tableDataAllPv,
      tableDataAllRate:tableDataAllRate,
      
      
      tableDataAllDate: tableDataAllDate,
      tableDataAllNewUser: tableDataAllNewUser,
      tableDataAllDau: tableDataAllDau,
      tableDataAllThirdparty: tableDataAllThirdparty,
      
      tableDataAllPvAvg: tableDataAllPvAvg,
      tableDataAllUseTime: tableDataAllUseTime,
      tableDataAllNumStart: tableDataAllNumStart,
      tableDataAllExitRate: tableDataAllExitRate,
      tableDataAllShareUv: tableDataAllShareUv,
      tableDataAllVv: tableDataAllVv,
      tableDataAllVvAvg: tableDataAllVvAvg,
      pickerOptions0: {
          disabledDate(time) {
            return time.getTime() > Date.now() - 8.64e7;
          }
        },
      value1:''
    }
  },
  methods: {
    sortMethod(value) {
        console.log(value)
        var propName=value.prop;
        var propSort=value.order;
        if(propSort=="descending"){//降序排序
        console.log('jiang')
           this.tableDataAll.sort(function(a,b){
             console.log(parseFloat(b[propName]))
            return parseFloat(b[propName])-parseFloat(a[propName])
            });

        }
        if(propSort=="ascending"){//升序排序
        console.log('sheng')
           this.tableDataAll.sort(function(a,b){
            return parseFloat(a[propName])-(b[propName])
            
            });
        }
        console.log(this.tableData)
        console.log(this.tableDataAll)
      tableData.splice(0, tableData.length);
        if (tableDataAll.length < 5) {
          this.pageSize = tableDataAll.length;
        } else {
          this.pageSize = 10;
        }
        for (var i = 0; i < this.pageSize; i++) {
          var line = tableDataAll[i];
          line['id'] = line['id'];
          line['ev'] = line['ev'];
          line['pv'] = line['pv'];
          line['share'] = line['share'];
          line['clickRate'] = line['clickRate'];
          line['shareRate'] = line['shareRate'];
          line['comment'] = line['comment'];
          line['rate'] = line['rate'];
          line['commentRate'] = line['commentRate'];
          line['store'] = line['store'];
          line['storeRate'] = line['storeRate'];
          line['title']=line['title'];
          tableData.push(tableDataAll[i]);
        }
        
    },
    // 清除
    handleIconClick(ev) {
      this.history.splice(0, this.history.length);
      localStorage.setItem('imageHistory', '');
    },
    // 搜索
    handleClick(ev) {
      var res = localStorage.getItem('imageHistory');
      if (res) {
        if (res.indexOf(this.input) == -1) {
          localStorage.setItem('imageHistory', res+' '+this.input);
        } else {
          var start = res.indexOf(this.input);
          var end = start+this.input.length;
          if (start != 0) {
            start = start-1;
          }
          res = res.slice(0, start)+res.slice(end);
          var arr = res.split(' ');
          this.history.splice(0, this.history.length);
          for (var i in arr) {
            this.history.unshift({"value": arr[i]});
          }
          localStorage.setItem('imageHistory', res+' '+this.input);
        }
      } else {
        localStorage.setItem('imageHistory', this.input);
      }
      this.history.unshift({"value": this.input});
      this.isLoading = true;
      this.getJSON();
      this.isLoading = false;
    },
    // 历史
    querySearch(queryString, cb) {
      if (this.history.length == 0) {
        var res = localStorage.getItem('imageHistory');
        if (res) {
          var arr = res.split(' ');
          for (var i in arr) {
            this.history.unshift({"value": arr[i]});
          }
        }
      }
      cb(this.history);
    },
    handleClickLook(index, row){
      this.articleId=row.id;
      this.getChart();
    },
    handleButtonClick(ev) {
      if(ev.target.innerText.split("-").length>=5){
        var url = 'http://share.iclient.ifeng.com/sharenews.f?guid='+ev.target.innerText;
        window.open(url)
      }else{
        var url = 'http://share.iclient.ifeng.com/sharenews.f?aid='+ev.target.innerText;
        window.open(url)
      }
    },
    // 下载
    handleClick(ev) {
      if(this.checked==0){
        var url = 'http://10.80.128.150:58080/newsPortrait/jpPool/yesterday/excel?col='+encodeURI(JSON.stringify(excelColumns));
      }else if(this.checked==1){
        var url = 'http://10.80.128.150:58080/newsPortrait/jpPool/today/excel?col='+encodeURI(JSON.stringify(excelColumns));
      }else{
         var url = 'http://10.80.128.150:58080/newsPortrait/jpPool/excel?date='+this.value1+'&col='+encodeURI(JSON.stringify(excelColumns));
      }
       window.open(url);
    },
    // 选择
    handleChange(val) {
      console.log(val)
      this.value1=val;
      var url='http://10.80.128.150:58080/newsPortrait/jpPool?date='+val;
      console.log(url)
      this.getJSONday(url);
    },
    getDay: function (day) {
      var today = new Date();
      var target = today.getTime()+1000*60*60*24*day;
      today.setTime(target);
      var year = today.getFullYear();
      var month = today.getMonth();
      var date = today.getDate();
      month = this.addZero(month+1);
      date = this.addZero(date);
      return year.toString()+month.toString()+date.toString();
    },
    getDaytime: function () {
      var today = new Date();
      var hour = today.getHours();
      var minute = today.getMinutes();
      hour = this.addZero(hour);
      minute = this.addZero(minute);
      return hour.toString()+minute.toString();
    },
    addZero: function (time) {
      if (time.toString().length == 1) {
        time = '0'+time;
      }
      return time;
    },
    getvalday:function (val,day) {
       var today = new Date(val);
       var target = today.getTime()+1000*60*60*24*day;
      today.setTime(target);
      var year = today.getFullYear();
      var month = today.getMonth();
      var date = today.getDate();
      month = this.addZero(month+1);
      date = this.addZero(date);
      return year.toString()+month.toString()+date.toString();
    },
    // 分页
    handleSizeChange(val) {
      this.pageSize = val;
      this.pageCurr = 1;
      tableData.splice(0, tableData.length);
      val=val<=tableDataAll.length?val:tableDataAll.length
      for (var i = 0; i < val; i++) {
        var line = tableDataAll[i];
        line['id'] = line['id'];
          line['ev'] = line['ev'];
          line['pv'] = line['pv'];
          line['share'] = line['share'];
          line['clickRate'] = line['clickRate'];
          line['shareRate'] = line['shareRate'];
          line['comment'] = line['comment'];
          line['commentRate'] = line['commentRate'];
          line['store'] = line['store'];
          line['rate'] = line['rate'];
          line['storeRate'] = line['storeRate'];
          line['title'] = line['title'];
          tableData.push(tableDataAll[i]);
      }
    },
    // 换页
    handleCurrentChange(val) {
      this.pageCurr = val;
      tableData.splice(0, tableData.length);
      var end = (tableDataAll.length > (this.pageCurr)*(this.pageSize)) ? (this.pageCurr)*(this.pageSize) : tableDataAll.length;
      for (var i = (this.pageCurr-1)*(this.pageSize); i < end; i++) {
        var line = tableDataAll[i];
        line['id'] = line['id'];
          line['ev'] = line['ev'];
          line['pv'] = line['pv'];
          line['share'] = line['share'];
          line['clickRate'] = line['clickRate'];
           line['rate'] = line['rate'];
          line['shareRate'] = line['shareRate'];
          line['comment'] = line['comment'];
          line['commentRate'] = line['commentRate'];
          line['store'] = line['store'];
          line['storeRate'] = line['storeRate'];
          line['title'] = line['title'];
          tableData.push(tableDataAll[i]);
      }
    },
    tableRowClassName(row, index) {
      if (index%2 != 0) {
        return 'odd-row';
      } else if (index%2 == 0) {
        return 'even-row';
      }
      return '';
    },
    getJSON: function () {
      tableData.length=0
      this.isLoading = true;
      this.checked=1;
      var url = 'http://10.80.128.150:58080/newsPortrait/jpPool/today';
      this.$http.get(url).then((response) => {
          console.log(response)
        tableDataAll.splice(0, tableDataAll.length);
        tableDataAllDate.splice(0, tableDataAllDate.length);
        var temps = response.data;
        /*var temps = obj['data'];*/
        this.isLoading = false;
        for (var i in temps) {
          var temp = temps[i];
          var line = {};
          line['id'] = temp['id'] ? temp['id']: 0;
          line['ev'] = temp['ev'] ? temp['ev']: 0;
          line['pv'] = temp['pv'] ? temp['pv']: 0;
          line['rate'] = temp['rate']? temp['rate']: 0;
          line['share'] = temp['share'] ? temp['share']: 0;
          line['clickRate'] = temp['clickRate'] ? temp['clickRate']: 0;
          line['shareRate'] = temp['shareRate'] ? temp['shareRate']: 0;
          line['comment'] = temp['comment'] ? temp['comment']: 0;
          line['commentRate'] = temp['commentRate'] ? temp['commentRate']: 0;
          line['store'] = temp['store'] ? temp['store']: 0;
          line['storeRate'] = temp['storeRate'] ? temp['storeRate']: 0;
          line['title'] = temp['title'] ? temp['title']: '';
          tableDataAll.push(line);
        }
        tableData.splice(0, tableData.length);
        if (tableDataAll.length < 5) {
          this.pageSize = tableDataAll.length;
        } else {
          this.pageSize = 10;
        }
        for (var i = 0; i < this.pageSize; i++) {
          var line = tableDataAll[i];
          line['id'] = line['id'];
          line['ev'] = line['ev'];
          line['pv'] = line['pv'];
          line['share'] = line['share'];
          line['clickRate'] = line['clickRate'];
          line['shareRate'] = line['shareRate'];
          line['comment'] = line['comment'];
          line['rate'] = line['rate'];
          line['commentRate'] = line['commentRate'];
          line['store'] = line['store'];
          line['storeRate'] = line['storeRate'];
          line['title']=line['title'];
          tableData.push(tableDataAll[i]);
        }
      })
    },
    getJSONYestoday: function () {
      tableData.length=0
      this.isLoading = true;
      this.checked=0;
      var url = 'http://10.80.128.150:58080/newsPortrait/jpPool/yesterday';
      this.$http.get(url).then((response) => {
        this.isLoading = false;
        
        tableDataAll.splice(0, tableDataAll.length);
        tableDataAllDate.splice(0, tableDataAllDate.length);
        var temps = response.data;
        /*var temps = obj['data'];*/
        
        for (var i in temps) {
          var temp = temps[i];
          var line = {};
          line['id'] = temp['id'] ? temp['id']: 0;
          line['ev'] = temp['ev'] ? temp['ev']: 0;
          line['pv'] = temp['pv'] ? temp['pv']: 0;
          line['share'] = temp['share'] ? temp['share']: 0;
          line['rate'] = temp['rate']? temp['rate']: 0;
          line['clickRate'] = temp['clickRate'] ? temp['clickRate']: 0;
          line['shareRate'] = temp['shareRate'] ? temp['shareRate']: 0;
          line['comment'] = temp['comment'] ? temp['comment']: 0;
          line['commentRate'] = temp['commentRate'] ? temp['commentRate']: 0;
          line['store'] = temp['store'] ? temp['store']: 0;
          line['storeRate'] = temp['storeRate'] ? temp['storeRate']: 0;
          line['title'] = temp['title'] ? temp['title']: '';
          tableDataAll.push(line);
        }
        tableData.splice(0, tableData.length);
        if (tableDataAll.length < 5) {
          this.pageSize = tableDataAll.length;
        } else {
          this.pageSize = 10;
        }
        for (var i = 0; i < this.pageSize; i++) {
          var line = tableDataAll[i];
          line['id'] = line['id'];
          line['ev'] = line['ev'];
          line['pv'] = line['pv'];
          line['rate'] = line['rate'];
          line['share'] = line['share'];
          line['clickRate'] = line['clickRate'];
          line['shareRate'] = line['shareRate'];
          line['comment'] = line['comment'];
          line['commentRate'] = line['commentRate'];
          line['store'] = line['store'];
          line['storeRate'] = line['storeRate'];
          
          tableData.push(tableDataAll[i]);
        }
      })
    },
    getJSONday: function (url) {
      tableData.length=0
      this.isLoading = true;
      this.checked=2;
      // var url = 'http://10.50.1.130:58080/newsPortrait/jpPool/yesterday';
      this.$http.get(url).then((response) => {
        this.isLoading = false;
        
        tableDataAll.splice(0, tableDataAll.length);
        tableDataAllDate.splice(0, tableDataAllDate.length);
        var temps = response.data;
        /*var temps = obj['data'];*/
        
        for (var i in temps) {
          var temp = temps[i];
          var line = {};
          line['id'] = temp['id'] ? temp['id']: 0;
          line['ev'] = temp['ev'] ? temp['ev']: 0;
          line['pv'] = temp['pv'] ? temp['pv']: 0;
          line['share'] = temp['share'] ? temp['share']: 0;
          line['rate'] = temp['rate']? temp['rate']: 0;
          line['clickRate'] = temp['clickRate'] ? temp['clickRate']: 0;
          line['shareRate'] = temp['shareRate'] ? temp['shareRate']: 0;
          line['comment'] = temp['comment'] ? temp['comment']: 0;
          line['commentRate'] = temp['commentRate'] ? temp['commentRate']: 0;
          line['store'] = temp['store'] ? temp['store']: 0;
          line['storeRate'] = temp['storeRate'] ? temp['storeRate']: 0;
          line['title'] = temp['title'] ? temp['title']: '';
          tableDataAll.push(line);
        }
        tableData.splice(0, tableData.length);
        if (tableDataAll.length < 5) {
          this.pageSize = tableDataAll.length;
        } else {
          this.pageSize = 10;
        }
        for (var i = 0; i < this.pageSize; i++) {
          var line = tableDataAll[i];
          line['id'] = line['id'];
          line['ev'] = line['ev'];
          line['pv'] = line['pv'];
          line['rate'] = line['rate'];
          line['share'] = line['share'];
          line['clickRate'] = line['clickRate'];
          line['shareRate'] = line['shareRate'];
          line['comment'] = line['comment'];
          line['commentRate'] = line['commentRate'];
          line['store'] = line['store'];
          line['storeRate'] = line['storeRate'];
          
          tableData.push(tableDataAll[i]);
        }
      })
    },
    getChart: function () {
      this.checkedCh=1;
      var url;
      if(this.articleId.split("-").length>=5){
        url = 'http://10.80.128.150:58080/newsPortrait/agg/5min?start='+this.getDay(0)+'0000'+'&stop='+this.getDay(0)+this.getDaytime()+'&id=video_'+this.articleId;
      }else{
        url = 'http://10.80.128.150:58080/newsPortrait/agg/5min?start='+this.getDay(0)+'0000'+'&stop='+this.getDay(0)+this.getDaytime()+'&id='+this.articleId;
      }
      this.$http.get(url).then((response) => {
        tableDataAll1.splice(0, tableDataAll1.length);
        tableDataAllTime.splice(0, tableDataAllTime.length);
        tableDataAllEv.splice(0, tableDataAllEv.length);
        tableDataAllPv.splice(0, tableDataAllPv.length);
        tableDataAllShare.splice(0, tableDataAllShare.length);
        tableDataAllStore.splice(0, tableDataAllStore.length);
        tableDataAllComment.splice(0, tableDataAllComment.length);

        tableDataAllClickRate.splice(0, tableDataAllClickRate.length);
        tableDataAllCommentRate.splice(0, tableDataAllCommentRate.length);
        tableDataAllShareRate.splice(0, tableDataAllShareRate.length);
        tableDataAllStoreRate.splice(0, tableDataAllStoreRate.length);

        var temps = response.data;
        for (var i in temps) {
          var temp = temps[i];
          var line = {};
          line['time'] = temp['time'] ? temp['time']: 0;
          line['id'] = temp['id'] ? temp['id']: 0;
          line['ev'] = temp['ev'] ? temp['ev']: 0;
          line['pv'] = temp['pv'] ? temp['pv']: 0;
          line['share'] = temp['share'] ? temp['share']: 0;
          line['store'] = temp['store'] ? temp['store']: 0;
          line['comment'] = temp['comment'] ? temp['comment']: 0;
          line['clickRate'] = temp['clickRate'] ? temp['clickRate']: 0;
          line['shareRate'] = temp['shareRate'] ? temp['shareRate']: 0;
          line['rate'] = temp['rate']?temp['rate']: 0;
          line['commentRate'] = temp['commentRate'] ? temp['commentRate']: 0;
          line['storeRate'] = temp['storeRate'] ? temp['storeRate']: 0;
          tableDataAll1.unshift(line);
          tableDataAllTime.push(line['time'].slice(8, 10)+':'+line['time'].slice(10));
          tableDataAllEv.push(line['ev']);
          tableDataAllPv.push(line['pv']);
          tableDataAllShare.push(line['share']);
          tableDataAllStore.push(line['store']);
          tableDataAllComment.push(line['comment']);
          tableDataAllClickRate.push(line['clickRate']);
          tableDataAllCommentRate.push(line['commentRate']);
          tableDataAllShareRate.push(line['shareRate']);
          tableDataAllStoreRate.push(line['storeRate']);
        }
        
        tableData1.splice(0, tableData1.length);
        for (var i = 0; i < this.pageSize; i++) {
          var line = tableDataAll1[i];
          line['ev'] = line['ev'];
          line['pv'] = line['pv'];
          line['share'] = line['share'];
           line['rate'] = line['rate'];
          line['store'] = line['store'];
          line['comment'] = line['comment'];
          line['clickRate'] = line['clickRate'];
          line['shareRate'] = line['shareRate'];
          line['commentRate'] = line['commentRate'];
          line['storeRate'] = line['storeRate'];
          tableData1.push(tableDataAll1[i]);
        }
      })
    },
    getChartYestoday: function () {
      this.checkedCh=0;
      var url = 'http://10.80.128.150:58080/newsPortrait/agg/5min?start='+this.getDay(-1)+'0000'+'&stop='+this.getDay(0)+'0000'+'&id='+this.articleId;
      console.log(url)
      var url;
      console.log(this.articleId)

        if(this.articleId.split("-").length>=5){
          url = 'http://10.80.128.150:58080/newsPortrait/agg/5min?start='+this.getDay(-1)+'0000'+'&stop='+this.getDay(0)+'0000'+'&id=video_'+this.articleId;
        }else{
          url = 'http://10.80.128.150:58080/newsPortrait/agg/5min?start='+this.getDay(-1)+'0000'+'&stop='+this.getDay(0)+'0000'+'&id='+this.articleId;
        }


      /*if(this.articleId.indexOf('cmpp')==0){
         url = 'http://10.50.1.130:58080/newsPortrait/agg/5min?start='+this.getDay(-1)+'0000'+'&stop='+this.getDay(0)+'0000'+'&id='+this.articleId
      }else if(this.articleId.indexOf('sports')==0){
         url = 'http://10.50.1.130:58080/newsPortrait/agg/5min?start='+this.getDay(-1)+'0000'+'&stop='+this.getDay(0)+'0000'+'&id='+this.articleId
      }else if(this.articleId.indexOf('client')==0){
         url = 'http://10.50.1.130:58080/newsPortrait/agg/5min?start='+this.getDay(-1)+'0000'+'&stop='+this.getDay(0)+'0000'+'&id='+this.articleId;
      }else if(this.articleId.indexOf('imcp')==0){
         url = 'http://10.50.1.130:58080/newsPortrait/agg/5min?start='+this.getDay(-1)+'0000'+'&stop='+this.getDay(0)+'0000'+'&id='+this.articleId;
      }else if(this.articleId.indexOf('ent_')==0){
         url = 'http://10.50.1.130:58080/newsPortrait/agg/5min?start='+this.getDay(-1)+'0000'+'&stop='+this.getDay(0)+'0000'+'&id='+this.articleId;
      }else{
         
      }*/
      console.log(url)
      this.$http.get(url).then((response) => {
        tableDataAll1.splice(0, tableDataAll1.length);
        tableDataAllTime.splice(0, tableDataAllTime.length);
        tableDataAllEv.splice(0, tableDataAllEv.length);
        tableDataAllPv.splice(0, tableDataAllPv.length);
        tableDataAllShare.splice(0, tableDataAllShare.length);
        tableDataAllStore.splice(0, tableDataAllStore.length);
        tableDataAllComment.splice(0, tableDataAllComment.length);

        tableDataAllClickRate.splice(0, tableDataAllClickRate.length);
        tableDataAllCommentRate.splice(0, tableDataAllCommentRate.length);
        tableDataAllShareRate.splice(0, tableDataAllShareRate.length);
        tableDataAllStoreRate.splice(0, tableDataAllStoreRate.length);
        var temps = response.data;
        for (var i in temps) {
          var temp = temps[i];
          var line = {};
          line['time'] = temp['time'] ? temp['time']: 0;
          line['id'] = temp['id'] ? temp['id']: 0;
          line['ev'] = temp['ev'] ? temp['ev']: 0;
          line['pv'] = temp['pv'] ? temp['pv']: 0;
          line['share'] = temp['share'] ? temp['share']: 0;
          line['store'] = temp['store'] ? temp['store']: 0;
          line['comment'] = temp['comment'] ? temp['comment']: 0;
          line['clickRate'] = temp['clickRate'] ? temp['clickRate']: 0;
          line['rate'] = temp['rate']? temp['rate']: 0;
          line['shareRate'] = temp['shareRate'] ? temp['shareRate']: 0;
          line['commentRate'] = temp['commentRate'] ? temp['commentRate']: 0;
          line['storeRate'] = temp['storeRate'] ? temp['storeRate']: 0;
          tableDataAll1.unshift(line);
          tableDataAllTime.push(line['time'].slice(8, 10)+':'+line['time'].slice(10));
          tableDataAllEv.push(line['ev']);
          tableDataAllPv.push(line['pv']);
          tableDataAllShare.push(line['share']);
          tableDataAllStore.push(line['store']);
          tableDataAllComment.push(line['comment']);
          tableDataAllClickRate.push(line['clickRate']);
          tableDataAllCommentRate.push(line['commentRate']);
          tableDataAllShareRate.push(line['shareRate']);
          tableDataAllStoreRate.push(line['storeRate']);
        }
        tableData1.splice(0, tableData1.length);
        for (var i = 0; i < this.pageSize; i++) {
          var line = tableDataAll1[i];
          line['ev'] = line['ev'];
          line['pv'] = line['pv'];
          line['share'] = line['share'];
          line['store'] = line['store'];
          line['rate'] = line['rate'];
          line['comment'] = line['comment'];
          line['clickRate'] = line['clickRate'];
          line['shareRate'] = line['shareRate'];
          line['commentRate'] = line['commentRate'];
          line['storeRate'] = line['storeRate'];
          tableData1.push(tableDataAll1[i]);
        }
      })
    },
    getChartDay: function () {
      console.log(this.getvalday(this.value1,0))
      console.log(this.getvalday(this.value1,1))
      this.checkedCh=2;
      var url = 'http://10.80.128.150:58080/newsPortrait/agg/5min?start='+this.getvalday(this.value1,0)+'0000'+'&stop='+this.getvalday(this.value1,1)+'0000'+'&id='+this.articleId;
      console.log(url)
      var url;
      console.log(this.articleId)

        if(this.articleId.split("-").length>=5){
          url = 'http://10.80.128.150:58080/newsPortrait/agg/5min?start='+this.getvalday(this.value1,0)+'0000'+'&stop='+this.getvalday(this.value1,1)+'0000'+'&id=video_'+this.articleId;
        }else{
          url = 'http://10.80.128.150:58080/newsPortrait/agg/5min?start='+this.getvalday(this.value1,0)+'0000'+'&stop='+this.getvalday(this.value1,1)+'0000'+'&id='+this.articleId;
        }
      console.log(url)
      this.$http.get(url).then((response) => {
        tableDataAll1.splice(0, tableDataAll1.length);
        tableDataAllTime.splice(0, tableDataAllTime.length);
        tableDataAllEv.splice(0, tableDataAllEv.length);
        tableDataAllPv.splice(0, tableDataAllPv.length);
        tableDataAllShare.splice(0, tableDataAllShare.length);
        tableDataAllStore.splice(0, tableDataAllStore.length);
        tableDataAllComment.splice(0, tableDataAllComment.length);

        tableDataAllClickRate.splice(0, tableDataAllClickRate.length);
        tableDataAllCommentRate.splice(0, tableDataAllCommentRate.length);
        tableDataAllShareRate.splice(0, tableDataAllShareRate.length);
        tableDataAllStoreRate.splice(0, tableDataAllStoreRate.length);
        var temps = response.data;
        for (var i in temps) {
          var temp = temps[i];
          var line = {};
          line['time'] = temp['time'] ? temp['time']: 0;
          line['id'] = temp['id'] ? temp['id']: 0;
          line['ev'] = temp['ev'] ? temp['ev']: 0;
          line['pv'] = temp['pv'] ? temp['pv']: 0;
          line['share'] = temp['share'] ? temp['share']: 0;
          line['store'] = temp['store'] ? temp['store']: 0;
          line['comment'] = temp['comment'] ? temp['comment']: 0;
          line['clickRate'] = temp['clickRate'] ? temp['clickRate']: 0;
          line['rate'] = temp['rate']? temp['rate']: 0;
          line['shareRate'] = temp['shareRate'] ? temp['shareRate']: 0;
          line['commentRate'] = temp['commentRate'] ? temp['commentRate']: 0;
          line['storeRate'] = temp['storeRate'] ? temp['storeRate']: 0;
          tableDataAll1.unshift(line);
          tableDataAllTime.push(line['time'].slice(8, 10)+':'+line['time'].slice(10));
          tableDataAllEv.push(line['ev']);
          tableDataAllPv.push(line['pv']);
          tableDataAllShare.push(line['share']);
          tableDataAllStore.push(line['store']);
          tableDataAllComment.push(line['comment']);
          tableDataAllClickRate.push(line['clickRate']);
          tableDataAllCommentRate.push(line['commentRate']);
          tableDataAllShareRate.push(line['shareRate']);
          tableDataAllStoreRate.push(line['storeRate']);
        }
        tableData1.splice(0, tableData1.length);
        for (var i = 0; i < this.pageSize; i++) {
          var line = tableDataAll1[i];
          line['ev'] = line['ev'];
          line['pv'] = line['pv'];
          line['share'] = line['share'];
          line['store'] = line['store'];
          line['rate'] = line['rate'];
          line['comment'] = line['comment'];
          line['clickRate'] = line['clickRate'];
          line['shareRate'] = line['shareRate'];
          line['commentRate'] = line['commentRate'];
          line['storeRate'] = line['storeRate'];
          tableData1.push(tableDataAll1[i]);
        }
      })
    }
  },
  created: function (tableDataAll) {
    this.getJSON();
  },
  beforeUpdate: function () {
    var option = {
      legend: {
        right: 100,
        data: ['EV', 'PV','分享次数', '分享率','收藏次数','收藏率', '评论次数', '评论率'],
        selectedMode: 'single'
      },
      grid: {
        top:'20%',
        left: '2%',
        right: '4%',
        bottom: '3%',
        containLabel: true
    },
    toolbox: {
        right:'2%',
        top:'8%',
        show: true,
        feature : {
            mark : {show: true},
            dataZoom : {show: true},
            magicType: {type: ['line', 'bar']},
            restore : {show: true},
            saveAsImage : {show: true}
        }
    },
      tooltip: {
        trigger: 'axis',
        position: function (pt) {
          return [pt[0]-50, '10%'];
        }
      },
      /*title: {
        left: 100,
        text: '今日文章数据5分钟粒度统计'
      },*/
      xAxis: {
        type: 'category',
        boundaryGap: false,
        data: this.tableDataAllTime
      },
      yAxis: {
        type: 'value',
        boundaryGap: [0, '30%']
      },
      dataZoom: [
        {
          type: 'slider',
          show: true,
          xAxisIndex: [0],
          start: 0,
          end: 100
        },
        {
          type: 'inside',
          xAxisIndex: [0],
          start: 0,
          end: 100
        }
      ],
      series: [
        {
          name: 'EV',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.tableDataAllEv
        },
        {
          name: 'PV',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.tableDataAllPv
        },
        {
          name: '转化率',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.tableDataAllRate
        },
        {
          name: '分享次数',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.tableDataAllShare
        },
        {
          name: '分享率',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.tableDataAllShareRate
        },
        {
          name: '收藏次数',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.tableDataAllStore
        },
        {
          name: '收藏率',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.tableDataAllStoreRate
        },
        {
          name: '评论次数',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.tableDataAllComment
        },
        {
          name: '评论率',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.tableDataAllCommentRate
        }
      ]
    };
    var myChart = echarts.init(document.getElementById('articleArea'));
    myChart.setOption(option);
  }
}
</script>
<style type="text/css">
  #wholeTable {
    margin-bottom: 10px;
  }
  #wholeTable  ::-webkit-scrollbar{width:4px;}
  #wholeTable  ::-webkit-scrollbar-track{background-color:#bee1eb;}
  #wholeTable ::-webkit-scrollbar-thumb{background-color:#00aff0;}
  #wholeTable ::-webkit-scrollbar-thumb:hover {background-color:#9c3}
  #wholeTable ::-webkit-scrollbar-thumb:active {background-color:#00aff0}
  .contentChart{
    position: fixed;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    z-index: 7;
    background-color: rgba(0,0,0,.5)
  }
  .contentChart .contentInner{
      position:relative;
      width: 800px;
      height: 400px;
      top: 120px;
      left: 50%;
      margin-left: -400px;
      background-color: #fff;
  }
  .contentChart .contentInner h2{
    height: 50px;
    line-height: 50px;
    text-align: center;
    font-size: 22px;
    border: 1px solid #ccc;
  }
  .contentChart .contentInner .contentTab{
    margin-left: 40px;
  }
  .chartShow{
    display: block;
  }
  .chartHide{
    display: none;
  }
  .getJbg{
    background-color: #20a0ff!important;
    color: #fff!important;
  }
  .getChbg{
    background-color: #20a0ff!important;
    color: #fff!important;
  }
</style>

