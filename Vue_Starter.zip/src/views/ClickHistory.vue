<template>
  <!-- 用户点击历史页面 -->
  <div class="animated fadeIn">
    
    <div class="row" style="margin-bottom:20px">
      <div id="wholeTable" style="width: 98%; margin: 0 auto">
      <el-row style="margin-bottom: 10px ">
         <el-col :span="2">
          <el-button type="primary" icon="search" :loading="isLoading" @click="handleClick">搜索</el-button>
        </el-col>
        <el-col :span="18" :offset="1">
          <el-autocomplete placeholder="请输入userkey，点击右侧删除按钮清空搜索历史" style="width: 100%" v-model="input"
          :fetch-suggestions="querySearch" icon="circle-cross" :on-icon-click="handleIconClick"></el-autocomplete>
        </el-col>
      </el-row>
      <el-pagination :total="tableDataAll.length" :page-size="pageSize" :page-sizes="[5, 10, 20, 50, 100, 500]" :current-page="pageCurr"
      layout="total, sizes, prev, pager, next, jumper" @size-change="handleSizeChange" @current-change="handleCurrentChange"></el-pagination>
       <el-table  v-loading="isLoading"   element-loading-text="拼命加载中"  :data="tableData" :row-class-name="tableRowClassName">
        <el-table-column align="center" prop="rt" label="时间" min-width="160px" sortable></el-table-column>
        <el-table-column align="center" prop="type" label="类型" min-width="100px" sortable></el-table-column>
        <el-table-column align="center" prop="id" label="新闻ID" min-width="110px" sortable>
          <template scope="scope">
            <el-button type="text" icon="document" size="mini" @click="handleButtonClick">{{scope.row.id}}</el-button>
          </template>
        </el-table-column>
         <el-table-column align="center" prop="title" label="标题" min-width="210px" sortable></el-table-column>
        <el-table-column align="center" prop="ua" label="机型" min-width="150px" sortable></el-table-column>
        <el-table-column align="center" prop="publishid" label="渠道号" min-width="90px" sortable></el-table-column>
        <el-table-column align="center" prop="mos" label="操作系统" min-width="120px" sortable></el-table-column>
        <el-table-column align="center" prop="ref" label="频道" min-width="100px" sortable></el-table-column>
        <el-table-column align="center" prop="src" label="稿源号" min-width="110px" sortable></el-table-column>
        <el-table-column align="center" prop="datatype" label="客户端类型" min-width="110px" sortable></el-table-column>
        <el-table-column align="center" prop="rToken" label="rToken" min-width="110px" sortable></el-table-column>
        <el-table-column align="center" prop="simid" label="simid" min-width="110px" sortable></el-table-column>
      </el-table>
    </div>
    </div>
  </div><!--/.row-->
</template>

<script>
var 
  input = '',
  history = [],
  pageSize = 10,
  pageCurr = 1,
  tableData = [],
  tableDataAll = [];
export default {
  data () {
    return {
      isLoading: false,
      input: input,
      history: history,
      pageSize: pageSize,
      pageCurr: pageCurr,
      tableData: tableData,
      tableDataAll: tableDataAll
    }
  },
  methods: {
     open() {
        this.$message({
          message:'没有搜到相关数据',
          duration:2000,
          customClass:'messagetop'
         });
      },
    // 清除
    handleIconClick(ev) {
      this.history.splice(0, this.history.length);
      localStorage.setItem('imageHistory', '');
    },
    // 搜索
    handleClick(ev) {
      var res = localStorage.getItem('imageHistory');
      if (res) {
        if (res.indexOf(this.input) == -1) {
          localStorage.setItem('imageHistory', res+' '+this.input);

        } else {
          var start = res.indexOf(this.input);
          var end = start+this.input.length;
          if (start != 0) {
            start = start-1;
          }
          res = res.slice(0, start)+res.slice(end);
          var arr = res.split(' ');
          this.history.splice(0, this.history.length);
          for (var i in arr) {
            this.history.unshift({"value": arr[i]});
          }
          localStorage.setItem('imageHistory', res+' '+this.input);
        }
      } else {
        localStorage.setItem('imageHistory', this.input);
      }
      this.history.unshift({"value": this.input});
      this.getJSON();
    },
    // 历史
    querySearch(queryString, cb) {
      if (this.history.length == 0) {
        var res = localStorage.getItem('imageHistory');
        if (res) {
          var arr = res.split(' ');
          for (var i in arr) {
            this.history.unshift({"value": arr[i]});
          }
        }
      }
      cb(this.history);
    },
    // 分页
    handleSizeChange(val) {
      this.pageSize = val;
      this.pageCurr = 1;
      tableData.splice(0, tableData.length);
      for (var i = 0; i < val; i++) {
        if(tableDataAll[i].id.indexOf('yz') != -1){
                  tableDataAll[i]['title']="用户中心";
                  tableData.push(tableDataAll[i]);
                }else if(tableDataAll[i].id.indexOf('rpack') != -1){
                    tableDataAll[i]['title']="红包活动页";
                    tableData.push(tableDataAll[i]);
                }else if(tableDataAll[i].id.indexOf('srh') != -1){
                    tableDataAll[i]['title']="srh-搜索关键字";
                    tableData.push(tableDataAll[i]);
                }else if(tableDataAll[i].id.indexOf('lgp') != -1){
                    tableDataAll[i]['title']="页面登录";
                    tableData.push(tableDataAll[i]);
                }else if(tableDataAll[i].id.indexOf('submanage') != -1){
                    tableDataAll[i]['title']="自媒体管理";
                    tableData.push(tableDataAll[i]);
                }else if(tableDataAll[i].id.indexOf('ys') != -1){
                    tableDataAll[i]['title']="用户设置页";
                    tableData.push(tableDataAll[i]);
                }else if(tableDataAll[i].id.indexOf('newscache') != -1){
                    tableDataAll[i]['title']="推送设置页";
                    tableData.push(tableDataAll[i]);
                }else if(tableDataAll[i].id.indexOf('msub') != -1){
                    tableDataAll[i]['title']="我的订阅";
                    tableData.push(tableDataAll[i]);
                }else if(tableDataAll[i].id.indexOf('dl') != -1){
                    tableDataAll[i]['title']="订阅列表页";
                    tableData.push(tableDataAll[i]);
                }else if(tableDataAll[i].id.indexOf('bind') != -1){
                    tableDataAll[i]['title']="绑定页面";
                    tableData.push(tableDataAll[i]);
                }else{
                   var urlT='http://local.data.ifengidc.com/newsPortrait/agg?start=20170707&stop=20170706&id='+tableDataAll[i].id;
                      $.ajax( {  
                          url:urlT,// 跳转到 action  
                         type:'get',  
                         cache:true,  
                         async:false, 
                         dataType:'json',  
                         success:function(response) { 
                         console.log(response) 
                             tableDataAll[i]['title']=response.newsInfo.title;
                          console.log(tableDataAll[i]['title'])
                          tableData.push(tableDataAll[i]);
                          console.log(tableData)
                          },  
                          error : function() {  
                               // view("异常！");  
                              alert("异常！");  
                          }  
                     });
                }
       
      }
    },
    // 换页
    handleCurrentChange(val) {
      this.pageCurr = val;
      tableData.splice(0, tableData.length);
      var end = (tableDataAll.length > (this.pageCurr)*(this.pageSize)) ? (this.pageCurr)*(this.pageSize) : tableDataAll.length;
      for (var i = (this.pageCurr-1)*(this.pageSize); i < end; i++) {
       
         if(tableDataAll[i].id.indexOf('yz') != -1){
                  tableDataAll[i]['title']="用户中心";
                  tableData.push(tableDataAll[i]);
                }else if(tableDataAll[i].id.indexOf('rpack') != -1){
                    tableDataAll[i]['title']="红包活动页";
                    tableData.push(tableDataAll[i]);
                }else if(tableDataAll[i].id.indexOf('srh') != -1){
                    tableDataAll[i]['title']="srh-搜索关键字";
                    tableData.push(tableDataAll[i]);
                }else if(tableDataAll[i].id.indexOf('lgp') != -1){
                    tableDataAll[i]['title']="页面登录";
                    tableData.push(tableDataAll[i]);
                }else if(tableDataAll[i].id.indexOf('submanage') != -1){
                    tableDataAll[i]['title']="自媒体管理";
                    tableData.push(tableDataAll[i]);
                }else if(tableDataAll[i].id.indexOf('ys') != -1){
                    tableDataAll[i]['title']="用户设置页";
                    tableData.push(tableDataAll[i]);
                }else if(tableDataAll[i].id.indexOf('newscache') != -1){
                    tableDataAll[i]['title']="推送设置页";
                    tableData.push(tableDataAll[i]);
                }else if(tableDataAll[i].id.indexOf('msub') != -1){
                    tableDataAll[i]['title']="我的订阅";
                    tableData.push(tableDataAll[i]);
                }else if(tableDataAll[i].id.indexOf('dl') != -1){
                    tableDataAll[i]['title']="订阅列表页";
                    tableData.push(tableDataAll[i]);
                }else if(tableDataAll[i].id.indexOf('bind') != -1){
                    tableDataAll[i]['title']="绑定页面";
                    tableData.push(tableDataAll[i]);
                }else{
                   var urlT='http://local.data.ifengidc.com/newsPortrait/agg?start=20170707&stop=20170706&id='+tableDataAll[i].id;
                      $.ajax( {  
                          url:urlT,// 跳转到 action  
                         type:'get',  
                         cache:true,  
                         async:false, 
                         dataType:'json',  
                         success:function(response) { 
                         console.log(response) 
                             tableDataAll[i]['title']=response.newsInfo.title;
                          console.log(tableDataAll[i]['title'])
                          tableData.push(tableDataAll[i]);
                          console.log(tableData)
                          },  
                          error : function() {  
                               // view("异常！");  
                              alert("异常！");  
                          }  
                     });
                    }
      }
    },
    tableRowClassName(row, index) {
      if (index%2 != 0) {
        return 'odd-row';
      } else if (index%2 == 0) {
        return 'even-row';
      }
      return '';
    },
    // 跳转
    handleButtonClick(ev) {
      if (ev.target.innerText.indexOf('cmpp') != -1) {
               var url = 'http://share.iclient.ifeng.com/sharenews.f?aid='+ev.target.innerText;
        window.open(url)
      }else if(ev.target.innerText.indexOf('imcp_crc') != -1){
                var url = 'http://share.iclient.ifeng.com/sharenews.f?guid='+ev.target.innerText;
        window.open(url)
      }else if(ev.target.innerText.indexOf('imcp') != -1){
                var url = 'http://share.iclient.ifeng.com/sharenews.f?aid='+ev.target.innerText;
        window.open(url)
      }else if(ev.target.innerText.indexOf('video') != -1){
                var url = 'http://share.iclient.ifeng.com/sharenews.f?guid='+ev.target.innerText.substring(6);
        window.open(url)

      }else if(ev.target.innerText.indexOf('sub_') != -1){
                var url = 'http://share.iclient.ifeng.com/vampire/sharenews.f?fromType=vampire&aid='+ev.target.innerText.substring(4);
        window.open(url)

      } else {
                var newWin = window.open();
        var urlT = 'http://local.api.iclient.ifeng.com/getAbNewslist?type=news&onlyId=1&id='+ev.target.innerText;
        this.$http.get(urlT).then((response) => {
          var staticId=JSON.parse(response.bodyText)['msg'][0].staticId
           url = 'http://share.iclient.ifeng.com/sharenews.f?aid='+staticId;
           newWin.location.href = url;
        })
      }
    },
    getDay: function (target) {
      var today = new Date();
      today.setTime(target);
      var year = today.getFullYear();
      var month = today.getMonth();
      var date = today.getDate();
      month = this.addZero(month+1);
      date = this.addZero(date);
      return year.toString()+'-'+month.toString()+'-'+date.toString();
    },
    getDaytime: function (target) {
      var today = new Date();
      today.setTime(target);
      var hour = today.getHours();
      var minute = today.getMinutes();
      var second = today.getSeconds();
      hour = this.addZero(hour);
      minute = this.addZero(minute);
      second = this.addZero(second);
      return hour.toString()+':'+minute.toString()+':'+second.toString();
    },
    addZero: function (time) {
      if (time.toString().length == 1) {
        time = '0'+time;
      }
      return time;
    },
    getJSON: function () {
      this.isLoading = true;
      var url = 'http://10.80.128.150:58080/click_history?userkey='+this.input;
      this.$http.get(url).then((response) => {
        this.isLoading = false;
        console.log(response)
        tableDataAll.splice(0, tableDataAll.length);
          if(response.data!=''){
          tableDataAll.splice(0, tableDataAll.length);
          var temps = response.data;
          for (var i in temps) {
            var temp=temps[i];
            /*temp['title']='nihao'*/
            tableDataAll.push(temp)
          }
          tableData.splice(0, tableData.length);
          console.log(tableData)
          for (var i = 0; i < this.pageSize; i++) {
            tableDataAll[i]['ua'] = decodeURIComponent(tableDataAll[i]['ua']);
            if(tableDataAll[i].id.indexOf('yz') != -1){
                  tableDataAll[i]['title']="用户中心";
                  tableData.push(tableDataAll[i]);
                }else if(tableDataAll[i].id.indexOf('rpack') != -1){
                    tableDataAll[i]['title']="红包活动页";
                    tableData.push(tableDataAll[i]);
                }else if(tableDataAll[i].id.indexOf('srh') != -1){
                    tableDataAll[i]['title']="srh-搜索关键字";
                    tableData.push(tableDataAll[i]);
                }else if(tableDataAll[i].id.indexOf('lgp') != -1){
                    tableDataAll[i]['title']="页面登录";
                    tableData.push(tableDataAll[i]);
                }else if(tableDataAll[i].id.indexOf('submanage') != -1){
                    tableDataAll[i]['title']="自媒体管理";
                    tableData.push(tableDataAll[i]);
                }else if(tableDataAll[i].id.indexOf('ys') != -1){
                    tableDataAll[i]['title']="用户设置页";
                    tableData.push(tableDataAll[i]);
                }else if(tableDataAll[i].id.indexOf('newscache') != -1){
                    tableDataAll[i]['title']="推送设置页";
                    tableData.push(tableDataAll[i]);
                }else if(tableDataAll[i].id.indexOf('msub') != -1){
                    tableDataAll[i]['title']="我的订阅";
                    tableData.push(tableDataAll[i]);
                }else if(tableDataAll[i].id.indexOf('dl') != -1){
                    tableDataAll[i]['title']="订阅列表页";
                    tableData.push(tableDataAll[i]);
                }else if(tableDataAll[i].id.indexOf('bind') != -1){
                    tableDataAll[i]['title']="绑定页面";
                    tableData.push(tableDataAll[i]);
                }else{
                   var urlT='http://local.data.ifengidc.com/newsPortrait/agg?start=20170707&stop=20170706&id='+tableDataAll[i].id;
                  $.ajax( {  
                      url:urlT,// 跳转到 action  
                     type:'get',  
                     cache:true,  
                     async:false, 
                     dataType:'json',  
                     success:function(response) { 
                     console.log(response) 
                         tableDataAll[i]['title']=response.newsInfo.title;
                      console.log(tableDataAll[i]['title'])
                      tableData.push(tableDataAll[i]);
                      console.log(tableData)
                      },  
                      error : function() {  
                           // view("异常！");  
                          alert("异常！");  
                      }  
                 });
                }
          }
        }else{
          this.open();
          tableDataAll.length=0;
          tableData.length=0;
          console.log(tableDataAll);
          console.log(tableData);
        }
        
      })
    }
  },
  mounted: function () {
    var _this = this;
    document.getElementsByTagName('input')[0].onkeydown = function (e) {
      if (e.keyCode == 13) {
        _this.handleClick();
      }
    };
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style>
.messagetop{
  top: 30%!important;
}
</style>
