<template>
  <!-- 用户推荐历史页面 -->
  <div class="animated fadeIn">
    
    <div class="row" style="margin-bottom:20px">
      <div id="wholeTable" style="width: 98%; margin: 0 auto">
      <el-row style="margin-bottom: 10px ">
         <el-col :span="2">
          <el-button type="primary" icon="search" :loading="isLoading" @click="handleClick">搜索</el-button>
        </el-col> 
        <el-col :span="18" :offset="1">
          <el-autocomplete placeholder="请输入userkey，点击右侧删除按钮清空搜索历史" style="width: 100%" v-model="input"
          :fetch-suggestions="querySearch" icon="circle-cross" :on-icon-click="handleIconClick"></el-autocomplete>
        </el-col>
      </el-row>
      <el-tooltip  effect="dark" placement="bottom" >
        <div class="tooltipMsg" slot="content">推荐原因字段解释：<br/>数据来源#推送原因#辅助说明<br/><br/>
              数据来源：<br/> 
          cf_item => 短期点击内容协同 <br/> 
          cf_user => 短期点击用户协同 <br/> 
          keyword_like => 短期感兴趣关键词  <br/> 
          keyword_like_longterm => 长期感兴趣关键词 <br/> 
          category_s => 短期兴趣分类 <br/> 
          category => 长期兴趣分类 <br/>
          hot => 热集<br/>
          jppool=> 精品池（编辑精选） <br/>
        </div>
      <i class="el-icon-warning" style="float: right;margin:7px 15px"></i>
      </el-tooltip>
      <el-pagination :total="tableDataAll.length" :page-size="pageSize" :page-sizes="[5, 10, 20, 50, 100, 500]" :current-page="pageCurr"
      layout="total, sizes, prev, pager, next, jumper" @size-change="handleSizeChange" @current-change="handleCurrentChange"></el-pagination>
      
    <el-table  v-loading="isLoading"   element-loading-text="拼命加载中" :data="tableData" :row-class-name="tableRowClassName">
        <el-table-column align="center" prop="dealTime" label="时间" min-width="120px" sortable></el-table-column>
        <el-table-column align="center" prop="guid" label="guid" min-width="200px" sortable>
              <template scope="scope">
                <el-button type="text" style="user-select: initial;" icon="document" size="mini" @click="handleButtonClick">{{scope.row.guid}}</el-button>
              </template>
            </el-table-column>
        <el-table-column align="center" prop="title" label="标题" min-width="220px" sortable></el-table-column>
        <el-table-column align="center" prop="bizType" label="业务来源" min-width="120px" sortable></el-table-column>
        <el-table-column align="center" prop="cpname" label="cpname" min-width="100px" sortable></el-table-column>
        <el-table-column align="center" prop="categoryId" label="categoryId" min-width="100px" sortable></el-table-column>
         <el-table-column align="center" prop="categoryName" label="categoryName" min-width="120px" sortable></el-table-column>
         <el-table-column align="center" prop="recomMachine" label="recomMachine" min-width="120px" sortable></el-table-column>
        <el-table-column align="center" prop="recomMethod" label="recomMethod" min-width="120px" sortable></el-table-column>
        <el-table-column align="center" prop="cfItemSource" label="cfItemSource" min-width="200px" sortable></el-table-column>
        <el-table-column align="center" prop="lastDoc" label="lastDoc" min-width="500px" sortable></el-table-column>
        <el-table-column align="center" prop="score" label="评分" min-width="120px" sortable></el-table-column>
        <el-table-column align="center" prop="simId" label="simId" min-width="120px" sortable></el-table-column>
        <el-table-column align="center" prop="source" label="source" min-width="120px" sortable></el-table-column>
        <el-table-column align="center" prop="updatetime" label="更新时间" min-width="120px" sortable></el-table-column>
        <el-table-column align="center" prop="keywordHit" label="keywordHit" min-width="120px" sortable></el-table-column>
        <el-table-column align="center" prop="recomToken" label="recomToken" min-width="200px" sortable></el-table-column>
        <el-table-column align="center" prop="dataSource" label="dataSource" min-width="120px" sortable></el-table-column>
        <el-table-column align="center" prop="statSource" label="statSource" min-width="120px" sortable></el-table-column>
         <el-table-column align="center" prop="onecategoryname" label="onecategoryname" min-width="120px" sortable></el-table-column>
        <el-table-column align="center" prop="city" label="城市" min-width="150px" sortable></el-table-column>
        <el-table-column align="center" prop="province" label="省份" min-width="180px" sortable></el-table-column>
         <el-table-column align="center" prop="gv" label="版本号" min-width="180px" sortable></el-table-column>
        <el-table-column align="center" prop="num" label="num" min-width="120px" sortable></el-table-column>
        <el-table-column align="center" prop="nw" label="网络制式" min-width="120px" sortable></el-table-column>
        <el-table-column align="center" prop="proid" label="渠道号" min-width="120px" sortable></el-table-column>
      </el-table>
    </div>
    </div>
  </div><!--/.row-->
 
</template>

<script>
var 
  input = '',
  history = [],
  pageSize = 10,
  pageCurr = 1,
  tableData = [],
  tableDataAll = [];
export default {
  data () {
    return {
      isLoading: false,
      input: input,
      history: history,
      pageSize: pageSize,
      pageCurr: pageCurr,
      tableData: tableData,
      tableDataAll: tableDataAll
    }
  },
  methods: {
     open() {
        this.$message({
          message:'没有搜到相关数据',
          duration:2000,
          customClass:'messagetop'
         });
      },
    // 清除
    handleIconClick(ev) {
      this.history.splice(0, this.history.length);
      localStorage.setItem('imageHistory', '');
    },
    // 搜索
    handleClick(ev) {
      var res = localStorage.getItem('imageHistory');
      if (res) {
        if (res.indexOf(this.input) == -1) {
          localStorage.setItem('imageHistory', res+' '+this.input);
        } else {
          var start = res.indexOf(this.input);
          var end = start+this.input.length;
          if (start != 0) {
            start = start-1;
          }
          res = res.slice(0, start)+res.slice(end);
          var arr = res.split(' ');
          this.history.splice(0, this.history.length);
          for (var i in arr) {
            this.history.unshift({"value": arr[i]});
          }
          localStorage.setItem('imageHistory', res+' '+this.input);
        }
      } else {
        localStorage.setItem('imageHistory', this.input);
      }
      this.history.unshift({"value": this.input});
      this.getJSON();
    },
    // 历史
    querySearch(queryString, cb) {
      if (this.history.length == 0) {
        var res = localStorage.getItem('imageHistory');
        if (res) {
          var arr = res.split(' ');
          for (var i in arr) {
            this.history.unshift({"value": arr[i]});
          }
        }
      }
      cb(this.history);
    },
    // 分页
    handleSizeChange(val) {
      this.pageSize = val;
      this.pageCurr = 1;
      tableData.splice(0, tableData.length);
      for (var i = 0; i < val; i++) {
        if(tableDataAll[i]!=undefined){
          tableData.push(tableDataAll[i]);
        }
        
      }
    },
    // 换页
    handleCurrentChange(val) {
      this.pageCurr = val;
      tableData.splice(0, tableData.length);
      var end = (tableDataAll.length > (this.pageCurr)*(this.pageSize)) ? (this.pageCurr)*(this.pageSize) : tableDataAll.length;
      for (var i = (this.pageCurr-1)*(this.pageSize); i < end; i++) {
        tableData.push(tableDataAll[i]);
      }
    },
    tableRowClassName(row, index) {
      if (index%2 != 0) {
        return 'odd-row';
      } else if (index%2 == 0) {
        return 'even-row';
      }
      return '';
    },
    // 跳转
    handleButtonClick(ev) {
      console.log(ev)
      if (ev.target.innerText.indexOf('cmpp') != -1) {
        var url = 'http://share.iclient.ifeng.com/sharenews.f?aid='+ev.target.innerText;
        window.open(url)
      }else if(ev.target.innerText.indexOf('sport') != -1){
        var url = 'http://share.iclient.ifeng.com/sharenews.f?aid='+ev.target.innerText;
        window.open(url)
      }else{
        var url = 'http://share.iclient.ifeng.com/sharenews.f?guid='+ev.target.innerText;
        window.open(url)
      }
    },
    getDay: function (target) {
      var today = new Date();
      today.setTime(target);
      var year = today.getFullYear();
      var month = today.getMonth();
      var date = today.getDate();
      month = this.addZero(month+1);
      date = this.addZero(date);
      return year.toString()+'-'+month.toString()+'-'+date.toString();
    },
    getDaytime: function (target) {
      var today = new Date();
      today.setTime(target);
      var hour = today.getHours();
      var minute = today.getMinutes();
      var second = today.getSeconds();
      hour = this.addZero(hour);
      minute = this.addZero(minute);
      second = this.addZero(second);
      return hour.toString()+':'+minute.toString()+':'+second.toString();
    },
    addZero: function (time) {
      if (time.toString().length == 1) {
        time = '0'+time;
      }
      return time;
    },
    getJSON: function () {
      this.isLoading = true;
      var url = 'http://10.80.128.150:58080/video_rec_history?userkey='+this.input;
      this.$http.get(url).then((response) => {
       this.isLoading = false;
        console.log(response.data)
        var data=response.data
        var DataAll=[];
        for(var i=0;i<data.length;i++){
          $.each(data[i]['data'],function(index,item){
            var dataObj={};
            for(var j in item){
              dataObj[j]=item[j]
            }
            dataObj['bizType']=data[i]['bizType'];
            dataObj['dealTime']=data[i]['dealTime'];
            for(var k in data[i]['requestParams']){
              dataObj[k]=data[i]['requestParams'][k]
            }
            DataAll.push(dataObj)
          })
          
          
        }
        console.log(DataAll)
        tableDataAll.splice(0, tableDataAll.length);
         if(response.data!=''){
              var temps = DataAll;
              for (var i in temps) {
              var temp = temps[i];
              var line = {};
              console.log(Number(temp['dealTime']))
              line['dealTime'] = this.getDay(Number(temp['dealTime']))+' '+this.getDaytime(Number(temp['dealTime']));
              line['action'] = temp['action'];
              line['bizType'] = temp['bizType'];
              line['categoryId'] = temp['categoryId'];
              line['categoryName'] = temp['categoryName'];
              line['cfItemSource'] = temp['cfItemSource'];
              line['cpname'] = temp['cpname'];
              
              line['city'] = temp['city'];
              line['dataSource'] = temp['dataSource'];
              line['flag'] = temp['flag'];
              line['guid'] = temp['guid'];
              line['gv'] = temp['gv'];
              line['keywordHit'] = temp['keywordHit'];
              line['readableFeatures'] = temp['readableFeatures'];
              line['lastDoc'] = temp['lastDoc'];
              line['num'] = temp['num'];
              line['nw'] = temp['nw'];

              line['onecategoryname'] = temp['onecategoryname'];
              line['proid'] = temp['proid'];
              line['province'] = temp['province'];
              line['recomMachine'] = temp['recomMachine'];
              line['recomMethod'] = temp['recomMethod'];
              line['recomToken'] = temp['recomToken'];
              line['simId'] = temp['simId'];
              line['score'] = temp['score'];
              line['source'] = temp['source'];
              line['statSource'] = temp['statSource'];
              line['title'] = temp['title'];
              line['updatetime'] = temp['updatetime'];
              tableDataAll.push(line);
            }
            console.log(tableDataAll)
            tableData.splice(0, tableData.length);

            for (var i = 0; i < this.pageSize; i++) {
              if(tableDataAll[i]!=undefined){
                tableData.push(tableDataAll[i]);
              }
              
            }
         }else{
          this.open();
          tableDataAll.length=0;
          tableData.length=0;
         }
        console.log(tableData)
      })
    }
  },
  mounted: function () {
    var _this = this;
    document.getElementsByTagName('input')[0].onkeydown = function (e) {
      if (e.keyCode == 13) {
        _this.handleClick();
      }
    };
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style >
span{
  -webkit-user-select: initial;
  user-select: initial;
}
.messagetop{
  top: 30%!important;
}
</style>
