<template>
  <!-- 频道（540）页面 -->
   <div class="animated fadeIn">
    <div class="card">
      <div class="card-block">
        <div class="row">
          <div class="col-sm-5">
            <h4 class="card-title">头条展示分类曲线图</h4>
            <div class="small text-muted"></div>
          </div><!--/.col-->
        </div><!--/.row-->
         <div id="channelArea" style="width: 100%; height: 400px; margin: 0 auto;text-align: -webkit-center;"></div>
      </div>
    </div><!--/.card-->
    <div class="row" style="margin-bottom:20px">
      <div id="wholeTable" style="width: 98%; margin: 0 auto">
      <el-row style="margin-bottom: -10px ">
        <el-col :span="9">
          <el-pagination :total="tableDataAll.length" :page-size="pageSize" :page-sizes="[5, 10, 15, 20]" :current-page="pageCurr"
          layout="total, sizes, prev, pager, next, jumper" @size-change="handleSizeChange" @current-change="handleCurrentChange"></el-pagination>
        </el-col>
        <el-col :span="2" :offset="1" style="margin-top: -4px">
          <el-button type="text" icon="upload2" @click="handleClick">导出</el-button>
        </el-col>
        <el-col :span="3" style="margin-top: -4px">
          <el-select placeholder="type" filterable v-model="option" @change="handleSelectChange">
            <el-option v-for="item in options" :label="item.label" :value="item.value"></el-option>
          </el-select>
        </el-col>
        <el-col :span="3" style="margin-top: -4px">
          <el-select placeholder="showType" filterable v-model="option1" @change="handleSelectChange">
            <el-option v-for="item in optionsType" :label="item.label" :value="item.value"></el-option>
          </el-select>
        </el-col>
        <el-col :span="3" style="margin-top: -4px">
          <el-date-picker type="daterange" placeholder="选择日期范围" :clearable="false" v-model="input" @change="handleChange"></el-date-picker>
        </el-col>
      </el-row>
      <el-tooltip  effect="dark" placement="bottom" >
        <div slot="content">展示类型：<br/>3小图：3pic<br/>大图：hdpic<br/>左图右文：pictxt<br/>无图：nopic<br/></div>
      <i class="el-icon-warning" style="float: right;margin:7px 15px"></i>
      </el-tooltip>
        <el-table v-loading="isLoading"   element-loading-text="拼命加载中"  stripe :data="tableData" :row-class-name="tableRowClassName">
          <el-table-column align="center" v-for="item in columns" :prop="item.prop" :label="item.label" :min-width="item.width" sortable>
          </el-table-column>
        </el-table>
    </div>
    </div>
  </div><!--/.row-->

</template>

<script>
import echarts from 'echarts'
var save = [],
  option = 'docpic',
  option1 ='pictxt',
  options = [],
  optionsType = [],
  input = '',
  startDate = '',
  endDate = '',
  pageSize = 10,
  pageCurr = 1,
  myChart,
  columns = [
    {
      prop: 'date',
      label: '日期',
      width: '120px'
    },
    {
      prop: 'type',
      label: '类型',
      width: '90px'
    },
    {
      prop: 'showtype',
      label: '展示类型',
      width: '90px'
    },
    {
      prop: 'pagenum',
      label: '文章量',
      width: '90px'
    },
    {
      prop: 'ev',
      label: '文章曝光量EV',
      width: '120px'
    },
    {
      prop: 'euv',
      label: '曝光人数EVU',
      width: '100px'
    },
    {
      prop: 'ev_avg',
      label: '人均曝光量',
      width: '120px'
    },
    {
      prop: 'pv',
      label: '阅读PV',
      width: '120px'
    },
    {
      prop: 'uv',
      label: '阅读UV',
      width: '100px'
    },
    {
      prop: 'pv_avg',
      label: '人均阅读数',
      width: '120px'
    },
    {
      prop: 'pv_rate',
      label: '转化率',
      width: '120px'
    },
    {
      prop: 'share',
      label: '分享次数',
      width: '100px'
    },
    {
      prop: 'share_rate',
      label: '分享率',
      width: '100px'
    },
    {
      prop: 'store',
      label: '收藏次数',
      width: '100px'
    },
    {
      prop: 'store_rate',
      label: '收藏率',
      width: '90px'
    },
    {
      prop: 'comment',
      label: '评论次数',
      width: '90px'
    },
    {
      prop: 'comment_avg',
      label: '评论率',
      width: '90px'
    },
    {
      prop: 'duration',
      label: '阅读时长',
      width: '90px'
    },
    {
      prop: 'duration_avg',
      label: '人均浏览时长（分）',
      width: '90px'
    },
    {
      prop: 'ev_rate',
      label: '曝光占比',
      width: '90px'
    },
    {
      prop: 'rate1',
      label: '一日曝光留存',
      width: '90px'
    },
    {
      prop: 'rate7',
      label: '七日曝光留存',
      width: '90px'
    }
  ],
  tableData = [],
  tableDataAll = [],
  tableDataAllDate = [],
  tableDataAllPagenum = [],
  tableDataAllEv = [],
  tableDataAllEuv = [],
  tableDataAllEv_avg = [],
  tableDataAllPv = [],
  tableDataAllUv = [],
  tableDataAllPv_avg = [],
  tableDataAllPv_rate= [],
  tableDataAllShare = [],
  tableDataAllShare_rate = [],
  tableDataAllStore = [],
  tableDataAllStore_rate = [],
  tableDataAllComment = [],
  tableDataAllComment_avg = [],
  tableDataAllDuration = [],
  tableDataAllDuration_avg = [],
  tableDataAllEv_rate = [],
  tableDataAllRate1 = [],
  tableDataAll7ate7 = [];
export default {
  data () {
    return {
      isLoading: false,
      save: save,
      option: option,
      option1: option1,
      options: options,
      optionsType:optionsType,
      input: input,
      startDate: startDate,
      endDate: endDate,
      pageSize: pageSize,
      pageCurr: pageCurr,
      columns: columns,
      tableData: tableData,
      tableDataAll: tableDataAll,
      tableDataAllDate: tableDataAllDate,
      tableDataAllPagenum: tableDataAllPagenum,
      tableDataAllEv: tableDataAllEv,
      tableDataAllEuv: tableDataAllEuv,
      tableDataAllEv_avg: tableDataAllEv_avg,
      tableDataAllPv: tableDataAllPv,
      tableDataAllUv: tableDataAllUv,
      tableDataAllPv_avg: tableDataAllPv_avg,
      tableDataAllPv_rate: tableDataAllPv_rate,
      tableDataAllShare: tableDataAllShare,
      tableDataAllShare_rate: tableDataAllShare_rate,
      tableDataAllStore: tableDataAllStore,
      tableDataAllStore_rate: tableDataAllStore_rate,
      tableDataAllComment: tableDataAllComment,
      tableDataAllComment_avg: tableDataAllComment_avg,
      tableDataAllDuration: tableDataAllDuration,
      tableDataAllDuration_avg: tableDataAllDuration_avg,
      tableDataAllEv_rate: tableDataAllEv_rate,
      tableDataAllRate1: tableDataAllRate1,
      tableDataAll7ate7: tableDataAll7ate7
    }
  },
  methods: {
    //download
    handleClick(ev) {
       var url='http://10.80.128.150:58080/headline/headlineShowtype/excel?startDate='+this.startDate+'&endDate='+this.endDate+'&col='+encodeURI(JSON.stringify(columns));
    //   var url = 'http://10.50.1.130:58080/channel/channel540Data/excel?startDate='+this.startDate+'&endDate='+this.endDate+'&col='+encodeURI(JSON.stringify(columns));
      console.log(url);
      window.open(url);
    },
    // 选择
    handleSelectChange() {
      tableDataAllDate.splice(0, tableDataAllDate.length);
      tableDataAllPagenum.splice(0, tableDataAllPagenum.length);
      tableDataAllEv.splice(0, tableDataAllEv.length);
      tableDataAllEuv.splice(0, tableDataAllEuv.length);
      tableDataAllEv_avg.splice(0, tableDataAllEv_avg.length);
      tableDataAllPv.splice(0, tableDataAllPv.length);
      tableDataAllUv.splice(0, tableDataAllUv.length);
      tableDataAllPv_avg.splice(0, tableDataAllPv_avg.length);
      tableDataAllPv_rate.splice(0, tableDataAllPv_rate.length);
      tableDataAllShare.splice(0, tableDataAllShare.length);
      tableDataAllShare_rate.splice(0, tableDataAllShare_rate.length);
      tableDataAllStore.splice(0, tableDataAllStore.length);
      tableDataAllStore_rate.splice(0, tableDataAllStore_rate.length);
      tableDataAllComment.splice(0, tableDataAllComment.length);
      tableDataAllComment_avg.splice(0, tableDataAllComment_avg.length);
      tableDataAllDuration.splice(0, tableDataAllDuration.length);
      tableDataAllDuration_avg.splice(0, tableDataAllDuration_avg.length);
      tableDataAllEv_rate.splice(0, tableDataAllEv_rate.length);
      tableDataAllRate1.splice(0, tableDataAllRate1.length);
      tableDataAll7ate7.splice(0, tableDataAll7ate7.length)
      var count = 0;
      console.log(save)
      for (var i in save) {
        var line = save[i];
        if ((line['type'] == this.option)&&(line['showtype'] == this.option1)) {
          tableDataAll.push(line);
          count++;
          tableDataAllDate.unshift(line['date']);
          tableDataAllPagenum.unshift(line['pagenum']);
          tableDataAllEv.unshift(line['ev']);
          tableDataAllEuv.unshift(line['euv']);
          tableDataAllEv_avg.unshift(line['ev_avg']);
          tableDataAllPv.unshift(line['pv']);
          tableDataAllUv.unshift(line['uv']);
          tableDataAllPv_avg.unshift(line['pv_avg']);
          tableDataAllPv_rate.unshift(parseFloat(line['pv_rate']));
          tableDataAllShare.unshift(line['share']);
          tableDataAllShare_rate.unshift(parseFloat(line['share_rate']));
          tableDataAllStore.unshift(line['store']);
          tableDataAllStore_rate.unshift(parseFloat(line['store_rate']));
          tableDataAllComment.unshift(line['comment']);
          tableDataAllComment_avg.unshift(parseFloat(line['comment_avg']));
          tableDataAllDuration.unshift(line['duration']);
          tableDataAllDuration_avg.unshift(line['duration_avg']);
          tableDataAllEv_rate.unshift(parseFloat(line['ev_rate']));
          tableDataAllRate1.unshift(parseFloat(line['rate1']));
          tableDataAll7ate7.unshift(parseFloat(line['rate7']));
        }
      }
      console.log(tableDataAllEv)
      console.log(tableDataAllDate)
      this.pageCurr = 1;
      tableDataAll.splice(0, tableDataAll.length-count);
      tableData.splice(0, tableData.length);
      if (tableDataAll.length < 5) {
        this.pageSize = tableDataAll.length;
      } else {
        this.pageSize = 10;
      }
      for (var i = 0; i < this.pageSize; i++) {
        var line = tableDataAll[i];
        line['date'] = line['date'];
          line['type'] = line['type'];
          line['showtype'] = line['showtype'];
          line['pagenum'] = line['pagenum'];
          line['ev'] = line['ev'];
          line['euv'] = line['euv'];
          line['ev_avg'] = line['ev_avg'];
          line['pv'] = line['pv'];
          line['uv'] = line['uv'];
          line['pv_avg'] = line['pv_avg'];
          line['pv_rate'] = line['pv_rate'];
          line['share'] =line['share'];
          line['share_rate'] = line['share_rate'];
          line['store'] = line['store'];
          line['store_rate'] = line['store_rate'];
          line['comment'] = line['comment'] ;
          line['comment_avg'] = line['comment_avg'];
          line['duration'] = line['duration'];
          line['duration_avg'] =  line['duration_avg'];
          line['ev_rate'] = line['ev_rate'];
          line['rate1'] = line['rate1'];
          line['rate7'] = line['rate7'];
        tableData.push(tableDataAll[i]);
      }

      console.log('tableDataAllPv_rate',tableDataAllPv_rate)
    },
    // 选择
    handleChange(val) {
      this.startDate = val.slice(0, 10);
      this.endDate = val.slice(13, 23);
      this.getJSON();
    },
    // 分页
    handleSizeChange(val) {
      this.pageSize = val;
      this.pageCurr = 1;
      tableData.splice(0, tableData.length);
      console.log(tableDataAll.length)
      console.log(val)
      val=val>=tableDataAll.length?tableDataAll.length:val
      console.log(val)
      for (var i = 0; i < val; i++) {
        var line = tableDataAll[i];
        line['date'] = line['date'];
          line['type'] = line['type'];
          line['showtype'] = line['showtype'];
          line['pagenum'] = line['pagenum'];
          line['ev'] = line['ev'];
          line['euv'] = line['euv'];
          line['ev_avg'] = line['ev_avg'];
          line['pv'] = line['pv'];
          line['uv'] = line['uv'];
          line['pv_avg'] = line['pv_avg'];
          line['pv_rate'] = line['pv_rate'];
          line['share'] =line['share'];
          line['share_rate'] = line['share_rate'];
          line['store'] = line['store'];
          line['store_rate'] = line['store_rate'];
          line['comment'] = line['comment'] ;
          line['comment_avg'] = line['comment_avg'];
          line['duration'] = line['duration'];
          line['duration_avg'] =  line['duration_avg'];
          line['ev_rate'] = line['ev_rate'];
          line['rate1'] = line['rate1'];
          line['rate7'] = line['rate7'];
        tableData.push(tableDataAll[i]);
      }
    },
    // 换页
    handleCurrentChange(val) {
      this.pageCurr = val;
      tableData.splice(0, tableData.length);
      var end = (tableDataAll.length > (this.pageCurr)*(this.pageSize)) ? (this.pageCurr)*(this.pageSize) : tableDataAll.length;
      for (var i = (this.pageCurr-1)*(this.pageSize); i < end; i++) {
        var line = tableDataAll[i];
        line['date'] = line['date'];
          line['type'] = line['type'];
          line['showtype'] = line['showtype'];
          line['pagenum'] = line['pagenum'];
          line['ev'] = line['ev'];
          line['euv'] = line['euv'];
          line['ev_avg'] = line['ev_avg'];
          line['pv'] = line['pv'];
          line['uv'] = line['uv'];
          line['pv_avg'] = line['pv_avg'];
          line['pv_rate'] = line['pv_rate'];
          line['share'] =line['share'];
          line['share_rate'] = line['share_rate'];
          line['store'] = line['store'];
          line['store_rate'] = line['store_rate'];
          line['comment'] = line['comment'] ;
          line['comment_avg'] = line['comment_avg'];
          line['duration'] = line['duration'];
          line['duration_avg'] =  line['duration_avg'];
          line['ev_rate'] = line['ev_rate'];
          line['rate1'] = line['rate1'];
          line['rate7'] = line['rate7'];
        tableData.push(tableDataAll[i]);
      }
    },
    tableRowClassName(row, index) {
      if (index%2 != 0) {
        return 'odd-row';
      } else if (index%2 == 0) {
        return 'even-row';
      }
      return '';
    },
    getDay: function (day) {
      var today = new Date();
      var target = today.getTime()+1000*60*60*24*day;
      today.setTime(target);
      var year = today.getFullYear();
      var month = today.getMonth();
      var date = today.getDate();
      month = this.addZero(month+1);
      date = this.addZero(date);
      return year.toString()+'-'+month.toString()+'-'+date.toString();
    },
    addZero: function (time) {
      if (time.toString().length == 1) {
        time = '0'+time;
      }
      return time;
    },
    getJSON: function () {
      this.isLoading = true;
      if ((this.startDate) && (this.endDate)) {
      } else {
        this.startDate = this.getDay(-31);
        this.endDate = this.getDay(0);
      }
      var map = new Map();
      var map1 = new Map();
      var url='http://10.80.128.150:58080/headline/headlineShowtype?startDate='+this.startDate+'&endDate='+this.endDate;
    //   var url = 'http://10.50.1.130:38080/channel/channel_channel540Data.action?startDate='+this.startDate+'&endDate='+this.endDate;
      this.$http.get(url).then((response) => {
          console.log(response)
        this.isLoading = false;
        tableDataAll.splice(0, tableDataAll.length);
        var obj = response.data;
        var temps = obj;
        for (var i in temps) {
          var temp = temps[i];
          var line = {};
          line['date'] = temp['date'];
          line['type'] = temp['type'];
          line['showtype'] = temp['showtype'];
          line['pagenum'] = temp['pagenum'];
          line['ev'] = temp['ev'];
          line['euv'] = temp['euv'];
          line['ev_avg'] = temp['ev_avg'].toFixed(3);
          line['pv'] = temp['pv'];
          line['uv'] = temp['uv'];
          line['pv_avg'] = temp['pv_avg'].toFixed(3);
          line['pv_rate'] = (temp['pv_rate']*100).toFixed(3)+'%';
          line['share'] = temp['share'];
          line['share_rate'] = (temp['share_rate']*100).toFixed(3)+'%';
          line['store'] = temp['store'];
          line['store_rate'] = (temp['store_rate']*100).toFixed(3)+'%';
          line['comment'] = temp['comment'];
          line['comment_avg'] = (temp['comment_avg']*100).toFixed(3)+'%';
          line['duration'] = temp['duration'];
          line['duration_avg'] = temp['duration_avg'].toFixed(3);
          line['ev_rate'] = (temp['ev_rate']*100).toFixed(3)+'%';
          line['rate1'] = (temp['rate1']*100).toFixed(3)+'%';
          line['rate7'] = (temp['rate7']*100).toFixed(3)+'%';
          tableDataAll.push(line);
          if (map.has(temp['type'])) {
          } else {
            map.set(temp['type'], 1);
          }
          if (map1.has(temp['showtype'])) {
          } else {
            map1.set(temp['showtype'], 1);
          }
        }
        save = [].concat(tableDataAll);
        this.options.splice(0, this.options.length);
        this.optionsType.splice(0, this.optionsType.length);
        for (var key of map.keys()) {
          var option = {
            value: key,
            label: key
          };
          this.options.push(option);
        }
        for (var key of map1.keys()) {
          var option = {
            value: key,
            label: key
          };
          this.optionsType.push(option);
        }
        console.log(this.optionsType)
        console.log(this.options)
        tableDataAllDate.splice(0, tableDataAllDate.length);
        tableDataAllPagenum.splice(0, tableDataAllPagenum.length);
      tableDataAllEv.splice(0, tableDataAllEv.length);
      tableDataAllEuv.splice(0, tableDataAllEuv.length);
      tableDataAllEv_avg.splice(0, tableDataAllEv_avg.length);
      tableDataAllPv.splice(0, tableDataAllPv.length);
      tableDataAllUv.splice(0, tableDataAllUv.length);
      tableDataAllPv_avg.splice(0, tableDataAllPv_avg.length);
      tableDataAllPv_rate.splice(0, tableDataAllPv_rate.length);
      tableDataAllShare.splice(0, tableDataAllShare.length);
      tableDataAllShare_rate.splice(0, tableDataAllShare_rate.length);
      tableDataAllStore.splice(0, tableDataAllStore.length);
      tableDataAllStore_rate.splice(0, tableDataAllStore_rate.length);
      tableDataAllComment.splice(0, tableDataAllComment.length);
      tableDataAllComment_avg.splice(0, tableDataAllComment_avg.length);
      tableDataAllDuration.splice(0, tableDataAllDuration.length);
      tableDataAllDuration_avg.splice(0, tableDataAllDuration_avg.length);
      tableDataAllEv_rate.splice(0, tableDataAllEv_rate.length);
      tableDataAllRate1.splice(0, tableDataAllRate1.length);
      tableDataAll7ate7.splice(0, tableDataAll7ate7.length)
        var count = 0;
        for (var i in save) {
          var line = save[i];
          if ((line['type'] == 'docpic')&&(line['showtype'] == 'pictxt')) {
            tableDataAll.push(line);
            count++;
            tableDataAllDate.unshift(line['date']);
          tableDataAllPagenum.unshift(line['pagenum']);
          tableDataAllEv.unshift(line['ev']);
          tableDataAllEuv.unshift(line['euv']);
          tableDataAllEv_avg.unshift(line['ev_avg']);
          tableDataAllPv.unshift(line['pv']);
          tableDataAllUv.unshift(line['uv']);
          tableDataAllPv_avg.unshift(line['pv_avg']);
          tableDataAllPv_rate.unshift(parseFloat(line['pv_rate']));
          tableDataAllShare.unshift(line['share']);
          tableDataAllShare_rate.unshift(parseFloat(line['share_rate']));
          tableDataAllStore.unshift(line['store']);
          tableDataAllStore_rate.unshift(parseFloat(line['store_rate']));
          tableDataAllComment.unshift(line['comment']);
          tableDataAllComment_avg.unshift(parseFloat(line['comment_avg']));
          tableDataAllDuration.unshift(line['duration']);
          tableDataAllDuration_avg.unshift(line['duration_avg']);
          tableDataAllEv_rate.unshift(parseFloat(line['ev_rate']));
          tableDataAllRate1.unshift(parseFloat(line['rate1']));
          tableDataAll7ate7.unshift(parseFloat(line['rate7']));
          }
        }
        tableDataAll.splice(0, tableDataAll.length-count);
        tableData.splice(0, tableData.length);
        if (tableDataAll.length < 5) {
          this.pageSize = tableDataAll.length;
        } else {
          this.pageSize = 10;
        }
        for (var i = 0; i < this.pageSize; i++) {
          var line = tableDataAll[i];
          line['date'] = line['date'];
          line['type'] = line['type'];
          line['showtype'] = line['showtype'];
          line['pagenum'] = line['pagenum'];
          line['ev'] = line['ev'];
          line['euv'] = line['euv'];
          line['ev_avg'] = line['ev_avg'];
          line['pv'] = line['pv'];
          line['uv'] = line['uv'];
          line['pv_avg'] = line['pv_avg'];
          line['pv_rate'] = line['pv_rate'];
          line['share'] =line['share'];
          line['share_rate'] = line['share_rate'];
          line['store'] = line['store'];
          line['store_rate'] = line['store_rate'];
          line['comment'] = line['comment'] ;
          line['comment_avg'] = line['comment_avg'];
          line['duration'] = line['duration'];
          line['duration_avg'] =  line['duration_avg'];
          line['ev_rate'] = line['ev_rate'];
          line['rate1'] = line['rate1'];
          line['rate7'] = line['rate7'];
          tableData.push(tableDataAll[i]);
        }
      })
    }
  },
  created: function () {
    this.getJSON();
  },
  beforeUpdate: function () {
    var option = {
      legend: {
        left: 'center',
        data: ['文章量', '文章曝光量EV', '曝光人数EVU', '人均曝光量', '阅读PV', '阅读UV', '人均阅读数', '转化率', '分享次数', '分享率', '收藏次数','收藏率', '评论次数', '评论率', '阅读时长', '人均浏览时长（分）', '曝光占比', '一日曝光留存','七日曝光留存' ],
        selectedMode: 'multiple',
        selected: {  
                    '文章量': false,  
                    '文章曝光量EV': false,  
                    '曝光人数EVU': true,  
                    '人均曝光量': false,  
                    '阅读PV': true,  
                    '阅读UV': false,  
                    '人均阅读数': false ,
                    '转化率': false,  
                    '分享次数': false,
                    '分享率': false,  
                    '收藏次数': false,  
                    '收藏率': false,  
                    '评论次数': false,  
                    '评论率': false,
                    '阅读时长': false,
                    '人均浏览时长（分）': false,
                    '曝光占比': false,
                    '一日曝光留存': false,
                    '七日曝光留存': false
                    
                }  
      },
      grid: {
        top:'20%',
        left: '2%',
        right: '4%',
        bottom: '3%',
        containLabel: true
    },
      tooltip: {
        trigger: 'axis',
        position: function (pt) {
          return [pt[0]-100, '10%'];
        }
      },
      toolbox: {
        right:'2%',
        top:'8%',
        show: true,
        feature : {
            mark : {show: true},
            dataZoom : {show: true},
            magicType: {type: ['line', 'bar']},
            restore : {show: true},
            saveAsImage : {show: true}
        }
    },
      xAxis: {
        type: 'category',
        boundaryGap: false,
        data: this.tableDataAllDate
      },
      yAxis: {
        type: 'value',
        boundaryGap: [0, '30%']
      },
      dataZoom: [
        {
          type: 'slider',
          show: true,
          xAxisIndex: [0],
          start: 0,
          end: 100
        },
        {
          type: 'inside',
          xAxisIndex: [0],
          start: 0,
          end: 100
        }
      ],
      series: [
        {
          name: '文章量',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.tableDataAllPagenum
        },
        {
          name: '文章曝光量EV',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.tableDataAllEv
        },
        {
          name: '曝光人数EVU',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.tableDataAllEuv
        },
        {
          name: '人均曝光量',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.tableDataAllEv_avg
        },
        {
          name: '阅读PV',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.tableDataAllPv
        },
        {
          name: '阅读UV',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.tableDataAllUv
        },
        {
          name: '人均阅读数',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.tableDataAllPv_avg
        },
        {
          name: '转化率',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.tableDataAllPv_rate
        },
        {
          name: '分享次数',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.tableDataAllShare
        },
        {
          name: '分享率',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.tableDataAllShare_rate
        },
        {
          name: '收藏次数',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.tableDataAllStore
        },
        {
          name: '收藏率',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.tableDataAllStore_rate
        },
        {
          name: '评论次数',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.tableDataAllComment
        },
        {
          name: '评论率',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.tableDataAllComment_avg
        },
        {
          name: '阅读时长',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.tableDataAllDuration
        },
        {
          name: '人均浏览时长（分）',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.tableDataAllDuration_avg
        },
         {
          name: '曝光占比',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.tableDataAllEv_rate
        },
         {
          name: '一日曝光留存',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.tableDataAllRate1
        },
         {
          name: '七日曝光留存',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.tableDataAll7ate7
        },
      ]
    };
    myChart = echarts.init(document.getElementById('channelArea'));
    myChart.setOption(option);
  },
  mounted () {
        window.onresize = function(){
          myChart.resize();
        }
   }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
/*h1, h2 {
  font-weight: normal;
}

ul {
  list-style-type: none;
  padding: 0;
}

li {
  display: inline-block;
  margin: 0 10px;
}

a {
  color: #42b983;
}*/
</style>
