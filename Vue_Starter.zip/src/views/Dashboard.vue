<template>
  <div class="animated fadeIn">
    <div class="row">
      

      <div class="col-sm-6 col-lg-3" style="margin-left: 25%">
        <div class="card card-inverse card-warning">
          <div class="card-block pb-0">
            <div class="btn-group float-right">
              <!-- <dropdown class="float-right" type="transparent p-0">
                <i slot="button" class="icon-settings"></i>
                <div slot="dropdown-menu" class="dropdown-menu dropdown-menu-right">
                  <a class="dropdown-item" href="#">Action</a>
                  <a class="dropdown-item" href="#">Another action</a>
                  <a class="dropdown-item" href="#">Something else here</a>
                </div>
              </dropdown> -->
            </div>
            <h4 class="mb-0">{{num3}}</h4>
            <p>信息流总点击</p>
          </div>
          <card-line3-chart-example class="chart-wrapper" style="height:70px;" height="70"/>
        </div>
      </div><!--/.col-->

      <div class="col-sm-6 col-lg-3">
        <div class="card card-inverse card-danger">
          <div class="card-block pb-0">
            <div class="btn-group float-right">
              <!-- <dropdown class="float-right" type="transparent p-0">
                <i slot="button" class="icon-settings"></i>
                <div slot="dropdown-menu" class="dropdown-menu dropdown-menu-right">
                  <a class="dropdown-item" href="#">Action</a>
                  <a class="dropdown-item" href="#">Another action</a>
                  <a class="dropdown-item" href="#">Something else here</a>
                </div>
              </dropdown> -->
            </div>
            <h4 class="mb-0">{{num4}}</h4>
            <p>信息流曝光</p>
          </div>
          <card-bar-chart-example class="chart-wrapper px-3" style="height:70px;" height="70"/>
        </div>
      </div><!--/.col-->
    </div><!--/.row-->
    <div class="card">
      <div class="card-block">
        <div class="row">
          <div class="col-sm-5">
            <h4 class="card-title">整体趋势曲线图</h4>
          </div><!--/.col-->
        </div><!--/.row-->
        <div id="wholeAreachart" style="width: 100%; height: 400px; text-align: -webkit-center;"></div>
      </div>
    </div><!--/.card-->
    <div class="row" style="margin-bottom:20px">
      <div id="wholeTable" style="width: 98%; margin: 0 auto">
      <el-row style="margin-bottom: -10px ">
        <el-col :span="16">
          <el-pagination :total="tableDataAll.length" :page-size="pageSize" :page-sizes="[5, 10, 15, 20]" :current-page="pageCurr"
          layout="total, sizes, prev, pager, next, jumper" @size-change="handleSizeChange" @current-change="handleCurrentChange"></el-pagination>
        </el-col>
        <el-col :span="2" :offset="1" style="margin-top: -4px">
          <el-button type="text" icon="upload2" @click="handleClick">导出</el-button>
        </el-col>
        <el-col :span="3" style="margin-top: -4px">
          <el-date-picker type="daterange" placeholder="选择日期范围" :clearable="false" v-model="input" @change="handleChange"></el-date-picker>
        </el-col>
      </el-row>
      <el-tooltip  effect="dark" placement="bottom" >
        <div  slot="content">
        	推荐原因字段解释：<br/>数据来源#推送原因#辅助说明<br/><br/>
          信息流人均点击：信息流点击次数/信息流点击人数<br/>
          点击率：信息流点击人数/信息流曝光次数；<br/>
          退出率：用户未阅读文章便退出客户端的比例<br/>
        </div>
      <i class="el-icon-warning" style="float: right;margin:7px 15px"></i>
      </el-tooltip>
        <el-table   v-loading="isLoading"   element-loading-text="拼命加载中"  stripe :data="tableData" :row-class-name="tableRowClassName" >
          <el-table-column align="center" v-for="item in columns" :prop="item.prop" :label="item.label" :min-width="item['min-width']" sortable>
          </el-table-column>
        </el-table>
    </div>
  </div>
    </div><!--/.row-->
  </div>
</template>

<script>
import echarts from 'echarts'
import CardLine1ChartExample from './dashboard/CardLine1ChartExample'
import CardLine2ChartExample from './dashboard/CardLine2ChartExample'
import CardLine3ChartExample from './dashboard/CardLine3ChartExample'
import CardBarChartExample from './dashboard/CardBarChartExample'
import MainChartExample from './dashboard/MainChartExample'
import SocialBoxChartExample from './dashboard/SocialBoxChartExample'

import { dropdown } from 'vue-strap'
import store from '@/vuex/store'

import { mapState,mapMutations } from 'vuex';

var input = '',
  num1,num2,num3,num4,
  startDate = '',
  endDate = '',
  pageSize = 10,
  pageCurr = 1,
  myChart,
  columns = [
    {
      prop: 'date',
      label: '日期',
      'min-width':'120px'
    },
    {
      prop: 'thirdparty',
      label: '第三方拉活人数',
      'min-width':'100px'
    },
    {
      prop: 'ev',
      label: '信息流曝光',
      'min-width':'120px'
    },
	 {
      prop: 'evAvg',
      label: '人均曝光',
      'min-width': '110px'
    },
    {
      prop: 'pv',
      label: '信息流点击',
      'min-width': '110px'
    },
    {
      prop: 'pvAvg',
      label: '信息流人均点击',
      'min-width': '120px'
    },
	{
      prop: 'vv',
      label: '视频vv',
      'min-width': '110px'
    },
	{
      prop: 'vvAvg',
      label: '人均vv',
      'min-width': '100px'
    },
    {
      prop: 'useTime',
      label: '使用时长',
      'min-width': '100px'
    },
    {
      prop: 'numStart',
      label: '启动次数',
      'min-width': '100px'
    },
    {
      prop: 'clickRate',
      label: '点击率',
      'min-width': '100px'
    },
    {
      prop: 'exitRate',
      label: '退出率',
      'min-width': '100px'
    },
    {
      prop: 'share',
      label: '分享次数',
      'min-width': '100px'
    }
  ],
  
  //column for excel
   excelColumns = [
    {
      prop: 'date',
      label: '日期',
      width: '140px'
    },
    {
      prop: 'thirdparty',
      label: '第三方拉活人数',
      width: '180px'
    },
    {
      prop: 'ev',
      label: '信息流曝光',
      width: '150px'
    },
    {
      prop: 'pv',
      label: '信息流点击',
      width: '150px'
    },
    {
      prop: 'pvAvg',
      label: '信息流人均点击',
      width: '180px'
    },
	{
      prop: 'vv',
      label: '视频vv',
      width: '180px'
    },
	{
      prop: 'vvAvg',
      label: '人均vv',
      width: '180px'
    },
    {
      prop: 'useTime',
      label: '使用时长',
      width: '140px'
    },
    {
      prop: 'numStart',
      label: '启动次数',
      width: '140px'
    },
    {
      prop: 'clickRate',
      label: '点击率',
      width: '140px'
    },
    {
      prop: 'exitRate',
      label: '退出率',
      width: '140px'
    },
    {
      prop: 'share',
      label: '分享次数',
      width: '140px'
    }
  ],
  tableData = [],
  tableDataAll = [],
  tableDataAllDate = [],
  tableDataAllNewUser = [],
  tableDataAllDau = [],
  tableDataAllThirdparty = [],
  tableDataAllEv = [],
  tableDataAllPv = [],
  tableDataAllPvAvg = [],
  tableDataAllUseTime = [],
  tableDataAllNumStart = [],
  tableDataAllClickRate = [],
  tableDataAllExitRate = [],
  tableDataAllShare = [],
  tableDataAllShareUv = [],
  tableDataAllVv = [],
  tableDataAllVvAvg = [],
  tableDataAllEvAvg = [];
export default {
  name: 'dashboard',
  data () {
    return {
      num1:num1,
      num2:num2,
      num3:num3,
      num4:num4,
      isLoading: false,
      input: input,
      startDate: startDate,
      endDate: endDate,
      pageSize: pageSize,
      pageCurr: pageCurr,
      columns: columns,
      tableData: tableData,
      tableDataAll: tableDataAll,
      tableDataAllDate: tableDataAllDate,
      tableDataAllNewUser: tableDataAllNewUser,
      tableDataAllDau: tableDataAllDau,
      tableDataAllThirdparty: tableDataAllThirdparty,
      tableDataAllEv: tableDataAllEv,
      tableDataAllPv: tableDataAllPv,
      tableDataAllPvAvg: tableDataAllPvAvg,
      tableDataAllUseTime: tableDataAllUseTime,
      tableDataAllNumStart: tableDataAllNumStart,
      tableDataAllClickRate: tableDataAllClickRate,
      tableDataAllExitRate: tableDataAllExitRate,
      tableDataAllShare: tableDataAllShare,
      tableDataAllShareUv: tableDataAllShareUv,
	  tableDataAllVv: tableDataAllVv,
	  tableDataAllVvAvg: tableDataAllVvAvg,
	  tableDataAllEvAvg: tableDataAllEvAvg
	  
    }
  },
  methods: {
    // 下载
    handleClick(ev) {
      var url = 'http://sdk.data.ifeng.com/macro/macro_exportDataToExcelV2.action?startDate='+this.startDate+'&endDate='+this.endDate+'&col='+encodeURI(JSON.stringify(excelColumns));
      
      window.open(url);
    },
    // 选择
    handleChange(val) {
      this.startDate = val.slice(0, 10);
      this.endDate = val.slice(13, 23);
      this.getJSON();
    },
    // 分页
    handleSizeChange(val) {
      this.pageSize = val;
      this.pageCurr = 1;
      tableData.splice(0, tableData.length);
      val=val<=tableDataAll.length?val:tableDataAll.length
      for (var i = 0; i < val; i++) {
        var line = tableDataAll[i];
        line['newUser'] = line['newUser'].toLocaleString();
        line['dau'] = line['dau'].toLocaleString();
        line['thirdparty'] = line['thirdparty'].toLocaleString();
        line['ev'] = line['ev'].toLocaleString();
        line['pv'] = line['pv'].toLocaleString();
        line['pvAvg'] = line['pvAvg'].toLocaleString();
        line['useTime'] = line['useTime'].toLocaleString();
        line['numStart'] = line['numStart'].toLocaleString();
        line['share'] = line['share'].toLocaleString();
        line['shareUv'] = line['shareUv'].toLocaleString();
		line['vv'] = line['vv'].toLocaleString();
		line['vvAvg'] = line['vvAvg'].toLocaleString();
		line['evAvg'] = line['evAvg'].toLocaleString();
        tableData.push(tableDataAll[i]);
      }
    },
    // 换页
    handleCurrentChange(val) {
      this.pageCurr = val;
      tableData.splice(0, tableData.length);
      var end = (tableDataAll.length > (this.pageCurr)*(this.pageSize)) ? (this.pageCurr)*(this.pageSize) : tableDataAll.length;
      for (var i = (this.pageCurr-1)*(this.pageSize); i < end; i++) {
        var line = tableDataAll[i];
        line['newUser'] = line['newUser'].toLocaleString();
        line['dau'] = line['dau'].toLocaleString();
        line['thirdparty'] = line['thirdparty'].toLocaleString();
        line['ev'] = line['ev'].toLocaleString();
        line['pv'] = line['pv'].toLocaleString();
        line['pvAvg'] = line['pvAvg'].toLocaleString();
        line['useTime'] = line['useTime'].toLocaleString();
        line['numStart'] = line['numStart'].toLocaleString();
        line['share'] = line['share'].toLocaleString();
        line['shareUv'] = line['shareUv'].toLocaleString();
		line['vv'] = line['vv'].toLocaleString();
		line['vvAvg'] = line['vvAvg'].toLocaleString();
		line['evAvg'] = line['evAvg'].toLocaleString();
        tableData.push(tableDataAll[i]);
      }
    },
    tableRowClassName(row, index) {
      if (index%2 != 0) {
        return 'odd-row';
      } else if (index%2 == 0) {
        return 'even-row';
      }
      return '';
    },
    getDay: function (day) {
      var today = new Date();
      var target = today.getTime()+1000*60*60*24*day;
      today.setTime(target);
      var year = today.getFullYear();
      var month = today.getMonth();
      var date = today.getDate();
      month = this.addZero(month+1);
      date = this.addZero(date);
      return year.toString()+'-'+month.toString()+'-'+date.toString();
    },
    addZero: function (time) {
      if (time.toString().length == 1) {
        time = '0'+time;
      }
      return time;
    },
    getNum:function(){
      var url = 'http://sdk.data.ifeng.com/macro/macro_macroData.action?startDate='+this.startDate+'&endDate='+this.endDate;
      this.$http.get(url).then((response) => {
         var jsonData=response.data.data;
                    this.num1=jsonData['0']['dau']
                    this.num2=jsonData['0']['newUser']
                    this.num3=jsonData['0']['pv']
                    this.num4=jsonData['0']['ev']
      })
    },
    getJSON: function () {
      this.isLoading = true;
      if ((this.startDate) && (this.endDate)) {
      } else {
        this.startDate = this.getDay(-31);
        this.endDate = this.getDay(0);
      }
      var url = 'http://sdk.data.ifeng.com/macro/macro_macroData.action?startDate='+this.startDate+'&endDate='+this.endDate;
      this.$http.get(url).then((response) => {
        this.isLoading = false;
        tableDataAll.splice(0, tableDataAll.length);
        tableDataAllDate.splice(0, tableDataAllDate.length);
        tableDataAllNewUser.splice(0, tableDataAllNewUser.length);
        tableDataAllDau.splice(0, tableDataAllDau.length);
        tableDataAllThirdparty.splice(0, tableDataAllThirdparty.length);
        tableDataAllEv.splice(0, tableDataAllEv.length);
        tableDataAllPv.splice(0, tableDataAllPv.length);
        tableDataAllPvAvg.splice(0, tableDataAllPvAvg.length);
        tableDataAllUseTime.splice(0, tableDataAllUseTime.length);
        tableDataAllNumStart.splice(0, tableDataAllNumStart.length);
        tableDataAllClickRate.splice(0, tableDataAllClickRate.length);
        tableDataAllExitRate.splice(0, tableDataAllExitRate.length);
        tableDataAllShare.splice(0, tableDataAllShare.length);
        tableDataAllShareUv.splice(0, tableDataAllShareUv.length);
		    tableDataAllVv.splice(0, tableDataAllVv.length);
		    tableDataAllVvAvg.splice(0, tableDataAllVvAvg.length);
		    tableDataAllEvAvg.splice(0, tableDataAllEvAvg.length);
        var obj = response.data;
        var temps = obj['data'];
        for (var i in temps) {
          var temp = temps[i];
          var line = {};
          line['date'] = temp['date'] ? temp['date']: 0;
          line['newUser'] = temp['newUser'] ? temp['newUser']: 0;
          line['dau'] = temp['dau'] ? temp['dau']: 0;
          line['thirdparty'] = temp['thirdparty'] ? parseInt(temp['thirdparty']): 0;
          line['ev'] = temp['ev'] ? temp['ev']: 0;
          line['pv'] = temp['pv'] ? temp['pv']: 0;
          line['pvAvg'] = temp['pvAvg'] ? parseFloat(temp['pvAvg']).toFixed(3): 0;
          line['useTime'] = temp['useTime'] ? parseFloat(temp['useTime']).toFixed(3): 0;
          line['numStart'] = temp['numStart'] ? parseFloat(temp['numStart']).toFixed(3): 0;
          line['clickRate'] = temp['clickRate'] ? parseFloat(temp['clickRate']*100).toFixed(3)+'%': 0;
          line['exitRate'] = temp['exitRate'] ? parseFloat(temp['exitRate']*100).toFixed(3)+'%': 0;
          line['share'] = temp['share'] ? temp['share']: 0;
          line['shareUv'] = temp['shareUv'] ? temp['shareUv']: 0;
		  line['vv'] = temp['vv'] ? temp['vv']: 0;
		  line['vvAvg'] = temp['vvAvg'] ? parseFloat(temp['vvAvg']).toFixed(3): 0;
		  line['evAvg'] = temp['ev'] ? parseFloat(temp['ev']/temp['dau']).toFixed(3) : 0;
          tableDataAll.push(line);
          tableDataAllDate.unshift(line['date']);
          tableDataAllNewUser.unshift(line['newUser']);
          tableDataAllDau.unshift(line['dau']);
          tableDataAllThirdparty.unshift(line['thirdparty']);
          tableDataAllEv.unshift(line['ev']);
          tableDataAllPv.unshift(line['pv']);
          tableDataAllPvAvg.unshift(line['pvAvg']);
          tableDataAllUseTime.unshift(line['useTime']);
          tableDataAllNumStart.unshift(line['numStart']);
          tableDataAllClickRate.unshift(parseFloat(line['clickRate']));
          tableDataAllExitRate.unshift(parseFloat(line['exitRate']));
          tableDataAllShare.unshift(line['share']);
          tableDataAllShareUv.unshift(line['shareUv']);
		  tableDataAllVv.unshift(line['vv']);
		  tableDataAllVvAvg.unshift(line['vvAvg']);
		  tableDataAllEvAvg.unshift(line['evAvg']);
        }
        tableData.splice(0, tableData.length);
        if (tableDataAll.length < 5) {
          this.pageSize = tableDataAll.length;
        } else {
          this.pageSize = 10;
        }
        for (var i = 0; i < this.pageSize; i++) {
          var line = tableDataAll[i];
          line['newUser'] = line['newUser'].toLocaleString();
          line['dau'] = line['dau'].toLocaleString();
          line['thirdparty'] = line['thirdparty'].toLocaleString();
          line['ev'] = line['ev'].toLocaleString();
          line['pv'] = line['pv'].toLocaleString();
          line['pvAvg'] = line['pvAvg'].toLocaleString();
          line['useTime'] = line['useTime'].toLocaleString();
          line['numStart'] = line['numStart'].toLocaleString();
          line['share'] = line['share'].toLocaleString();
          line['shareUv'] = line['shareUv'].toLocaleString();
    		  line['vv'] = line['vv'].toLocaleString();
    		  line['vvAvg'] = line['vvAvg'].toLocaleString();
    		  line['evAvg'] = line['evAvg'].toLocaleString();
          tableData.push(tableDataAll[i]);
        }
      })
    }
  },
  created: function (tableDataAll) {
    this.getJSON();
    this.getNum()
  },
  beforeUpdate: function () {
    var option = {
      legend: {
        left: 'center',
        data: ['第三方拉活数', '信息流曝光', '人均曝光', '信息流点击', '信息流人均点击', '视频vv', '人均vv', '使用时长', '启动次数', '点击率', '退出率', '分享次数', '分享人数'],
        selectedMode: 'multiple',
        selected: {  
                    '第三方拉活数': false,  
                    '信息流曝光': false,  
                    '室外湿度': false,  
                    '人均曝光': false,  
                    '信息流点击': false,  
                    '信息流人均点击': false,  
                    '视频vv': false ,
                    '人均vv': false,  
                    '使用时长': false,  
                    '启动次数': false,  
                    '点击率': false,  
                    '退出率': false ,
                    '分享次数': true,  
                    '分享人数': true  
                }  
      },
      tooltip: {
        trigger: 'axis',
        position: function (pt) {
          return [pt[0]-100, '10%'];
        }
      },
      toolbox: {
        right:'2%',
        top:'8%',
        show: true,
        feature : {
            mark : {show: true},
            dataZoom : {show: true},
            magicType: {type: ['line', 'bar']},
            restore : {show: true},
            saveAsImage : {show: true}
        }
    },
      grid: {
        top:'20%',
        left: '2%',
        right: '3%',
        bottom: '3%',
        containLabel: true
    },
      xAxis: {
        type: 'category',
        boundaryGap: false,
        data: this.tableDataAllDate
      },
      yAxis: {
        type: 'value',
        boundaryGap: [0, '30%']
      },
      dataZoom: [
        {
          type: 'slider',
          show: true,
          xAxisIndex: [0],
          start: 0,
          end: 100
        },
        {
          type: 'inside',
          xAxisIndex: [0],
          start: 0,
          end: 100
        }
      ],
      series: [
        {
          name: '第三方拉活数',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.tableDataAllThirdparty
        },
        {
          name: '信息流曝光',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.tableDataAllEv
        },
		{
          name: '人均曝光',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.tableDataAllEvAvg
        },
        {
          name: '信息流点击',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.tableDataAllPv
        },
        {
          name: '信息流人均点击',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.tableDataAllPvAvg
        },
		{
          name: '视频vv',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.tableDataAllVv
        },
		{
          name: '人均vv',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.tableDataAllVvAvg
        },
        {
          name: '使用时长',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.tableDataAllUseTime
        },
        {
          name: '启动次数',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.tableDataAllNumStart
        },
        {
          name: '点击率',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.tableDataAllClickRate
        },
        {
          name: '退出率',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.tableDataAllExitRate
        },
        {
          name: '分享次数',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.tableDataAllShare
        },
        {
          name: '分享人数',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.tableDataAllShareUv
        }
      ]
    };
     myChart = echarts.init(document.getElementById('wholeAreachart'));
     myChart.setOption(option);

  },

  components: {
    CardLine1ChartExample,
    CardLine2ChartExample,
    CardLine3ChartExample,
    CardBarChartExample,
    MainChartExample,
    SocialBoxChartExample,
    dropdown
  },
  mounted () {
        window.onresize = function(){
          myChart.resize();
        }
        }
}
</script>
<style type="text/css">
	#wholeTable {
		margin-bottom: 10px;
	}
	#wholeTable  ::-webkit-scrollbar{width:4px;}
	#wholeTable  ::-webkit-scrollbar-track{background-color:#bee1eb;}
	#wholeTable ::-webkit-scrollbar-thumb{background-color:#00aff0;}
	#wholeTable ::-webkit-scrollbar-thumb:hover {background-color:#9c3}
	#wholeTable ::-webkit-scrollbar-thumb:active {background-color:#00aff0}
</style>
