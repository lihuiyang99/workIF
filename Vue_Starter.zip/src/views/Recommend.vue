<template>
  <!-- 用户推荐历史页面 -->
  <div class="animated fadeIn">
    
    <div class="row" style="margin-bottom:20px">
      <div id="wholeTable" style="width: 98%; margin: 0 auto">
      <el-row style="margin-bottom: 10px ">
         <el-col :span="2">
          <el-button type="primary" icon="search" :loading="isLoading" @click="handleClick">搜索</el-button>
        </el-col> 
        <el-col :span="18" :offset="1">
          <el-autocomplete placeholder="请输入userkey，点击右侧删除按钮清空搜索历史" style="width: 100%" v-model="input"
          :fetch-suggestions="querySearch" icon="circle-cross" :on-icon-click="handleIconClick"></el-autocomplete>
        </el-col>
      </el-row>
      <el-tooltip  effect="dark" placement="bottom" >
        <div class="tooltipMsg" slot="content">推荐原因字段解释：<br/>数据来源#推送原因#辅助说明<br/><br/>
              数据来源：<br/> 
          editor => 编辑 <br/> 
          perfectOld => 热闻榜 <br/> 
          perfectNew => 长效 <br/> 
          slide => 图集 <br/> 
          video => 视频 <br/> <br/>
              推荐原因：<br/>editor => 编辑<br/>corec => 正反馈 <br/>recommend => 内容匹配 <br/>explore => 分类试探 <br/>supply => 补充 <br/>view => 大图 <br/>video => 视频 <br/>cold => 冷启动 <br/>hot => 热点 <br/>local => 本地<br/>insert => 强插<br/><br/>
              perfectNewDeepChel  垂直分类长效数据<br/>
          nillDeepChel    垂直分类时效数据<br/>
          perfectNewContentMatch   相关推荐长效数据<br/>
          nillContentMatch  相关推荐时效数据<br/>
          nillPreferSource 优质稿源时效数据<br/>
          perfectNewPreferSource 优质稿源长效数据<br/>
          nillCF 协同时效数据<br/>
          perfectNewCF 协同长效数据<br/>
          文章类型（docpic/slide/video/etc）
        </div>
      <i class="el-icon-warning" style="float: right;margin:7px 15px"></i>
      </el-tooltip>
      <el-pagination :total="tableDataAll.length" :page-size="pageSize" :page-sizes="[5, 10, 20, 50, 100, 500]" :current-page="pageCurr"
      layout="total, sizes, prev, pager, next, jumper" @size-change="handleSizeChange" @current-change="handleCurrentChange"></el-pagination>
      
    <el-table  v-loading="isLoading"   element-loading-text="拼命加载中" :data="tableData" :row-class-name="tableRowClassName">
        <el-table-column align="center" prop="time" label="时间" min-width="150px" sortable></el-table-column>
        <el-table-column align="center" prop="engine" label="引擎" min-width="140px" sortable></el-table-column>
        <el-table-column align="center" prop="id" label="推荐ID" min-width="150px" sortable>
          <template scope="scope">
            <el-button type="text" style="user-select: initial;" icon="document" size="mini" @click="handleButtonClick">{{scope.row.id}}</el-button>
          </template>
        </el-table-column>
        <el-table-column align="center" prop="staticId" label="新闻ID" min-width="150px" sortable>
          <template scope="scope">
            <el-button type="text" style="user-select: initial;" icon="document" size="mini" @click="handleButtonClick">{{scope.row.staticId}}</el-button>
          </template>
        </el-table-column>
        <el-table-column align="center" prop="title" label="标题" min-width="210px" sortable></el-table-column>
        <el-table-column align="center" prop="itemtype" label="文章类型" min-width="150px" sortable></el-table-column>
        <el-table-column align="center" prop="why" label="推荐原因" min-width="220px" sortable></el-table-column>
        <el-table-column align="center" prop="readableFeatures" label="特征词" min-width="260px" sortable></el-table-column>
         <el-table-column align="center" prop="optype" label="操作类型" min-width="200px" sortable></el-table-column>
         <el-table-column align="center" prop="maxitems" label="召回数" min-width="200px" sortable></el-table-column>
        <el-table-column align="center" prop="date" label="日期" min-width="200px" sortable></el-table-column>
        <el-table-column align="center" prop="docChannel" label="频道" min-width="110px" sortable></el-table-column>
        <el-table-column align="center" prop="score" label="相似度得分" min-width="150px" sortable></el-table-column>
        <el-table-column align="center" prop="hotBoost" label="热度得分" min-width="140px" sortable></el-table-column>
        <el-table-column align="center" prop="simId" label="simId" min-width="210px" sortable></el-table-column>
        <el-table-column align="center" prop="rToken" label="rToken" min-width="200px" sortable></el-table-column>
        <el-table-column align="center" prop="resin" label="resin" min-width="120px" sortable></el-table-column>
        <el-table-column align="center" prop="iphost" label="iphost" min-width="110px" sortable></el-table-column>
      </el-table>
    </div>
    </div>
  </div><!--/.row-->
 
</template>

<script>
var input = '',
  history = [],
  pageSize = 10,
  pageCurr = 1,
  tableData = [],
  tableDataAll = [];
export default {
  data () {
    return {
      isLoading: false,
      input: input,
      history: history,
      pageSize: pageSize,
      pageCurr: pageCurr,
      tableData: tableData,
      tableDataAll: tableDataAll
    }
  },
  methods: {
    open() {
        this.$message({
          message:'没有搜到相关数据',
          duration:2000,
          customClass:'messagetop'
      });
      },
    // 清除
    handleIconClick(ev) {
      this.history.splice(0, this.history.length);
      localStorage.setItem('imageHistory', '');
    },
    // 搜索
    handleClick(ev) {
      var res = localStorage.getItem('imageHistory');
      if (res) {
        if (res.indexOf(this.input) == -1) {
          localStorage.setItem('imageHistory', res+' '+this.input);
        } else {
          var start = res.indexOf(this.input);
          var end = start+this.input.length;
          if (start != 0) {
            start = start-1;
          }
          res = res.slice(0, start)+res.slice(end);
          var arr = res.split(' ');
          this.history.splice(0, this.history.length);
          for (var i in arr) {
            this.history.unshift({"value": arr[i]});
          }
          localStorage.setItem('imageHistory', res+' '+this.input);
        }
      } else {
        localStorage.setItem('imageHistory', this.input);
      }
      this.history.unshift({"value": this.input});
      this.getJSON();
      
    },
    // 历史
    querySearch(queryString, cb) {
      if (this.history.length == 0) {
        var res = localStorage.getItem('imageHistory');
        if (res) {
          var arr = res.split(' ');
          for (var i in arr) {
            this.history.unshift({"value": arr[i]});
          }
        }
      }
      cb(this.history);
    },
    // 分页
    handleSizeChange(val) {
      this.pageSize = val;
      this.pageCurr = 1;
      tableData.splice(0, tableData.length);
      for (var i = 0; i < val; i++) {
        tableData.push(tableDataAll[i]);
      }
    },
    // 换页
    handleCurrentChange(val) {
      this.pageCurr = val;
      tableData.splice(0, tableData.length);
      var end = (tableDataAll.length > (this.pageCurr)*(this.pageSize)) ? (this.pageCurr)*(this.pageSize) : tableDataAll.length;
      for (var i = (this.pageCurr-1)*(this.pageSize); i < end; i++) {
        tableData.push(tableDataAll[i]);
      }
    },
    tableRowClassName(row, index) {
      if (index%2 != 0) {
        return 'odd-row';
      } else if (index%2 == 0) {
        return 'even-row';
      }
      return '';
    },
    // 跳转
    handleButtonClick(ev) {
      if (ev.target.innerText.indexOf('cmpp') != -1) {
        var url = 'http://share.iclient.ifeng.com/sharenews.f?aid='+ev.target.innerText;
        window.open(url)
      }else if(ev.target.innerText.indexOf('imcp_crc') != -1){
        var url = 'http://share.iclient.ifeng.com/sharenews.f?guid='+ev.target.innerText;
        window.open(url)
      }else if(ev.target.innerText.indexOf('imcp') != -1){
        var url = 'http://share.iclient.ifeng.com/sharenews.f?aid='+ev.target.innerText;
        window.open(url)
      }else if(ev.target.innerText.indexOf('video') != -1){
        var url = 'http://share.iclient.ifeng.com/sharenews.f?guid='+ev.target.innerText.substring(6);
        window.open(url)

      }else if(ev.target.innerText.indexOf('sub') != -1){
        var url = 'http://share.iclient.ifeng.com/vampire/sharenews.f?fromType=vampire&aid='+ev.target.innerText.substring(4);
        window.open(url)

      } else {
        /*var newWin = window.open();*/
        var urlT = 'http://local.api.iclient.ifeng.com/getAbNewslist?type=news&onlyId=1&id='+ev.target.innerText;

        $.ajax( {  
                      url:urlT,// 跳转到 action  
                     type:'get',  
                     jsonpCallback:"success_jsonpCallback",
                     dataType:'jsonp', 
                     jsonp: "callbackparam", 
                     success:function(response) { 
                     console.log(response) 
                      },  
                      error : function() {  
                           // view("异常！");  
                          alert("异常！");  
                      }  
                 });

        
      }
    },
    getDay: function (target) {
      var today = new Date();
      today.setTime(target);
      var year = today.getFullYear();
      var month = today.getMonth();
      var date = today.getDate();
      month = this.addZero(month+1);
      date = this.addZero(date);
      return year.toString()+'-'+month.toString()+'-'+date.toString();
    },
    getDaytime: function (target) {
      var today = new Date();
      today.setTime(target);
      var hour = today.getHours();
      var minute = today.getMinutes();
      var second = today.getSeconds();
      hour = this.addZero(hour);
      minute = this.addZero(minute);
      second = this.addZero(second);
      return hour.toString()+':'+minute.toString()+':'+second.toString();
    },
    addZero: function (time) {
      if (time.toString().length == 1) {
        time = '0'+time;
      }
      return time;
    },
    getJSON: function () {
      this.isLoading = true;
      var url = 'http://10.80.128.150:58080/rec_history?userkey='+this.input;
      this.$http.get(url).then((response) => {
        this.isLoading = false;
        console.log(response)
        tableDataAll.splice(0, tableDataAll.length);
         if(response.data!=''){
          var temps = response.data;
          for (var i in temps) {
          var temp = temps[i];
          var line = {};
          line['staticId'] = temp['staticId'];
          line['time'] = temp['time'];
          line['resin'] = temp['resin'];
          line['engine'] = temp['engine'];
          line['id'] = temp['id'];
          line['title'] = temp['title'];
          var formatDate = temp['date'];
          if (formatDate) {
            var first = temp['date'].slice(0, 10);
            var second = temp['date'].slice(10, 29);
            second = second.slice(0, 16)+second.slice(17);
            var third = temp['date'].slice(29);
            formatDate = first+third+second;
          } else {
            continue;
          }
          line['date'] = this.getDay(Date.parse(formatDate))+' '+this.getDaytime(Date.parse(formatDate));
          line['hot_level'] = temp['hot_level'];
          line['optype'] = temp['optype'];
          line['maxitems'] = temp['maxitems'];
          line['itemtype'] = temp['itemtype'];
          line['docChannel'] = temp['docChannel'];
          line['why'] = temp['why'];
          line['score'] = temp['score'];
          line['hotBoost'] = temp['hotBoost'];
          line['readableFeatures'] = temp['readableFeatures'];
          line['simId'] = temp['simId'];
          line['rToken'] = temp['rToken'];
          line['iphost'] = temp['iphost'];
          tableDataAll.push(line);
        }
        console.log(tableDataAll)
        tableData.splice(0, tableData.length);
        for (var i = 0; i < this.pageSize; i++) {
          tableData.push(tableDataAll[i]);
        }
         }else{
          tableDataAll.length=0;
          tableData.length=0;
          /*alert('没有搜到相关数据')*/
          this.open()
         }
        
      })
      
    }
  },
  mounted: function () {
    var _this = this;
    document.getElementsByTagName('input')[0].onkeydown = function (e) {
      if (e.keyCode == 13) {
        _this.handleClick();
      }
    };
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style>
span{
  -webkit-user-select: initial;
  user-select: initial;
}
.messagetop{
  top: 30%!important;
}
</style>
