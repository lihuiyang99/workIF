<template>
  <!-- 视频数据页面 -->
  <div class="animated fadeIn">
    <div class="card">
      <div class="card-block">
        <div class="row">
          <div class="col-sm-9">
            <h4 class="card-title">视频数据曲线图</h4>
            <div class="small text-muted"></div>
          </div><!--/.col-->
           <div class="col-sm-3">
              <div style="margin-left: 3%">
              <el-date-picker type="daterange" placeholder="选择日期范围" :clearable="false" v-model="input" @change="handleChange"></el-date-picker>
            </div>
          </div><!--/.col-->
        </div><!--/.row-->
        
    <div id="videoAreaUp" style="width: 100%; height: 380px; margin: 10px auto;text-align: -webkit-center;" :trigger="isTrigger"></div>
      </div>
    </div><!--/.card-->
    <div class="card" style="margin-bottom:20px">
        <div class="card-block">
        <div class="row">
          <div class="col-sm-5">
            <h4 class="card-title mb-0">视频数据饼形图分析</h4>
          </div><!--/.col-->
        </div><!--/.row-->
        <div id="videoAreaDown" style="width: 100%; height: 380px; margin: 0 auto"></div>
      </div>
    </div>
  </div>
    </div><!--/.row-->
  </div>
</template>

<script>
import echarts from 'echarts'
var input = '',
  downChart,
  upChart,
  startDate = '',
  endDate = '',
  isTrigger = false,
  upDate = [],
  upEntVuv = [],
  upEntVv = [],
  upIfengtvFirstVuv = [],
  upIfengtvFirstVv = [],
  upMilVuv = [],
  upMilVv = [],
  upOutsideVuv = [],
  upOutsideVv = [],
  upPhtvVuv = [],
  upPhtvVv = [],
  upRcmdVuv = [],
  upRcmdVv = [],
  upRelationArticleVuv = [],
  upRelationArticleVv = [],
  upRelationVideoVuv = [],
  upRelationVideoVv = [],
  upSpVuv = [],
  upSpVv = [],
  upSyAiVuv = [],
  upSyAiVv = [],
  upSyEditorVuv = [],
  upSyEditorVv = [],
  upVideoArticleVuv = [],
  upVideoArticleVv = [],
  downEntVuv = [],
  downEntVv = [],
  downIfengtvFirstVuv = [],
  downIfengtvFirstVv = [],
  downMilVuv = [],
  downMilVv = [],
  downOutsideVuv = [],
  downOutsideVv = [],
  downPhtvVuv = [],
  downPhtvVv = [],
  downRcmdVuv = [],
  downRcmdVv = [],
  downRelationArticleVuv = [],
  downRelationArticleVv = [],
  downRelationVideoVuv = [],
  downRelationVideoVv = [],
  downSpVuv = [],
  downSpVv = [],
  downSyAiVuv = [],
  downSyAiVv = [],
  downSyEditorVuv = [],
  downSyEditorVv = [],
  downVideoArticleVuv = [],
  downVideoArticleVv = [];
export default {
  data () {
    return {
      input: input,
      startDate: startDate,
      endDate: endDate,
      isTrigger: isTrigger,
      upDate: upDate,
      upEntVuv: upEntVuv,
      upEntVv: upEntVv,
      upIfengtvFirstVuv: upIfengtvFirstVuv,
      upIfengtvFirstVv: upIfengtvFirstVv,
      upMilVuv: upMilVuv,
      upMilVv: upMilVv,
      upOutsideVuv: upOutsideVuv,
      upOutsideVv: upOutsideVv,
      upPhtvVuv: upPhtvVuv,
      upPhtvVv: upPhtvVv,
      upRcmdVuv: upRcmdVuv,
      upRcmdVv: upRcmdVv,
      upRelationArticleVuv: upRelationArticleVuv,
      upRelationArticleVv: upRelationArticleVv,
      upRelationVideoVuv: upRelationVideoVuv,
      upRelationVideoVv: upRelationVideoVv,
      upSpVuv: upSpVuv,
      upSpVv: upSpVv,
      upSyAiVuv: upSyAiVuv,
      upSyAiVv: upSyAiVv,
      upSyEditorVuv: upSyEditorVuv,
      upSyEditorVv: upSyEditorVv,
      upVideoArticleVuv: upVideoArticleVuv,
      upVideoArticleVv: upVideoArticleVv,
      downEntVuv: downEntVuv,
      downEntVv: downEntVv,
      downIfengtvFirstVuv: downIfengtvFirstVuv,
      downIfengtvFirstVv: downIfengtvFirstVv,
      downMilVuv: downMilVuv,
      downMilVv: downMilVv,
      downOutsideVuv: downOutsideVuv,
      downOutsideVv: downOutsideVv,
      downPhtvVuv: downPhtvVuv,
      downPhtvVv: downPhtvVv,
      downRcmdVuv: downRcmdVuv,
      downRcmdVv: downRcmdVv,
      downRelationArticleVuv: downRelationArticleVuv,
      downRelationArticleVv: downRelationArticleVv,
      downRelationVideoVuv: downRelationVideoVuv,
      downRelationVideoVv: downRelationVideoVv,
      downSpVuv: downSpVuv,
      downSpVv: downSpVv,
      downSyAiVuv: downSyAiVuv,
      downSyAiVv: downSyAiVv,
      downSyEditorVuv: downSyEditorVuv,
      downSyEditorVv: downSyEditorVv,
      downVideoArticleVuv: downVideoArticleVuv,
      downVideoArticleVv: downVideoArticleVv
    }
  },
  methods: {
    // 选择
    handleChange(val) {
      this.startDate = val.slice(0, 10);
      this.endDate = val.slice(13, 23);
      this.getJSONUp();
    },
    getDay: function (day) {
      var today = new Date();
      var target = today.getTime()+1000*60*60*24*day;
      today.setTime(target);
      var year = today.getFullYear();
      var month = today.getMonth();
      var date = today.getDate();
      month = this.addZero(month+1);
      date = this.addZero(date);
      return year.toString()+'-'+month.toString()+'-'+date.toString();
    },
    addZero: function (time) {
      if (time.toString().length == 1) {
        time = '0'+time;
      }
      return time;
    },
    getJSONUp: function () {
      if ((this.startDate) && (this.endDate)) {
      } else {
        this.startDate = this.getDay(-31);
        this.endDate = this.getDay(0);
      }
      var url = 'http://sdk.data.ifeng.com/video/video_videoData.action?startDate='+this.startDate+'&endDate='+this.endDate;
      this.$http.get(url).then((response) => {
        upDate.splice(0, upDate.length);
        upEntVuv.splice(0, upEntVuv.length);
        upEntVv.splice(0, upEntVv.length);
        upIfengtvFirstVuv.splice(0, upIfengtvFirstVuv.length);
        upIfengtvFirstVv.splice(0, upIfengtvFirstVv.length);
        upMilVuv.splice(0, upMilVuv.length);
        upMilVv.splice(0, upMilVv.length);
        upOutsideVuv.splice(0, upOutsideVuv.length);
        upOutsideVv.splice(0, upOutsideVv.length);
        upPhtvVuv.splice(0, upPhtvVuv.length);
        upPhtvVv.splice(0, upPhtvVv.length);
        upRcmdVuv.splice(0, upRcmdVuv.length);
        upRcmdVv.splice(0, upRcmdVv.length);
        upRelationArticleVuv.splice(0, upRelationArticleVuv.length);
        upRelationArticleVv.splice(0, upRelationArticleVv.length);
        upRelationVideoVuv.splice(0, upRelationVideoVuv.length);
        upRelationVideoVv.splice(0, upRelationVideoVv.length);
        upSpVuv.splice(0, upSpVuv.length);
        upSpVv.splice(0, upSpVv.length);
        upSyAiVuv.splice(0, upSyAiVuv.length);
        upSyAiVv.splice(0, upSyAiVv.length);
        upSyEditorVuv.splice(0, upSyEditorVuv.length);
        upSyEditorVv.splice(0, upSyEditorVv.length);
        upVideoArticleVuv.splice(0, upVideoArticleVuv.length);
        upVideoArticleVv.splice(0, upVideoArticleVv.length);
        var obj = response.data;
        var temps = obj['data'];
        for (var i in temps) {
          var temp = temps[i];
          var line = {};
          line['date'] = temp['date'] ? temp['date']: 0;
          line['ent_vuv'] = temp['ent_vuv'] ? temp['ent_vuv']: 0;
          line['ent_vv'] = temp['ent_vv'] ? temp['ent_vv']: 0;
          line['ifengtv_first_vuv'] = temp['ifengtv_first_vuv'] ? temp['ifengtv_first_vuv']: 0;
          line['ifengtv_first_vv'] = temp['ifengtv_first_vv'] ? temp['ifengtv_first_vv']: 0;
          line['mil_vuv'] = temp['mil_vuv'] ? temp['mil_vuv']: 0;
          line['mil_vv'] = temp['mil_vv'] ? temp['mil_vv']: 0;
          line['outside_vuv'] = temp['outside_vuv'] ? temp['outside_vuv']: 0;
          line['outside_vv'] = temp['outside_vv'] ? temp['outside_vv']: 0;
          line['phtv_vuv'] = temp['phtv_vuv'] ? temp['phtv_vuv']: 0;
          line['phtv_vv'] = temp['phtv_vv'] ? temp['phtv_vv']: 0;
          line['rcmd_vuv'] = temp['rcmd_vuv'] ? temp['rcmd_vuv']: 0;
          line['rcmd_vv'] = temp['rcmd_vv'] ? temp['rcmd_vv']: 0;
          line['relation_article_vuv'] = temp['relation_article_vuv'] ? temp['relation_article_vuv']: 0;
          line['relation_article_vv'] = temp['relation_article_vv'] ? temp['relation_article_vv']: 0;
          line['relation_video_vuv'] = temp['relation_video_vuv'] ? temp['relation_video_vuv']: 0;
          line['relation_video_vv'] = temp['relation_video_vv'] ? temp['relation_video_vv']: 0;
          line['sp_vuv'] = temp['sp_vuv'] ? temp['sp_vuv']: 0;
          line['sp_vv'] = temp['sp_vv'] ? temp['sp_vv']: 0;
          line['sy_ai_vuv'] = temp['sy_ai_vuv'] ? temp['sy_ai_vuv']: 0;
          line['sy_ai_vv'] = temp['sy_ai_vv'] ? temp['sy_ai_vv']: 0;
          line['sy_editor_vuv'] = temp['sy_editor_vuv'] ? temp['sy_editor_vuv']: 0;
          line['sy_editor_vv'] = temp['sy_editor_vv'] ? temp['sy_editor_vv']: 0;
          line['video_article_vuv'] = temp['video_article_vuv'] ? temp['video_article_vuv']: 0;
          line['video_article_vv'] = temp['video_article_vv'] ? temp['video_article_vv']: 0;
          upDate.unshift(line['date']);
          upEntVuv.unshift(line['ent_vuv']);
          upEntVv.unshift(line['ent_vv']);
          upIfengtvFirstVuv.unshift(line['ifengtv_first_vuv']);
          upIfengtvFirstVv.unshift(line['ifengtv_first_vv']);
          upMilVuv.unshift(line['mil_vuv']);
          upMilVv.unshift(line['mil_vv']);
          upOutsideVuv.unshift(line['outside_vuv']);
          upOutsideVv.unshift(line['outside_vv']);
          upPhtvVuv.unshift(line['phtv_vuv']);
          upPhtvVv.unshift(line['phtv_vv']);
          upRcmdVuv.unshift(line['rcmd_vuv']);
          upRcmdVv.unshift(line['rcmd_vv']);
          upRelationArticleVuv.unshift(line['relation_article_vuv']);
          upRelationArticleVv.unshift(line['relation_article_vv']);
          upRelationVideoVuv.unshift(line['relation_video_vuv']);
          upRelationVideoVv.unshift(line['relation_video_vv']);
          upSpVuv.unshift(line['sp_vuv']);
          upSpVv.unshift(line['sp_vv']);
          upSyAiVuv.unshift(line['sy_ai_vuv']);
          upSyAiVv.unshift(line['sy_ai_vv']);
          upSyEditorVuv.unshift(line['sy_editor_vuv']);
          upSyEditorVv.unshift(line['sy_editor_vv']);
          upVideoArticleVuv.unshift(line['video_article_vuv']);
          upVideoArticleVv.unshift(line['video_article_vv']);
        }
      })
    },
    getJSONDown: function () {
      var url = 'http://sdk.data.ifeng.com/video/video_videoVv.action?type=vuv';
      this.$http.get(url).then((response) => {
        downEntVuv.splice(0, downEntVuv.length);
        downIfengtvFirstVuv.splice(0, downIfengtvFirstVuv.length);
        downMilVuv.splice(0, downMilVuv.length);
        downOutsideVuv.splice(0, downOutsideVuv.length);
        downPhtvVuv.splice(0, downPhtvVuv.length);
        downRcmdVuv.splice(0, downRcmdVuv.length);
        downRelationArticleVuv.splice(0, downRelationArticleVuv.length);
        downRelationVideoVuv.splice(0, downRelationVideoVuv.length);
        downSpVuv.splice(0, downSpVuv.length);
        downSyAiVuv.splice(0, downSyAiVuv.length);
        downSyEditorVuv.splice(0, downSyEditorVuv.length);
        downVideoArticleVuv.splice(0, downVideoArticleVuv.length);
        var obj = response.data;
        var temps = obj['data'];
        for (var i in temps) {
          var temp = temps[i];
          var line = {};
          line['ent_vuv'] = temp['ent_vuv'] ? temp['ent_vuv']: 0;
          line['ifengtv_first_vuv'] = temp['ifengtv_first_vuv'] ? temp['ifengtv_first_vuv']: 0;
          line['mil_vuv'] = temp['mil_vuv'] ? temp['mil_vuv']: 0;
          line['outside_vuv'] = temp['outside_vuv'] ? temp['outside_vuv']: 0;
          line['phtv_vuv'] = temp['phtv_vuv'] ? temp['phtv_vuv']: 0;
          line['rcmd_vuv'] = temp['rcmd_vuv'] ? temp['rcmd_vuv']: 0;
          line['relation_article_vuv'] = temp['relation_article_vuv'] ? temp['relation_article_vuv']: 0;
          line['relation_video_vuv'] = temp['relation_video_vuv'] ? temp['relation_video_vuv']: 0;
          line['sp_vuv'] = temp['sp_vuv'] ? temp['sp_vuv']: 0;
          line['sy_ai_vuv'] = temp['sy_ai_vuv'] ? temp['sy_ai_vuv']: 0;
          line['sy_editor_vuv'] = temp['sy_editor_vuv'] ? temp['sy_editor_vuv']: 0;
          line['video_article_vuv'] = temp['video_article_vuv'] ? temp['video_article_vuv']: 0;
          downEntVuv.unshift(line['ent_vuv']);
          downIfengtvFirstVuv.unshift(line['ifengtv_first_vuv']);
          downMilVuv.unshift(line['mil_vuv']);
          downOutsideVuv.unshift(line['outside_vuv']);
          downPhtvVuv.unshift(line['phtv_vuv']);
          downRcmdVuv.unshift(line['rcmd_vuv']);
          downRelationArticleVuv.unshift(line['relation_article_vuv']);
          downRelationVideoVuv.unshift(line['relation_video_vuv']);
          downSpVuv.unshift(line['sp_vuv']);
          downSyAiVuv.unshift(line['sy_ai_vuv']);
          downSyEditorVuv.unshift(line['sy_editor_vuv']);
          downVideoArticleVuv.unshift(line['video_article_vuv']);
        }
      })
      var url = 'http://sdk.data.ifeng.com/video/video_videoVv.action?type=vv';
      this.$http.get(url).then((response) => {
        downEntVv.splice(0, downEntVv.length);
        downIfengtvFirstVv.splice(0, downIfengtvFirstVv.length);
        downMilVv.splice(0, downMilVv.length);
        downOutsideVv.splice(0, downOutsideVv.length);
        downPhtvVv.splice(0, downPhtvVv.length);
        downRcmdVv.splice(0, downRcmdVv.length);
        downRelationArticleVv.splice(0, downRelationArticleVv.length);
        downRelationVideoVv.splice(0, downRelationVideoVv.length);
        downSpVv.splice(0, downSpVv.length);
        downSyAiVv.splice(0, downSyAiVv.length);
        downSyEditorVv.splice(0, downSyEditorVv.length);
        downVideoArticleVv.splice(0, downVideoArticleVv.length);
        var obj = response.data;
        var temps = obj['data'];
        for (var i in temps) {
          var temp = temps[i];
          var line = {};
          line['ent_vv'] = temp['ent_vv'] ? temp['ent_vv']: 0;
          line['ifengtv_first_vv'] = temp['ifengtv_first_vv'] ? temp['ifengtv_first_vv']: 0;
          line['mil_vv'] = temp['mil_vv'] ? temp['mil_vv']: 0;
          line['outside_vv'] = temp['outside_vv'] ? temp['outside_vv']: 0;
          line['phtv_vv'] = temp['phtv_vv'] ? temp['phtv_vv']: 0;
          line['rcmd_vv'] = temp['rcmd_vv'] ? temp['rcmd_vv']: 0;
          line['relation_article_vv'] = temp['relation_article_vv'] ? temp['relation_article_vv']: 0;
          line['relation_video_vv'] = temp['relation_video_vv'] ? temp['relation_video_vv']: 0;
          line['sp_vv'] = temp['sp_vv'] ? temp['sp_vv']: 0;
          line['sy_ai_vv'] = temp['sy_ai_vv'] ? temp['sy_ai_vv']: 0;
          line['sy_editor_vv'] = temp['sy_editor_vv'] ? temp['sy_editor_vv']: 0;
          line['video_article_vv'] = temp['video_article_vv'] ? temp['video_article_vv']: 0;
          downEntVv.unshift(line['ent_vv']);
          downIfengtvFirstVv.unshift(line['ifengtv_first_vv']);
          downMilVv.unshift(line['mil_vv']);
          downOutsideVv.unshift(line['outside_vv']);
          downPhtvVv.unshift(line['phtv_vv']);
          downRcmdVv.unshift(line['rcmd_vv']);
          downRelationArticleVv.unshift(line['relation_article_vv']);
          downRelationVideoVv.unshift(line['relation_video_vv']);
          downSpVv.unshift(line['sp_vv']);
          downSyAiVv.unshift(line['sy_ai_vv']);
          downSyEditorVv.unshift(line['sy_editor_vv']);
          downVideoArticleVv.unshift(line['video_article_vv']);
        }
        this.isTrigger = true;
      })
    }
  },
  created: function () {
    this.getJSONUp();
    this.getJSONDown();
  },
  beforeUpdate: function () {
    var optionUp = {
      legend: {
        left: 'center',
        data: ['娱乐频道vuv', '娱乐频道vv', '凤凰TVtabvuv', '凤凰TVtabvv', '军事频道vuv', '军事频道vv', '分享视频回流vuv', '分享视频回流vv', '凤凰卫视vuv', '凤凰卫视vv', '推荐频道vuv', '推荐频道vv', '正文相关视频vuv', '正文相关视频vv', '相关视频vuv', '相关视频vv', '视频频道vuv', '视频频道vv', '头条机器推荐视频vuv', '头条机器推荐视频vv', '头条编辑推荐视频vuv', '头条编辑推荐视频vv', '文章页视频vuv', '文章页视频vv'],
        selectedMode: 'multiple',
        selected: {  
                    '娱乐频道vuv': true,  
                    '娱乐频道vv': true,  
                    '凤凰TVtabvuv': false,  
                    '凤凰TVtabvv': false,  
                    '军事频道vuv': false,  
                    '军事频道vv': false, 
                    '分享视频回流vuv': false,  
                    '分享视频回流vv': false,
                    '凤凰卫视vuv': false,  
                    '凤凰卫视vv': false,  
                    '推荐频道vuv': false,  
                    '推荐频道vv': false,  
                    '正文相关视频vuv': false, 
                    '正文相关视频vv': false,  
                    '相关视频vuv': false,
                    '相关视频vv': false,  
                    '视频频道vuv': false,  
                    '视频频道vv': false,  
                    '头条机器推荐视频vuv': false,  
                    '头条机器推荐视频vv': false,  
                    '头条编辑推荐视频vuv': false, 
                    '头条编辑推荐视频vv': false,  
                    '文章页视频vuv': false,
                    '文章页视频vv': false
                }  
      },
      tooltip: {
        trigger: 'axis',
        position: function (pt) {
          return [pt[0]-100, '10%'];
        }
      },
      grid: {
        top:'25%',
        left: '2%',
        right: '2%',
        bottom: '3%',
        containLabel: true
    },
    toolbox: {
        right:'2%',
        top:'12%',
        show: true,
        feature : {
            mark : {show: true},
            dataZoom : {show: true},
            magicType: {type: ['line', 'bar']},
            restore : {show: true},
            saveAsImage : {show: true}
        }
    },
      xAxis: {
        type: 'category',
        boundaryGap: false,
        data: this.upDate
      },
      yAxis: {
        type: 'value',
        boundaryGap: [0, '30%']
      },
      dataZoom: [
        {
          type: 'slider',
          show: true,
          xAxisIndex: [0],
          start: 0,
          end: 100
        },
        {
          type: 'inside',
          xAxisIndex: [0],
          start: 0,
          end: 100
        }
      ],
      series: [
        {
          name: '娱乐频道vuv',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.upEntVuv
        },
        {
          name: '娱乐频道vv',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.upEntVv
        },
        {
          name: '凤凰TVtabvuv',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.upIfengtvFirstVuv
        },
        {
          name: '凤凰TVtabvv',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.upIfengtvFirstVv
        },
        {
          name: '军事频道vuv',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.upMilVuv
        },
        {
          name: '军事频道vv',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.upMilVv
        },
        {
          name: '分享视频回流vuv',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.upOutsideVuv
        },
        {
          name: '分享视频回流vv',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.upOutsideVv
        },
        {
          name: '凤凰卫视vuv',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.upPhtvVuv
        },
        {
          name: '凤凰卫视vv',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.upPhtvVv
        },
        {
          name: '推荐频道vuv',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.upRcmdVuv
        },
        {
          name: '推荐频道vv',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.upRcmdVv
        },
        {
          name: '正文相关视频vuv',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.upRelationArticleVuv
        },
        {
          name: '正文相关视频vv',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.upRelationArticleVv
        },
        {
          name: '相关视频vuv',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.upRelationVideoVuv
        },
        {
          name: '相关视频vv',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.upRelationVideoVv
        },
        {
          name: '视频频道vuv',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.upSpVuv
        },
        {
          name: '视频频道vv',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.upSpVv
        },
        {
          name: '头条机器推荐视频vuv',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.upSyAiVuv
        },
        {
          name: '头条机器推荐视频vv',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.upSyAiVv
        },
        {
          name: '头条编辑推荐视频vuv',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.upSyEditorVuv
        },
        {
          name: '头条编辑推荐视频vv',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.upSyEditorVv
        },
        {
          name: '文章页视频vuv',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.upVideoArticleVuv
        },
        {
          name: '文章页视频vv',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.upVideoArticleVv
        }
      ]
    };
    upChart = echarts.init(document.getElementById('videoAreaUp'));
    upChart.setOption(optionUp);
    var optionDown = {
      legend: {
        x: 'center',
        y: 'bottom',
        data: ['娱乐频道', '凤凰TVtab', '军事频道', '分享视频回流', '凤凰卫视', '推荐频道', '正文相关视频', '相关视频', '视频频道', '头条机器推荐视频', '头条编辑推荐视频', '文章页视频']
      },
      tooltip: {
        trigger: 'item',
        formatter: "{a} <br/>{b} : {c} ({d}%)"
      },
      title: {
        x: 'center',
        text: '昨日视频数据分类统计饼图'
      },
      series: [
        {
          name: 'vuv',
          type: 'pie',
          radius: '55%',
          center: ['25%', '50%'],
          data: [
            {value: downEntVuv[0], name: '娱乐频道'},
            {value: downIfengtvFirstVuv[0], name: '凤凰TVtab'},
            {value: downMilVuv[0], name: '军事频道'},
            {value: downOutsideVuv[0], name: '分享视频回流'},
            {value: downPhtvVuv[0], name: '凤凰卫视'},
            {value: downRcmdVuv[0], name: '推荐频道'},
            {value: downRelationArticleVuv[0], name: '正文相关视频'},
            {value: downRelationVideoVuv[0], name: '相关视频'},
            {value: downSpVuv[0], name: '视频频道'},
            {value: downSyAiVuv[0], name: '头条机器推荐视频'},
            {value: downSyEditorVuv[0], name: '头条编辑推荐视频'},
            {value: downVideoArticleVuv[0], name: '文章页视频'}
          ],
          itemStyle: {
            emphasis: {
              shadowBlur: 20,
              shadowOffsetX: 0,
              shadowColor: 'rgba(0, 0, 0, 0.5)'
            }
          }
        },
        {
          name: 'vv',
          type: 'pie',
          radius: '55%',
          center: ['75%', '50%'],
          data: [
            {value: downEntVv[0], name: '娱乐频道'},
            {value: downIfengtvFirstVv[0], name: '凤凰TVtab'},
            {value: downMilVv[0], name: '军事频道'},
            {value: downOutsideVv[0], name: '分享视频回流'},
            {value: downPhtvVv[0], name: '凤凰卫视'},
            {value: downRcmdVv[0], name: '推荐频道'},
            {value: downRelationArticleVv[0], name: '正文相关视频'},
            {value: downRelationVideoVv[0], name: '相关视频'},
            {value: downSpVv[0], name: '视频频道'},
            {value: downSyAiVv[0], name: '头条机器推荐视频'},
            {value: downSyEditorVv[0], name: '头条编辑推荐视频'},
            {value: downVideoArticleVv[0], name: '文章页视频'}
          ],
          itemStyle: {
            emphasis: {
              shadowBlur: 20,
              shadowOffsetX: 0,
              shadowColor: 'rgba(0, 0, 0, 0.5)'
            }
          }
        }
      ],
      color: ['#c23531', '#2f4554', '#61a0a8', '#d48265', '#91c7ae', '#749f83', '#ca8622', '#bda29a', '#6e7074', '#546570', '#c4ccd3', '#ff7500']
    };
     downChart = echarts.init(document.getElementById('videoAreaDown'));
    downChart.setOption(optionDown);
  },
  mounted () {
        window.onresize = function(){
          upChart.resize();
          downChart.resize();
        }
   }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
/*h1, h2 {
  font-weight: normal;
}

ul {
  list-style-type: none;
  padding: 0;
}

li {
  display: inline-block;
  margin: 0 10px;
}

a {
  color: #42b983;
}*/
</style>
