<template>
  <!-- 文章消费反馈页面 -->
  <div class="animated fadeIn">
    <div class="card">
      <div class="card-block">
         <div id="articleStats" style="margin: 20px 1%">
            <el-row type="flex" justify="center">
              <el-col :span="2">
                <el-button type="primary" icon="search" :loading="isLoading" @click="handleClick">搜索</el-button>
              </el-col>
              <el-col :span="18" :offset="1">
                <el-autocomplete placeholder="请输入文章ID（如cmpp_034210050829769）" style="width: 100%" v-model="input" :fetch-suggestions="querySearch">
                </el-autocomplete>
              </el-col>
            </el-row>
            <div style="margin-top: 8px"></div>
            <el-row type="flex" justify="space-around">
              <el-col :span="3" :offset="2">
                <span>EV</span>
                <el-tooltip effect="dark" placement="top" :content="tipContent">
                  <el-button>{{evStats}}</el-button>
                </el-tooltip>
              </el-col>
              <el-col :span="3">
                <span>PV</span>
                <el-tooltip effect="dark" placement="top" :content="tipContent">
                  <el-button>{{pvStats}}</el-button>
                </el-tooltip>
              </el-col>
              <el-col :span="4">
                <span>分享次数</span>
                <el-tooltip effect="dark" placement="top" :content="tipContent">
                  <el-button>{{shareStats}}</el-button>
                </el-tooltip>
              </el-col>
              <el-col :span="4">
                <span>收藏次数</span>
                <el-tooltip effect="dark" placement="top" :content="tipContent">
                  <el-button>{{storeStats}}</el-button>
                </el-tooltip>
              </el-col>
              <el-col :span="4">
                <span>评论次数</span>
                <el-tooltip effect="dark" placement="top" :content="tipContent">
                  <el-button>{{commentStats}}</el-button>
                </el-tooltip>
              </el-col>
            </el-row>
      </div>
    <div id="articleArea" style="width: 100%; height: 400px; margin: 0 auto;text-align: -webkit-center;"></div>
      </div>
    </div><!--/.card-->
    <div class="row" style="margin-bottom:20px">
      <div id="wholeTable" style="width: 98%; margin: 0 auto">
      <el-row style="margin-bottom: 10px ">
         <el-col :span="16">
          <el-pagination :total="tableDataAll.length" :page-size="pageSize" :page-sizes="[5, 10, 15, 20]" :current-page="pageCurr"
      layout="total, sizes, prev, pager, next, jumper" @size-change="handleSizeChange" @current-change="handleCurrentChange"></el-pagination>
        </el-col>
      </el-row>
      
      <el-table  v-loading="isLoading"   element-loading-text="拼命加载中"  :data="tableData" :row-class-name="tableRowClassName">
        <el-table-column align="center" v-for="item in columns" :prop="item.prop" :label="item.label" :width="item.width" sortable></el-table-column>
      </el-table>
    </div>
    </div>
  </div><!--/.row-->
</template>

<script>
import echarts from 'echarts'
var 
  input = '',
  history = [],
  tipContent = '',
  evStats = 0,
  pvStats = 0,
  shareStats = 0,
  storeStats = 0,
  commentStats = 0,
  pageSize = 10,
  pageCurr = 1,
  columns = [
    {
      prop: 'time',
      label: '时间',
      width: '210px'
    },
    {
      prop: 'id',
      label: 'ID',
      width: '250px'
    },
    {
      prop: 'ev',
      label: 'EV',
      width: '210px'
    },
    {
      prop: 'pv',
      label: 'PV',
      width: '210px'
    },
    {
      prop: 'share',
      label: '分享次数',
      width: '210px'
    },
    {
      prop: 'store',
      label: '收藏次数',
      width: '210px'
    },
    {
      prop: 'comment',
      label: '评论次数',
      width: '210px'
    }
  ],
  tableData = [],
  tableDataAll = [],
  tableDataAllTime = [],
  tableDataAllEv = [],
  tableDataAllPv = [],
  tableDataAllShare = [],
  tableDataAllStore = [],
  tableDataAllComment = [];
export default {
  data () {
    return {
      isLoading: false,
      input: input,
      history: history,
      tipContent: '累积实时统计结果，截止至今日'+this.getDaytime().slice(0, 2)+'时'+this.getDaytime().slice(2)+'分',
      evStats: evStats,
      pvStats: pvStats,
      shareStats: shareStats,
      storeStats: storeStats,
      commentStats: commentStats,
      pageSize: pageSize,
      pageCurr: pageCurr,
      columns: columns,
      tableData: tableData,
      tableDataAll: tableDataAll,
      tableDataAllTime: tableDataAllTime,
      tableDataAllEv: tableDataAllEv,
      tableDataAllPv: tableDataAllPv,
      tableDataAllShare: tableDataAllShare,
      tableDataAllStore: tableDataAllStore,
      tableDataAllComment: tableDataAllComment
    }
  },
  methods: {
    // 搜索
    handleClick(ev) {
      var res = sessionStorage.getItem('historyA');
      if (res) {
        if (res.indexOf(this.input) == -1) {
          sessionStorage.setItem('historyA', res+' '+this.input);
        } else {
          var start = res.indexOf(this.input);
          var end = start+this.input.length;
          if (start != 0) {
            start = start-1;
          }
          res = res.slice(0, start)+res.slice(end);
          var arr = res.split(' ');
          this.history.splice(0, this.history.length);
          for (var i in arr) {
            this.history.unshift({"value": arr[i]});
          }
          sessionStorage.setItem('historyA', res+' '+this.input);
        }
      } else {
        sessionStorage.setItem('historyA', this.input);
      }
      this.history.unshift({"value": this.input});
      this.isLoading = true;
      this.getJSONStats();
      this.getJSON();
      this.isLoading = false;
    },
    // 历史
    querySearch(queryString, cb) {
      if (this.history.length == 0) {
        var res = sessionStorage.getItem('historyA');
        if (res) {
          var arr = res.split(' ');
          for (var i in arr) {
            this.history.unshift({"value": arr[i]});
          }
        }
      }
      cb(this.history);
    },
    // 分页
    handleSizeChange(val) {
      this.pageSize = val;
      this.pageCurr = 1;
      tableData.splice(0, tableData.length);
      for (var i = 0; i < val; i++) {
        var line = tableDataAll[i];
        line['ev'] = line['ev'].toLocaleString();
        line['pv'] = line['pv'].toLocaleString();
        line['share'] = line['share'].toLocaleString();
        line['store'] = line['store'].toLocaleString();
        line['comment'] = line['comment'].toLocaleString();
        tableData.push(tableDataAll[i]);
      }
    },
    // 换页
    handleCurrentChange(val) {
      this.pageCurr = val;
      tableData.splice(0, tableData.length);
      var end = (tableDataAll.length > (this.pageCurr)*(this.pageSize)) ? (this.pageCurr)*(this.pageSize) : tableDataAll.length;
      for (var i = (this.pageCurr-1)*(this.pageSize); i < end; i++) {
        var line = tableDataAll[i];
        line['ev'] = line['ev'].toLocaleString();
        line['pv'] = line['pv'].toLocaleString();
        line['share'] = line['share'].toLocaleString();
        line['store'] = line['store'].toLocaleString();
        line['comment'] = line['comment'].toLocaleString();
        tableData.push(tableDataAll[i]);
      }
    },
    tableRowClassName(row, index) {
      if (index%2 != 0) {
        return 'odd-row';
      } else if (index%2 == 0) {
        return 'even-row';
      }
      return '';
    },
    getDay: function (day) {
      var today = new Date();
      var target = today.getTime()+1000*60*60*24*day;
      today.setTime(target);
      var year = today.getFullYear();
      var month = today.getMonth();
      var date = today.getDate();
      month = this.addZero(month+1);
      date = this.addZero(date);
      return year.toString()+month.toString()+date.toString();
    },
    getDaytime: function () {
      var today = new Date();
      var hour = today.getHours();
      var minute = today.getMinutes();
      hour = this.addZero(hour);
      minute = this.addZero(minute);
      return hour.toString()+minute.toString();
    },
    addZero: function (time) {
      if (time.toString().length == 1) {
        time = '0'+time;
      }
      return time;
    },
    getJSONStats: function () {
      var url = 'http://10.80.128.150:58080/newsPortrait/agg?start='+this.getDay(-7)+'&stop='+this.getDay(0)+'&id='+this.input;
      this.$http.get(url).then((response) => {
        var temp = response.data;
        this.evStats = temp['ev'];
        this.pvStats = temp['pv'];
        this.shareStats = temp['share'];
        this.storeStats = temp['store'];
        this.commentStats = temp['comment'];
        this.tipContent = '累积实时统计结果，截止至今日'+this.getDaytime().slice(0, 2)+'时'+this.getDaytime().slice(2)+'分';
      })
    },
    getJSON: function () {
      this.isLoading = true;
      var url = 'http://10.80.128.150:58080/newsPortrait/agg/5min?start='+this.getDay(0)+'0000'+'&stop='+this.getDay(0)+this.getDaytime()+'&id='+this.input;
      this.$http.get(url).then((response) => {
        this.isLoading = false;
        tableDataAll.splice(0, tableDataAll.length);
        tableDataAllTime.splice(0, tableDataAllTime.length);
        tableDataAllEv.splice(0, tableDataAllEv.length);
        tableDataAllPv.splice(0, tableDataAllPv.length);
        tableDataAllShare.splice(0, tableDataAllShare.length);
        tableDataAllStore.splice(0, tableDataAllStore.length);
        tableDataAllComment.splice(0, tableDataAllComment.length);
        var temps = response.data;
        for (var i in temps) {
          var temp = temps[i];
          var line = {};
          line['time'] = temp['time'] ? temp['time']: 0;
          line['id'] = temp['id'] ? temp['id']: 0;
          line['ev'] = temp['ev'] ? temp['ev']: 0;
          line['pv'] = temp['pv'] ? temp['pv']: 0;
          line['share'] = temp['share'] ? temp['share']: 0;
          line['store'] = temp['store'] ? temp['store']: 0;
          line['comment'] = temp['comment'] ? temp['comment']: 0;
          tableDataAll.unshift(line);
          tableDataAllTime.push(line['time'].slice(8, 10)+':'+line['time'].slice(10));
          tableDataAllEv.push(line['ev']);
          tableDataAllPv.push(line['pv']);
          tableDataAllShare.push(line['share']);
          tableDataAllStore.push(line['store']);
          tableDataAllComment.push(line['comment']);
        }
        tableData.splice(0, tableData.length);
        for (var i = 0; i < this.pageSize; i++) {
          var line = tableDataAll[i];
          line['ev'] = line['ev'].toLocaleString();
          line['pv'] = line['pv'].toLocaleString();
          line['share'] = line['share'].toLocaleString();
          line['store'] = line['store'].toLocaleString();
          line['comment'] = line['comment'].toLocaleString();
          tableData.push(tableDataAll[i]);
        }
      })
    }
  },
  beforeUpdate: function () {
    var option = {
      legend: {
        right: 100,
        data: ['EV', 'PV', '分享次数', '收藏次数', '评论次数'],
        selectedMode: 'single'
      },
      grid: {
        top:'20%',
        left: '2%',
        right: '4%',
        bottom: '3%',
        containLabel: true
    },
    toolbox: {
        right:'2%',
        top:'8%',
        show: true,
        feature : {
            mark : {show: true},
            dataZoom : {show: true},
            magicType: {type: ['line', 'bar']},
            restore : {show: true},
            saveAsImage : {show: true}
        }
    },
      tooltip: {
        trigger: 'axis',
        position: function (pt) {
          return [pt[0]-100, '10%'];
        }
      },
      title: {
        left: 100,
        text: '今日文章数据5分钟粒度统计'
      },
      xAxis: {
        type: 'category',
        boundaryGap: false,
        data: this.tableDataAllTime
      },
      yAxis: {
        type: 'value',
        boundaryGap: [0, '30%']
      },
      dataZoom: [
        {
          type: 'slider',
          show: true,
          xAxisIndex: [0],
          start: 0,
          end: 100
        },
        {
          type: 'inside',
          xAxisIndex: [0],
          start: 0,
          end: 100
        }
      ],
      series: [
        {
          name: 'EV',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.tableDataAllEv
        },
        {
          name: 'PV',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.tableDataAllPv
        },
        {
          name: '分享次数',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.tableDataAllShare
        },
        {
          name: '收藏次数',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.tableDataAllStore
        },
        {
          name: '评论次数',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.tableDataAllComment
        }
      ]
    };
    var myChart = echarts.init(document.getElementById('articleArea'));
    myChart.setOption(option);
  },
  mounted: function () {
    var _this = this;
    document.getElementsByTagName('input')[0].onkeydown = function (e) {
      if (e.keyCode == 13) {
        _this.handleClick();
      }
    };
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
.el-table .odd-row {
  background: #c9e5f5;
}

.el-table .even-row {
  background: #e2f0e4;
}

/*h1, h2 {
  font-weight: normal;
}

ul {
  list-style-type: none;
  padding: 0;
}

li {
  display: inline-block;
  margin: 0 10px;
}

a {
  color: #42b983;
}*/
</style>
