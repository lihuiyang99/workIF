<template>
  <!-- 长效整体页面 -->
  <div class="animated fadeIn">
    <div class="card">
      <div class="card-block">
        <div class="row">
          <div class="col-sm-5">
            <h4 class="card-title">长效汇总曲线图</h4>
            <div class="small text-muted"></div>
          </div><!--/.col-->
        </div><!--/.row-->
         <div id="wholeArea" style="width: 100%; height: 400px; margin: 0 auto;text-align: -webkit-center;"></div>
      </div>
    </div><!--/.card-->
    <div class="row" style="margin-bottom:20px">
      <div id="wholeTable" style="width: 98%; margin: 0 auto">
      <el-row style="margin-bottom: 10px ">
         <el-col :span="16">
          <el-pagination :total="tableDataAll.length" :page-size="pageSize" :page-sizes="[5, 10, 15, 20]" :current-page="pageCurr"
          layout="total, sizes, prev, pager, next, jumper" @size-change="handleSizeChange" @current-change="handleCurrentChange"></el-pagination>
        </el-col>
        <el-col :span="3" style="margin-top: -4px">
          <el-date-picker type="daterange" placeholder="选择日期范围" :clearable="false" v-model="input" @change="handleChange"></el-date-picker>
        </el-col>
      </el-row>
     <!--  <el-tooltip  effect="dark" placement="bottom" >
        <div slot="content">文章更新量：当日曝光，但未在之前5日内曝光的文章<br/>曝光次数：该频道文章曝光次数<br/>曝光人数：该频道文章曝光的用户数<br/>频道页UV：频道首页停留3秒以上的用户<br/>转化率：阅读PV/EV<br/>分享率：分享次数/EV<br/></div>
      <i class="el-icon-warning" style="float: right;margin:7px 15px"></i>
      </el-tooltip> -->
       <el-table   v-loading="isLoading"   element-loading-text="拼命加载中"  :data="tableData" :row-class-name="tableRowClassName">
          <el-table-column align="center" v-for="item in columns" :prop="item.prop" :label="item.label" :min-width="item.width" sortable>
          </el-table-column>
        </el-table>
    </div>
    </div>
  </div><!--/.row-->
</template>

<script>
import echarts from 'echarts'
var input = '',
  startDate = '',
  endDate = '',
  pageSize = 10,
  pageCurr = 1,
  columns = [
    {
      prop: 'date',
      label: '日期',
      width: '120px'
    },
    {
      prop: 'share',
      label: '分享数',
      width: '100px'
    },
    {
      prop: 'share_ev',
      label: '曝光分享率',
      width: '100px'
    },
	 {
      prop: 'head_share',
      label: '头条曝光分享率',
      width: '100px'
    },
    {
      prop: 'share_read',
      label: '阅读分享率',
      width: '100px'
    },
    {
      prop: 'pv_ev',
      label: '转化率',
      width: '100px'
    },
	{
      prop: 'head_pv',
      label: '头条转化率',
      width: '100px'
    },
	{
      prop: 'to_solve',
      label: '待处理数量',
      width: '100px'
    },
    {
      prop: 'solved',
      label: '已通过数量',
      width: '100px'
    },
    {
      prop: 'pagenum',
      label: '曝光篇数',
      width: '100px'
    },
    {
      prop: 'ev_rate',
      label: '曝光占比',
      width: '100px'
    },
    {
      prop: 'ev',
      label: 'EV',
      width: '120px'
    },
    {
      prop: 'euv',
      label: 'EUV',
      width: '100px'
    },
    {
      prop: 'ev_avg',
      label: '人均EV',
      width: '100px'
    },
    {
      prop: 'pv',
      label: '阅读PV',
      width: '100px'
    },
    {
      prop: 'uv',
      label: '阅读UV',
      width: '100px'
    },
    {
      prop: 'pv_avg',
      label: '人均阅读PV',
      width: '100px'
    },
    {
      prop: 'duration',
      label: '阅读时长(分)',
      width: '130px'
    },
    {
      prop: 'duration_avg',
      label: '人均阅读时长(分)',
      width: '100px'
    },
    {
      prop: 'store',
      label: '收藏数',
      width: '100px'
    }
  ],
  tableData = [],
  tableDataAll = [],
  tableDataAllDate = [],
  tableDataAllShare = [],
  tableDataAllShareEv = [],
  tableDataAllHeadShare = [],
  tableDataAllShareRead = [],
  tableDataAllPvEv = [],
  tableDataAllHeadPv = [],
  tableDataAllToSolve = [],
  tableDataAllSolved = [],
  tableDataAllPagenum = [],
  tableDataAllEvRate = [],
  tableDataAllEv = [],
  tableDataAllEuv = [],
  tableDataAllEvAvg = [],
  tableDataAllPv = [],
  tableDataAllUv = [],
  tableDataAllPvAvg = [],
  tableDataAllDuration = [],
  tableDataAllDurationAvg = [],
  tableDataAllStore = [];
  
export default {
  data () {
    return {
      isLoading: false,
      input: input,
      startDate: startDate,
      endDate: endDate,
      pageSize: pageSize,
      pageCurr: pageCurr,
      columns: columns,
      tableData: tableData,
  tableDataAll: tableDataAll,
  tableDataAllDate: tableDataAllDate,
  tableDataAllShare: tableDataAllShare,
  tableDataAllShareEv: tableDataAllShareEv,
  tableDataAllHeadShare: tableDataAllHeadShare,
  tableDataAllShareRead: tableDataAllShareRead,
  tableDataAllPvEv: tableDataAllPvEv,
  tableDataAllHeadPv: tableDataAllHeadPv,
  tableDataAllToSolve: tableDataAllToSolve,
  tableDataAllSolved: tableDataAllSolved,
  tableDataAllPagenum: tableDataAllPagenum,
  tableDataAllEvRate: tableDataAllEvRate,
  tableDataAllEv: tableDataAllEv,
  tableDataAllEuv: tableDataAllEuv,
  tableDataAllEvAvg: tableDataAllEvAvg,
  tableDataAllPv: tableDataAllPv,
  tableDataAllUv: tableDataAllUv,
  tableDataAllPvAvg: tableDataAllPvAvg,
  tableDataAllDuration: tableDataAllDuration,
  tableDataAllDurationAvg: tableDataAllDurationAvg,
  tableDataAllStore: tableDataAllStore
	  
    }
  },
  methods: {
    // 下载
    // handleClick(ev) {
    //   var url = 'http://10.50.1.130:38080/macro/macro_exportDataToExcelV2.action?startDate='+this.startDate+'&endDate='+this.endDate+'&col='+encodeURI(JSON.stringify(excelColumns));
    //   window.open(url);
    // },
    // 选择
    handleChange(val) {
      this.startDate = val.slice(0, 10);
      this.endDate = val.slice(13, 23);
      this.getJSON();
    },
    // 分页
    handleSizeChange(val) {
      this.pageSize = val;
      this.pageCurr = 1;
      tableData.splice(0, tableData.length);
      for (var i = 0; i < val; i++) {
        var line = tableDataAll[i];
        for( var x in line ){
          line[x] = line[x].toLocaleString();
        }
  //       line['newUser'] = line['newUser'].toLocaleString();
  //       line['dau'] = line['dau'].toLocaleString();
  //       line['thirdparty'] = line['thirdparty'].toLocaleString();
  //       line['ev'] = line['ev'].toLocaleString();
  //       line['pv'] = line['pv'].toLocaleString();
  //       line['pvAvg'] = line['pvAvg'].toLocaleString();
  //       line['useTime'] = line['useTime'].toLocaleString();
  //       line['numStart'] = line['numStart'].toLocaleString();
  //       line['share'] = line['share'].toLocaleString();
  //       line['shareUv'] = line['shareUv'].toLocaleString();
		// line['vv'] = line['vv'].toLocaleString();
		// line['vvAvg'] = line['vvAvg'].toLocaleString();
		// line['evAvg'] = line['evAvg'].toLocaleString();
        tableData.push(tableDataAll[i]);
      }
    },
    // 换页
    handleCurrentChange(val) {
      this.pageCurr = val;
      tableData.splice(0, tableData.length);
      var end = (tableDataAll.length > (this.pageCurr)*(this.pageSize)) ? (this.pageCurr)*(this.pageSize) : tableDataAll.length;
      for (var i = (this.pageCurr-1)*(this.pageSize); i < end; i++) {
        var line = tableDataAll[i];
        for( var x in line ){
          line[x] = line[x].toLocaleString();
        }
  //       line['newUser'] = line['newUser'].toLocaleString();
  //       line['dau'] = line['dau'].toLocaleString();
  //       line['thirdparty'] = line['thirdparty'].toLocaleString();
  //       line['ev'] = line['ev'].toLocaleString();
  //       line['pv'] = line['pv'].toLocaleString();
  //       line['pvAvg'] = line['pvAvg'].toLocaleString();
  //       line['useTime'] = line['useTime'].toLocaleString();
  //       line['numStart'] = line['numStart'].toLocaleString();
  //       line['share'] = line['share'].toLocaleString();
  //       line['shareUv'] = line['shareUv'].toLocaleString();
		// line['vv'] = line['vv'].toLocaleString();
		// line['vvAvg'] = line['vvAvg'].toLocaleString();
		// line['evAvg'] = line['evAvg'].toLocaleString();
        tableData.push(tableDataAll[i]);
      }
    },
    tableRowClassName(row, index) {
      if (index%2 != 0) {
        return 'odd-row';
      } else if (index%2 == 0) {
        return 'even-row';
      }
      return '';
    },
    getDay: function (day) {
      var today = new Date();
      var target = today.getTime()+1000*60*60*24*day;
      today.setTime(target);
      var year = today.getFullYear();
      var month = today.getMonth();
      var date = today.getDate();
      month = this.addZero(month+1);
      date = this.addZero(date);
      return year.toString()+'-'+month.toString()+'-'+date.toString();
    },
    addZero: function (time) {
      if (time.toString().length == 1) {
        time = '0'+time;
      }
      return time;
    },
    getJSON: function () {
      this.isLoading = true;
      if ((this.startDate) && (this.endDate)) {
      } else {
        this.startDate = this.getDay(-31);
        this.endDate = this.getDay(0);
      }
      var url = 'http://sdk.data.ifeng.com/idpool/idpool_idpoolData.action?startDate='+this.startDate+'&endDate='+this.endDate;
      this.$http.get(url).then((response) => {
        this.isLoading = false;
  tableDataAll.splice(0, tableDataAll.length);
  tableDataAllDate.splice(0, tableDataAllDate.length);
  tableDataAllShare.splice(0, tableDataAllShare.length);
  tableDataAllShareEv.splice(0, tableDataAllShareEv.length);
  tableDataAllHeadShare.splice(0, tableDataAllHeadShare.length);
  tableDataAllShareRead.splice(0, tableDataAllShareRead.length);
  tableDataAllPvEv.splice(0, tableDataAllPvEv.length);
  tableDataAllHeadPv.splice(0, tableDataAllHeadPv.length);
  tableDataAllToSolve.splice(0, tableDataAllToSolve.length);
  tableDataAllSolved.splice(0, tableDataAllSolved.length);
  tableDataAllPagenum.splice(0, tableDataAllPagenum.length);
  tableDataAllEvRate.splice(0, tableDataAllEvRate.length);
  tableDataAllEv.splice(0, tableDataAllEv.length);
  tableDataAllEuv.splice(0, tableDataAllEuv.length);
  tableDataAllEvAvg.splice(0, tableDataAllEvAvg.length);
  tableDataAllPv.splice(0, tableDataAllPv.length);
  tableDataAllUv.splice(0, tableDataAllUv.length);
  tableDataAllPvAvg.splice(0, tableDataAllPvAvg.length);
  tableDataAllDuration.splice(0, tableDataAllDuration.length);
  tableDataAllDurationAvg.splice(0, tableDataAllDurationAvg.length);
  tableDataAllStore.splice(0, tableDataAllStore.length);
        var obj = response.data;
        var temps = obj['data'];
        for (var i in temps) {
          var temp = temps[i];
          var line = {};
          line['date'] = temp['date'] ? temp['date']: 0;
          line['share'] = temp['share'] ? temp['share']: 0;
          line['share_ev'] = temp['share_ev'] ? parseFloat(temp['share_ev']*100).toFixed(3)+'%': 0;
          line['head_share'] = temp['head_share'] ? parseFloat(temp['head_share']*100).toFixed(3)+'%': 0;
          line['share_read'] = temp['share_read'] ? parseFloat(temp['share_read']*100).toFixed(3)+'%': 0;
          line['pv_ev'] = temp['pv_ev'] ? parseFloat(temp['pv_ev']*100).toFixed(3)+'%': 0;
          line['head_pv'] = temp['head_pv'] ? parseFloat(temp['head_pv']*100).toFixed(3)+'%': 0;
          line['to_solve'] = temp['to_solve'] ? temp['to_solve']: 0;
          line['solved'] = temp['solved'] ? temp['solved']: 0;
          line['pagenum'] = temp['pagenum'] ? temp['pagenum']: 0;
          line['ev_rate'] = temp['ev_rate'] ? parseFloat(temp['ev_rate']*100).toFixed(3)+'%': 0;
          line['ev'] = temp['ev'] ? temp['ev']: 0;
          line['euv'] = temp['euv'] ? temp['euv']: 0;
          line['ev_avg'] = temp['ev_avg'] ? parseFloat(temp['ev_avg']).toFixed(3): 0;
          line['pv'] = temp['pv'] ? temp['pv']: 0;
          line['uv'] = temp['uv'] ? temp['uv']: 0;
          line['pv_avg'] = temp['pv_avg'] ? parseFloat(temp['pv_avg']).toFixed(3): 0;
          line['duration'] = temp['duration'] ? parseFloat(temp['duration']).toFixed(3): 0;
          line['duration_avg'] = temp['duration_avg'] ? parseFloat(temp['duration_avg']).toFixed(3): 0;
          line['store'] = temp['store'] ? temp['store']: 0;
    
          tableDataAll.push(line);
          tableDataAllDate.unshift(line['date']);
          tableDataAllShare.unshift(line['share']);
          tableDataAllShareEv.unshift(parseFloat(line['share_ev']));
          tableDataAllHeadShare.unshift(parseFloat(line['head_share']));
          tableDataAllShareRead.unshift(parseFloat(line['share_read']));
          tableDataAllPvEv.unshift(parseFloat(line['pv_ev']));
          tableDataAllHeadPv.unshift(parseFloat(line['head_pv']));
          tableDataAllToSolve.unshift(line['to_solve']);
          tableDataAllSolved.unshift(line['solved']);
          tableDataAllPagenum.unshift(line['pagenum']);
          tableDataAllEvRate.unshift(parseFloat(line['ev_rate']));
          tableDataAllEv.unshift(line['ev']);
          tableDataAllEuv.unshift(line['euv']);
          tableDataAllEvAvg.unshift(parseFloat(line['ev_avg']));
          tableDataAllPv.unshift(line['pv']);
          tableDataAllUv.unshift(line['uv']);
          tableDataAllPvAvg.unshift(parseFloat(line['pv_avg']));
          tableDataAllDuration.unshift(line['duration']);
          tableDataAllDurationAvg.unshift(parseFloat(line['duration_avg']));
          tableDataAllStore.unshift(line['store']);
        }
        tableData.splice(0, tableData.length);
        if (tableDataAll.length < 5) {
          this.pageSize = tableDataAll.length;
        } else {
          this.pageSize = 10;
        }
        for (var i = 0; i < this.pageSize; i++) {
          var line = tableDataAll[i];
          for( var x in line ){
            line[x] = line[x].toLocaleString();
          }
          tableData.push(tableDataAll[i]);
        }
      })
    }
  },
  created: function () {
    this.getJSON();
  },
  beforeUpdate: function () {
    var option = {
      legend: {
        left: 'center',
        data: ['分享数', '曝光分享率', '头条曝光分享率', '阅读分享率', '转化率', '头条转化率', '待处理数量', '已通过数量', '曝光篇数', '曝光占比', 'EV', 'EUV', '人均EV'
        ,'阅读PV','阅读UV','人均阅读PV','阅读时长(分)','人均阅读时长(分)','收藏数'],
        selectedMode: 'multiple',
        selected: {  
                    '分享数': false,  
                    '曝光分享率': false,  
                    '头条曝光分享率': false,  
                    '阅读分享率': false,  
                    '转化率': false,  
                     '头条转化率': true,  
                    '待处理数量': false, 
                    '已通过数量': false,  
                    '曝光篇数': false,  
                    '曝光占比': true,  
                    'EV': false,  
                    'EUV': false, 
                    '人均EV': false,  
                    '阅读PV': false,
                    '阅读UV': false,  
                    '人均阅读PV': false,  
                    '阅读时长(分)': false,  
                    '人均阅读时长(分)': false,
                    '收藏数': false
                }  
      },
      grid: {
        top:'20%',
        left: '2%',
        right: '4%',
        bottom: '3%',
        containLabel: true
    },
    toolbox: {
        right:'2%',
        top:'10%',
        show: true,
        feature : {
            mark : {show: true},
            dataZoom : {show: true},
            magicType: {type: ['line', 'bar']},
            restore : {show: true},
            saveAsImage : {show: true}
        }
    },
      tooltip: {
        trigger: 'axis',
        position: function (pt) {
          return [pt[0]-100, '10%'];
        }
      },
      xAxis: {
        type: 'category',
        boundaryGap: false,
        data: this.tableDataAllDate
      },
      yAxis: {
        type: 'value',
        boundaryGap: [0, '30%']
      },
      dataZoom: [
        {
          type: 'slider',
          show: true,
          xAxisIndex: [0],
          start: 0,
          end: 100
        },
        {
          type: 'inside',
          xAxisIndex: [0],
          start: 0,
          end: 100
        }
      ],
      series: [
        {
          name: '分享数',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.tableDataAllShare
        },
        {
          name: '曝光分享率',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.tableDataAllShareEv
        },
		{
          name: '头条曝光分享率',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.tableDataAllHeadShare
        },
        {
          name: '阅读分享率',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.tableDataAllShareRead
        },
        {
          name: '转化率',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.tableDataAllPvEv
        },
		{
          name: '头条转化率',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.tableDataAllHeadPv
        },
		{
          name: '待处理数量',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.tableDataAllToSolve
        },
        {
          name: '已通过数量',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.tableDataAllSolved
        },
        {
          name: '曝光篇数',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.tableDataAllPagenum
        },
        {
          name: '曝光占比',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.tableDataAllEvRate
        },
        {
          name: 'EV',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.tableDataAllEv
        },
        {
          name: 'EUV',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.tableDataAllEuv
        },
        {
          name: '人均EV',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.tableDataAllEvAvg 
        },
        {
          name: '阅读PV',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.tableDataAllPv
        },
        {
          name: '阅读UV',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.tableDataAllUv
        },
        {
          name: '人均阅读PV',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.tableDataAllPvAvg
        },
        {
          name: '阅读时长(分)',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.tableDataAllDuration
        },
        {
          name: '人均阅读时长(分)',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.tableDataAllDurationAvg
        },
        {
          name: '收藏数',
          type: 'line',
          smooth: true,
          symbol: 'none',
          sampling: 'average',
          areaStyle: {
            normal: {
              opacity: 0.6
            }
          },
          data: this.tableDataAllStore
        },
      ]
    };
    var myChart = echarts.init(document.getElementById('wholeArea'));
    myChart.setOption(option);
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
/*h1, h2 {
  font-weight: normal;
}

ul {
  list-style-type: none;
  padding: 0;
}

li {
  display: inline-block;
  margin: 0 10px;
}

a {
  color: #42b983;
}*/
</style>
