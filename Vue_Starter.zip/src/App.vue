<template>
  <router-view></router-view>
</template>

<script>
export default {
  name: 'app'
}
</script>

<style>
#wholeTable {
		margin-bottom: 10px;
	}
	#wholeTable  ::-webkit-scrollbar{width:4px;}
	#wholeTable  ::-webkit-scrollbar-track{background-color:#e8cece;}
	#wholeTable ::-webkit-scrollbar-thumb{background-color:#7bb1d8;}
	#wholeTable ::-webkit-scrollbar-thumb:hover {background-color:#ccc}
	#wholeTable ::-webkit-scrollbar-thumb:active {background-color:#00aff0}
</style> 
