// The Vue build version to load with the `import` command
// (runtime-only or standalone) has been set in webpack.base.conf with an alias.
import Vue from 'vue'
import App from './App'
import router from './router'
import ElementUI from 'element-ui' // 引入UI组件
import 'element-ui/lib/theme-default/index.css'
import Resource from 'vue-resource' // 引入Ajax插件
import $ from 'jquery'
import {MessageBox} from 'element-ui' // 额外引入MessageBox弹框
/* eslint-disable no-new */
import Vuex from 'vuex'

Vue.use(Vuex)
Vue.use(Resource) // 全局组件使用Ajax插件
Vue.use(ElementUI) // 全局组件使用前端路由
/*由于先走，所以先获取权限*/



// 前端路由全局方法
router.beforeEach((to, from, next) => {
	
  // 清session
 // 非登陆页面路由控制
  var d = new Date();
  var uid = localStorage.getItem('uid');
  var name = localStorage.getItem(to.path.slice(1))

  if (localStorage.getItem('date') != d.toLocaleDateString()&&to.path!='/') {
    next({ path: '/' });
  } else if (uid && !name&&to.path != '/home'&&to.path!='/') {
    MessageBox({
      title: '无法跳转到页面路径'+to.path,
      message: '请联系管理员添加相应页面的浏览权限！',
      type: 'warning'
    });
    next({ path: '/home' });
  } else {
    next();

  }
  
  // next();
})

new Vue({
  el: '#app',
  router,
  template: '<App/>',
  components: { App }
})
