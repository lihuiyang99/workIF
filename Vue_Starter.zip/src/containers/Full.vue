<template>
  <div class="app">
    <AppHeader/>
    <div class="app-body">
      <Sidebar/>
      <main class="main">
        <breadcrumb :list="list"/>
        <div class="container-fluid">
            
          <router-view></router-view>
        </div>
        <div v-if="this.$route.path=='/home'" style="width:100%;height:100%;padding:50px 20px;box-sizing:border-box;">
            <div style="width:100%;height:100%;background:#ffffff url(../../static/img/ifengBg.png) no-repeat center bottom;position:relative;">
                  <img style="position:absolute;left:50%;top:20%;margin-left:-100px;width:200px;" src="../../static/img/ifengIcon.png">
            </div><!--/.col-->
        </div>
      </main>
    </div>
    <AppFooter/>
  </div>
</template>

<script>
import AppHeader from '../components/Header'
import Sidebar from '../components/Sidebar'
import AppFooter from '../components/Footer'
import Breadcrumb from '../components/Breadcrumb'
var uid = '',
  token2 = '',
  name = '';
export default {
  data() {
    return {
      uid: uid,
      token2: token2,
      name: name
    }
  },
  /*name: 'full',*/
  components: {
    AppHeader,
    Sidebar,
    AppFooter,
    Breadcrumb
  },
  methods: {
    // 存session
  },
  created: function () {
    console.log(this.$route.path)
   /*this.getLogin();*/
  },
  computed: {
   /* name () {
      return this.$route.name
    },*/

    list () {
      return this.$route.matched
    }
  }
}
</script>
