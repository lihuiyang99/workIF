<template>
  <aside class="aside-menu px-2">
    
  </aside>
</template>

<script>
export default {
  name: 'aside'
}
</script>
