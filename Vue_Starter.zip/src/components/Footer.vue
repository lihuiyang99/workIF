<template>
  <footer class="app-footer">
     © 2017 技术中心数据组, All Rights Reserved ®
    <span class="float-right">Powered by Recommendation Analysis</span>
  </footer>
</template>
<script>
export default {
  name: 'footer'
}
</script>
