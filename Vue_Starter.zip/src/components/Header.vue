<template>
  <navbar>
    <button class="navbar-toggler mobile-sidebar-toggler d-lg-none" type="button" @click="mobileSidebarToggle">&#9776;</button>    <a class="navbar-brand" style="background-image:url(../../static/img/logo.png)" href="#"></a>
    <ul class="nav navbar-nav d-md-down-none mr-auto">
      <li class="nav-item" >
        <a class="nav-link navbar-toggler sidebar-toggler" href="#" @click="sidebarToggle">&#9776;</a>
      </li>
    </ul>
    <ul class="nav navbar-nav ml-auto" style="margin-right: 5%;">
      <li class="nav-item d-md-down-none">
        <a class="nav-link" href="#"><i class="icon-bell"></i><span class="badge badge-pill badge-danger">0</span></a>
      </li>
      <dropdown size="nav" class="nav-item">
        <span slot="button">
          <img src="static/img/avatars/6.jpg" class="img-avatar" alt="admin@bootstrapmaster.com">
          <span class="d-md-down-none">{{welcome}}</span>
        </span>
        <div slot="dropdown-menu"class="dropdown-menu dropdown-menu-right">

          <div class="dropdown-header text-center"><strong>Account</strong></div>

         <!--  <a class="dropdown-item" href="#"><i class="fa fa-bell-o"></i> Updates<span class="badge badge-info">42</span></a> -->
          <!-- <a class="dropdown-item" href="#"><i class="fa fa-envelope-o"></i> Messages<span class="badge badge-success">0</span></a>
          <a class="dropdown-item" href="#"><i class="fa fa-tasks"></i> Tasks<span class="badge badge-danger">0</span></a>
          <a class="dropdown-item" href="#"><i class="fa fa-comments"></i> Comments<span class="badge badge-warning">0</span></a>
          <div class="dropdown-header text-center"><strong>Settings</strong></div>
          <a class="dropdown-item" href="#"><i class="fa fa-user"></i> Profile</a>
          <a class="dropdown-item" href="#"><i class="fa fa-wrench"></i> Settings</a>
          <a class="dropdown-item" href="#"><i class="fa fa-lock"></i> Logout</a> -->
          <p class="dropdown-item" href="#" @click="nopower"><i class="fa fa-envelope-o"></i> Messages<span class="badge badge-success">0</span></p>
          <p class="dropdown-item" href="#" @click="nopower"><i class="fa fa-tasks"></i> Tasks<span class="badge badge-danger">0</span></p>
          <p class="dropdown-item" href="#" @click="nopower"><i class="fa fa-comments"></i> Comments<span class="badge badge-warning">0</span></p>
          <div class="dropdown-header text-center"><strong>Settings</strong></div>
          <p class="dropdown-item" href="#" @click="nopower"><i class="fa fa-user"></i> Profile</p>
          <p class="dropdown-item" href="#" @click="nopower"><i class="fa fa-wrench"></i> Settings</p>
          <a class="dropdown-item" href="#" @click="loginOut"><i class="fa fa-lock"></i> Logout</a>
          <!-- <a class="dropdown-item" href="#"><i class="fa fa-usd"></i> Payments<span class="badge badge-default">42</span></a>
          <a class="dropdown-item" href="#"><i class="fa fa-file"></i> Projects<span class="badge badge-primary">42</span></a>
          <div class="divider"></div>
          <a class="dropdown-item" href="#"><i class="fa fa-shield"></i> Lock Account</a> -->
          
        </div>
      </dropdown>
      <dropdown size="nav" class="nav-item" style="margin-left: 20px!important;">
        <span slot="button">
          <span class="d-md-down-none">权限申请</span>
        </span>
        <div slot="dropdown-menu"class="dropdown-menu dropdown-menu-right">
          <div class="dropdown-header text-center"><a style="color:#333" href="mailto:yinxq@ifeng.com">推荐运营：殷晓晴</a></div>
          <div class="dropdown-header text-center"><a style="color:#333" href="mailto:jinze@ifeng.com">数据推荐：金泽</a></div>
          <div class="dropdown-header text-center"><a style="color:#333" href="mailto:gaopeng1@ifeng.com">数据推荐：高鹏</a></div>
          <div class="dropdown-header text-center"><a style="color:#333" href="mailto:lihy11@ifeng.com">数据推荐：李会洋</a></div>
        </div>
      </dropdown>
    </ul>
  </navbar>
</template>
<script>
import {MessageBox} from 'element-ui'
import navbar from './Navbar'
import { dropdown } from 'vue-strap'

import store from '@/vuex/store'

import { mapState,mapMutations } from 'vuex';

var welcome='addmin';
export default {
  data(){
    return{
      welcome:welcome
    }
  },
  name: 'header',
  components: {
    navbar,
    dropdown
  },
  /*store,
  computed:mapState(["count"]),*/
  methods: {
    nopower(){
      MessageBox({
        title: '模块正在建设中',
        message: '模块正在建设中，请等待！',
        type: 'warning'
      });
    },
    loginOut(){
      sessionStorage.clear();
      /*this.this.$router.push({ path: '/' });*/
    },
    welcomeUser(){
      this.welcome = localStorage.getItem('name');
    },
    changeEchart(){
      console.log(this.count)
    },
    click () {
      // do nothing
    },
    sidebarToggle (e) {
      e.preventDefault()
      document.body.classList.toggle('sidebar-hidden')
    },
    sidebarMinimize (e) {
      e.preventDefault()
      document.body.classList.toggle('sidebar-minimized')
    },
    mobileSidebarToggle (e) {
      e.preventDefault()
      document.body.classList.toggle('sidebar-mobile-show')
    },
    asideToggle (e) {
      e.preventDefault()
      document.body.classList.toggle('aside-menu-hidden')
    }
  },
  created:function(){
    this.welcomeUser();
  }
}
</script>
