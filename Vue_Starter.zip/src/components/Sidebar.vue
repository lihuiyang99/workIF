<template>
  <div class="sidebar" @click="hideBlock">
    <nav class="sidebar-nav">
     <main style="padding-left: 250px">
      <div @click="conRoutes" style="background-color: #383e4b;width: 220px; float: left; margin-left: -100%; position: relative; left: -250px">
      <form>
          <div class="form-group p-2  mb-0" style="position:relative">
            <input type="text" class="form-control" aria-describedby="search" @keyup="showKeyUp"  v-model="Search" placeholder="Search..."/>
            <ul class="searchList" :class="display?'showBlock':'hideBlock'"><li  v-for="(cur,curIndex) in this.SearchArr" @click="goPath(cur.path)">  {{cur.name}}</li></ul>
          </div>
        </form>
        <el-menu  theme="dark" mode="vertical" router unique-opened :default-active="this.$route.path">
          <template v-for="(parent, parentIndex) in this.$router.options.routes" v-if="!parent.hidden&&parent.show">
            <el-submenu :index="parentIndex+''">
              <template slot="title"><i class=""></i>{{parent.name}}</template>
              <template v-for="(child, childIndex) in parent.children" v-if="!child.children && !child.hidden">
                <el-menu-item :index="child.path"><i class=""></i>{{child.name}}</el-menu-item>
              </template>
              <template v-else-if="child.children && !child.hidden">
                <el-submenu :index="parentIndex+'-'+childIndex">
                  <template slot="title">{{child.name}}</template>
                  <template v-for="grandchild in child.children" v-if="!grandchild.hidden">
                    <el-menu-item :index="grandchild.path"><i class=""></i>{{grandchild.name}}</el-menu-item>
                  </template>
                </el-submenu>
              </template>
            </el-submenu>
          </template>
        </el-menu>
      </div>
      <div style="clear: both"></div>
    </main>
    </nav>
  </div>
</template>
<script>
import router from '../router'
var SearchArr=[];
var RoutesArr=[];
var parents=[];
var authorityArr=[];

export default {
  name: 'sidebar',
  data () {
    return {
      display:1,//显示
      RoutesArr:RoutesArr,
      Search:'',
      SearchArr:SearchArr,
      activeIndex: '1',
      authorityArr:authorityArr
    }
  },
  router,
  methods: {
    getJSON: function () {
      var map = new Map();
      var mail = localStorage.getItem('uid')+'@ifeng.com';
      var url = 'http://10.50.1.130:38080/sso/sso_getAuthList.action?uname='+mail;
      this.$http.get(url).then((response) => {
        var obj = response.data;
        var temps = obj['data'];
        for (var i in temps) {
          var temp = temps[i];
          var name = temp['resourcesViewName'];
          if (map.has(name)) {
          } else {
            map.set(name, 1);
            localStorage.setItem(name, name);
          }
        }
        var parents = this.$router.options.routes;
        for (var i in parents) {
          var parent = parents[i];
          if (parent.children) {
            var children = parent.children;
            for (var j in children) {
              var child = children[j];
              if (child.children) {
                var grandchildren = child.children;
                for (var k in grandchildren) {
                  var grandchild = grandchildren[k];
                  if (!map.has(grandchild.path.slice(1))) {
                    grandchild.hidden = true;
                  }else{
                    authorityArr.push(grandchild)
                  }
                }
              } else {
                if (!map.has(child.path.slice(1))) {
                  child.hidden = true;
                }else{
                  authorityArr.push(child)
                }
              }
            }
          }
        }
        for (var i in parents) {
          var parent = parents[i];
          if (parent.children) {
            var childCount = 0;
            var children = parent.children;
            for (var j in children) {
              var child = children[j];
              if (child.children) {
                var grandchildCount = 0;
                var grandchildren = child.children;
                for (var k in grandchildren) {
                  var grandchild = grandchildren[k];
                  if (grandchild.hidden == true) {
                    grandchildCount++;
                  }
                }
                if (grandchildCount == grandchildren.length) {
                  child.hidden = true;
                  childCount++;
                }
              } else {
                if (child.hidden == true) {
                  childCount++;
                }
              }
            }
            if (childCount == children.length) {
              parent.hidden = true;
            }
          }
        }
        // sessionStorage.setItem('authorityArr', JSON.stringify(authorityArr));
        this.$forceUpdate();

        // if (this.$router.history.current.path == '/home') {
        //   this.$router.push({ path: '/video' });
        // }
      })
    },
    hideBlock:function(){
      this.display=0;
    },
    goPath:function(path){
      this.$router.push(path);
      this.display=0;
    },
    showKeyUp: function (ev) {
        console.log(this.authorityArr)
          this.display=1;
          this.SearchArr.length=0
          if(ev.keyCode==13){
              this.$router.push(this.Search);
           }else{
            if(this.Search){
              var SearchTxt=this.Search
              $.each(this.authorityArr,function(index,item){

                if(item['name']){
                  if(item['name'].indexOf(SearchTxt) != -1){
                    SearchArr.push(item)
                  }
                }
              })
            }
           }
           console.log(this.SearchArr)
       },
    getRoutesArr:function(){
      var optionsRoute=this.$router.options.routes;
      for(var i=0;i<optionsRoute.length-1;i++){//老子级
        var curparent=optionsRoute[i];
            var obj={};
            if(curparent['hidden']==false){
              obj['name']=curparent['name']
              obj['path']=curparent['path']
              obj['hidden']=curparent['hidden']
              RoutesArr.push(obj)
            }
            if(curparent['children']){
              for(var j=0;j<curparent['children'].length;j++){
                var cur=curparent['children'][j];
                var obj1={};
                if(cur['hidden']==false){
                  obj1['name']=cur['name']
                  obj1['path']=cur['path']
                  obj1['hidden']=cur['hidden']
                  RoutesArr.push(obj1)
                }
                if(cur['children']){
                  for(var k=0;k<cur['children'].length;k++){
                    var obj2={};
                    var curSon=cur['children'][k];
                    if(curSon['hidden']==false){
                      obj2['name']=curSon['name']
                      obj2['path']=curSon['path']
                      obj2['hidden']=curSon['hidden']
                      RoutesArr.push(obj2)
                    }
                  }
                }
              }
            }

      }
      /*console.log(RoutesArr)*/
    },
    conRoutes:function(){
      /*console.log(this.$router.options.routes)*/
    },
    handleClick (e) {
      e.preventDefault()
      e.target.parentElement.classList.toggle('open')
    }
  },
  created:function(){
    this.getJSON();
  },
  mounted: function () {
     this.getRoutesArr();
  }
}
</script>

<style lang="css">
  .nav-link {
    cursor:pointer;
  }
  .el-submenu__title{
    height: 45px;
    line-height: 45px;
  }
  .el-submenu .el-menu-item{
    height: 45px;
    line-height: 45px;
  }
  .el-icon-lishihuisu{
    display: inline-block;
    background-image: url(../../static/img/history.png);
    width: 20px;
    height: 20px;
    background-size: 100%;
    vertical-align: middle!important;
  }
  .el-icon-lishihuisu:before {
    content: "\E61E";
    width: 20px;
    height: 20px;
    background-image: url(../../static/img/history.png);
    background-size: 100%;
}
.searchList{
  width: 202px;
    padding: 0;
    background: #fff;
    position: absolute;
    right: 0;
    left: 10px;
    z-index: 1;
}
.searchList>li{
  color: #333;
  list-style: none;
  text-align: left;
    height: 30px;
    line-height: 30px;
    padding-left: 20px;

}
.searchList>li:hover{
  background-color: #ccc;
  color: #333;
  cursor: pointer;
}
.showBlock{
  display: block;
}
.hideBlock{
  display: none;
}
</style>
